"use client";

import { EntityBrowser } from "@/components/EntityBrowser";
import { Badge, InfoNote } from "@/components/ui";

export default function AuditPage() {
  return (
    <div className="space-y-4">
      <InfoNote>
        Every score, term, amount and approval is audited. The repository writes an audit row whenever a value actually
        changes, recording the actor, the field, the value before, the value after and the reason where one was given.
      </InfoNote>

      <EntityBrowser
        entity="audit_events"
        module="audit"
        title="Audit history"
        description="Actor, action, record, field, value before, value after, reason and time."
        searchPlaceholder="Search actor, action, field, reason or record type"
        filters={[
          {
            column: "action",
            label: "Action",
            options: [
              { value: "create", label: "Create" },
              { value: "update", label: "Update" },
              { value: "delete", label: "Delete" },
            ],
          },
        ]}
        columns={[
          { key: "created_at", label: "When" },
          { key: "actor_name", label: "Actor" },
          { key: "action", label: "Action", render: (r) => <Badge tone={String(r.action) === "delete" ? "danger" : String(r.action) === "create" ? "success" : "info"}>{String(r.action)}</Badge> },
          { key: "entity_type", label: "Record type" },
          { key: "entity_id", label: "Record" },
          { key: "field", label: "Field" },
          { key: "before_value", label: "Before" },
          { key: "after_value", label: "After" },
          { key: "reason", label: "Reason" },
        ]}
      />
    </div>
  );
}
