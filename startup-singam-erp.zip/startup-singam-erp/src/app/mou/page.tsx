"use client";

import { EntityBrowser, LinkCell } from "@/components/EntityBrowser";
import { ModuleActions } from "@/components/ModuleActions";
import { InfoNote, StatusBadge } from "@/components/ui";

export default function MouPage() {
  return (
    <div className="space-y-4">
      <InfoNote>
        The documented timing runs as automated tasks: sharing the MoU starts the review clock, the Legal AMA falls on the
        fourth working day and the signing deadline on the seventh. An unsigned MoU needs a Proceed, Negotiate or
        Discontinue response; negotiation escalates to Management, and discontinuation keeps the founder&apos;s email and
        the reason on the record.
      </InfoNote>

      <ModuleActions
        actions={["mou.share", "mou.record_ama", "mou.respond"]}
        label="MoU actions"
        notes={{
          "mou.share": "Deadlines are computed against the working-day calendar, so holidays and non-working days are respected.",
        }}
      />

      <EntityBrowser
        entity="mous"
        module="mou"
        title="Startup MoUs"
        description="Signed version, commercial schedule, approved exceptions and signature dates are stored."
        searchPlaceholder="Search commercial schedule, exceptions or founder email"
        filters={[
          {
            column: "status",
            label: "Status",
            options: [
              { value: "not_started", label: "Not started" },
              { value: "shared", label: "Shared" },
              { value: "under_review", label: "Under review" },
              { value: "legal_ama_done", label: "Legal AMA done" },
              { value: "signed", label: "Signed" },
              { value: "negotiation", label: "In negotiation" },
              { value: "discontinued", label: "Discontinued" },
            ],
          },
        ]}
        columns={[
          { key: "id", label: "MoU", render: (r) => <LinkCell entity="mous" id={r.id} label={String(r.id)} /> },
          { key: "application_id", label: "Application", render: (r) => <LinkCell entity="applications" id={r.application_id} label={String(r.application_id)} /> },
          { key: "status", label: "Status", render: (r) => <StatusBadge registry="mou" value={r.status} /> },
          { key: "shared_on", label: "Shared" },
          { key: "legal_ama_due", label: "Legal AMA due (working day 4)" },
          { key: "legal_ama_on", label: "AMA held" },
          { key: "signing_deadline", label: "Signing deadline (working day 7)" },
          { key: "signed_on", label: "Signed" },
          { key: "response", label: "Response" },
          {
            key: "escalated_to_management",
            label: "Escalated",
            render: (r) => (r.escalated_to_management ? <span className="text-xs font-medium text-warn">Yes</span> : <span className="text-faint">No</span>),
          },
          { key: "approved_exceptions", label: "Approved exceptions" },
          { key: "discontinued_reason", label: "Discontinuation reason" },
        ]}
      />
    </div>
  );
}
