"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { apiDashboard, type DashboardResponse } from "@/lib/client/api";
import { useSession } from "@/components/SessionProvider";
import { Badge, Card, DateText, EmptyState, InfoNote, Money, PageHeader, ProgressBar, Stat, StatusBadge, Table, ToneDot } from "@/components/ui";
import { DEPARTMENT_MAP } from "@/lib/domain/departments";
import { Icon } from "@/components/icons";
import type { Tone } from "@/lib/domain/statuses";

export default function ManagementDashboard() {
  const { session, seasonId, season } = useSession();
  const [data, setData] = useState<DashboardResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Reload whenever the season changes; the figures below are all season scoped.
    if (!seasonId) return;
    setError(null);
    apiDashboard()
      .then(setData)
      .catch((e) => setError(e instanceof Error ? e.message : "Failed to load dashboard"));
  }, [seasonId]);

  if (error) {
    return (
      <div className="p-4">
        <InfoNote tone="danger">{error}</InfoNote>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="space-y-6">
        <div className="h-8 w-64 animate-pulse rounded bg-hover" />
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-[76px] animate-pulse rounded-lg border border-hair bg-surface" />
          ))}
        </div>
        <div className="grid gap-4 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-40 animate-pulse rounded-lg border border-hair bg-surface" />
          ))}
        </div>
      </div>
    );
  }

  const k = data.kpis;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Management dashboard"
        description={
          <>
            {season ? (
              <span className="mb-1.5 flex flex-wrap items-center gap-2">
                <Badge tone="info">{season.name}</Badge>
                <span className="text-[12.5px] text-faint">
                  All figures on this page are scoped to {season.name}. Change the season in the sidebar.
                </span>
              </span>
            ) : null}
            Every startup&apos;s progress, pending actions, investor commitments, funds deployed, fees collected and
            outstanding balances. Selection, shoot completion, investment commitment, deployment and fee collection
            are tracked separately, never merged.
          </>
        }
        icon={<Icon name="home" className="h-[22px] w-[22px] text-brand" />}
        actions={
          <>
            <Link
              href="/journeys"
              className="inline-flex items-center gap-1.5 rounded-md border border-hair-strong bg-canvas px-2.5 py-1.5 text-[13.5px] font-medium text-ink transition hover:bg-hover"
            >
              <Icon name="map" className="h-[15px] w-[15px] text-faint" />
              Journey maps
            </Link>
            <Link
              href="/my-work"
              className="inline-flex items-center gap-1.5 rounded-md bg-navy px-2.5 py-1.5 text-[13.5px] font-medium text-white transition hover:bg-navy-dark"
            >
              <Icon name="check-square" className="h-[15px] w-[15px]" />
              My work
            </Link>
          </>
        }
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Stat
          label="Application to selection"
          value={`${k.applications.conversionPct}%`}
          hint={`${k.applications.proceeded} of ${k.applications.total} proceeded`}
          tone="progress"
        />
        <Stat label="Stage-wise backlog" value={k.stageBacklog.reduce((s, b) => s + b.count, 0)} hint={`${k.stageBacklog.length} open stages`} tone="warning" />
        <Stat label="Investor conversion" value={`${k.matching.coveragePct}%`} hint={`${k.matching.advanced} advanced of ${k.investors.total} investors`} tone="info" />
        <Stat label="Upfront fees" value={<Money paise={k.upfront.collected} compact />} hint={`${k.upfront.overdueCount} overdue, ${(k.upfront.overdue / 100).toLocaleString("en-IN")} rupees outstanding`} tone={k.upfront.overdueCount > 0 ? "danger" : "success"} />
        <Stat label="Verified deployment" value={<Money paise={k.commitments.deployed} compact />} hint={<><Money paise={k.commitments.outstanding} compact /> commitment outstanding</>} tone="success" />
        <Stat label="Success fees" value={<Money paise={k.successFees.collected} compact />} hint={`${k.successFees.overdueCount} overdue`} tone={k.successFees.overdueCount > 0 ? "danger" : "success"} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Applications" subtitle="Sourcing through internal screening">
          <dl className="space-y-2 text-[13px]">
            <Row label="Total applications" value={k.applications.total} />
            <Row label="Awaiting screening" value={k.applications.submitted} />
            <Row label="In screening" value={k.applications.inScreening} />
            <Row label="Proceeded" value={k.applications.proceeded} />
            <Row label="Rejected" value={k.applications.rejected} />
          </dl>
          <div className="mt-3">
            <ProgressBar value={k.applications.conversionPct} tone="progress" />
          </div>
        </Card>

        <Card title="Investor engagement" subtitle="Sourcing through commitment">
          <dl className="space-y-2 text-[13px]">
            <Row label="Investors on record" value={k.investors.total} />
            <Row label="Onboarded" value={k.investors.onboarded} />
            <Row label="Verification pending" value={k.investors.verificationPending} />
            <Row label="Agreement pending" value={k.investors.agreementPending} />
            <Row label="Matches advanced" value={k.matching.advanced} />
          </dl>
          <div className="mt-3 flex flex-wrap gap-1">
            {Object.entries(k.investors.gradeMix).map(([grade, count]) => (
              <Badge key={grade} tone={grade === "l1" ? "success" : grade === "l2" ? "info" : grade === "l3" ? "warning" : "neutral"}>
                {grade.toUpperCase()}: {count}
              </Badge>
            ))}
          </div>
        </Card>

        <Card title="Shoot and telecast readiness">
          <dl className="space-y-2 text-[13px]">
            <Row label="Paid startups awaiting AV" value={k.shoot.paidAwaitingAv} />
            <Row label="AV completed" value={k.shoot.avCompleted} />
            <Row label="Mock readiness approved" value={k.shoot.mockReady} />
            <Row label="Shoots completed" value={k.shoot.shootCompleted} />
            <Row label="Episodes awaiting telecast" value={k.shoot.telecastReady} />
            <Row label="Telecast done" value={k.shoot.telecastDone} />
          </dl>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Commitments and deals">
          <dl className="space-y-2 text-[13px]">
            <Row label="Committed" value={<Money paise={k.commitments.committed} />} />
            <Row label="Signed deals" value={k.commitments.signedDeals} />
            <Row label="Verified deployed" value={<Money paise={k.commitments.deployed} />} />
            <Row label="Outstanding commitment" value={<Money paise={k.commitments.outstanding} />} />
            <Row label="Deals at risk" value={k.commitments.atRiskDeals} />
          </dl>
        </Card>
        <Card title="Finance">
          <dl className="space-y-2 text-[13px]">
            <Row label="Upfront fees due" value={<Money paise={k.upfront.due} />} />
            <Row label="Upfront fees collected" value={<Money paise={k.upfront.collected} />} />
            <Row label="Upfront fees overdue" value={<Money paise={k.upfront.overdue} />} />
            <Row label="Success fee due" value={<Money paise={k.successFees.due} />} />
            <Row label="Success fee invoiced" value={<Money paise={k.successFees.invoiced} />} />
            <Row label="Success fee collected" value={<Money paise={k.successFees.collected} />} />
          </dl>
        </Card>
        <Card title="Community">
          <dl className="space-y-2 text-[13px]">
            <Row label="Members" value={k.community.members} />
            <Row label="Events" value={`${k.community.events} (${k.community.attendance} attended)`} />
            <Row label="Qualified referrals" value={k.community.qualifiedReferrals} />
            <Row label="Converted referrals" value={k.community.convertedReferrals} />
            <Row label="Support resolved" value={`${k.community.supportResolved} of ${k.community.supportResolved + k.community.supportOpen}`} />
            <Row label="Referral funding outcomes" value={<Money paise={k.community.referralFunding} compact />} />
          </dl>
        </Card>
      </div>

      <Card title="Stage-wise backlog and ageing" subtitle="Ordered by the age of the oldest open record" padded={false}>
        <Table
          dense
          columns={[
            { key: "stage", label: "Stage", render: (r) => <span className="font-medium text-ink">{String(r.stage)}</span> },
            { key: "department", label: "Owner department", render: (r) => <Badge>{DEPARTMENT_MAP[String(r.department)]?.short ?? String(r.department)}</Badge> },
            { key: "count", label: "Open", align: "right" },
            {
              key: "oldestDays",
              label: "Oldest (days)",
              align: "right",
              render: (r) => (
                <span className={Number(r.oldestDays) > 30 ? "font-semibold text-risk" : Number(r.oldestDays) > 10 ? "font-medium text-warn" : "text-ink-soft"}>
                  {String(r.oldestDays)}
                </span>
              ),
            },
          ]}
          rows={k.stageBacklog as unknown as Record<string, unknown>[]}
          empty="No open stages"
        />
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Material exceptions" subtitle="Escalations, overdue fees and failed syncs" padded={false}>
          {k.exceptions.length === 0 ? (
            <div className="p-4">
              <EmptyState title="No exceptions open" />
            </div>
          ) : (
            <ul className="divide-y divide-hair">
              {k.exceptions.slice(0, 12).map((e) => (
                <li key={`${e.id}-${e.title}`} className="flex items-start gap-3 px-4 py-3">
                  <ToneDot tone={(e.severity === "critical" ? "danger" : e.severity === "high" ? "warning" : "info") as Tone} />
                  <div className="min-w-0">
                    <p className="text-[13.5px] font-medium text-ink">{e.title}</p>
                    <p className="mt-0.5 text-[12.5px] text-ink-soft">{e.detail}</p>
                    <p className="mt-1 text-[11px] text-faint">
                      {DEPARTMENT_MAP[e.department]?.label ?? e.department} - {e.id}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Department-wise overdue actions">
          {k.overdueByDepartment.length === 0 ? (
            <EmptyState title="No overdue actions" />
          ) : (
            <ul className="space-y-2">
              {k.overdueByDepartment.map((d) => (
                <li key={d.department} className="flex items-center justify-between gap-3 text-[13.5px]">
                  <span className="text-ink-soft">{DEPARTMENT_MAP[d.department]?.label ?? d.department}</span>
                  <Badge tone="danger">{d.count} overdue</Badge>
                </li>
              ))}
            </ul>
          )}
          <div className="mt-4">
            <Link href="/tasks" className="text-[13.5px] font-medium text-navy underline decoration-navy/25 underline-offset-2 hover:decoration-navy">
              Open the task register
            </Link>
          </div>
        </Card>
      </div>

      <Card
        title="Startup progress board"
        subtitle="Each startup reads as a sentence: shoot, telecast, deployment and fee collection are separate facts."
        padded={false}
      >
        <div className="overflow-x-auto">
          <table className="ss-table w-full border-collapse text-[13px]">
            <thead>
              <tr className="border-b border-hair bg-surface text-left text-[11px] font-semibold uppercase tracking-[0.04em] text-faint">
                <th className="px-3 py-2">Startup</th>
                <th className="px-3 py-2">Application</th>
                <th className="px-3 py-2">Screening</th>
                <th className="px-3 py-2">MoU / IRR</th>
                <th className="px-3 py-2">Committee</th>
                <th className="px-3 py-2">Upfront fee</th>
                <th className="px-3 py-2">Shoot</th>
                <th className="px-3 py-2">Telecast</th>
                <th className="px-3 py-2 text-right">Deployed</th>
                <th className="px-3 py-2 text-right">Outstanding</th>
                <th className="px-3 py-2">Success fee</th>
                <th className="px-3 py-2 text-right">Tasks</th>
              </tr>
            </thead>
            <tbody>
              {data.board.map((row) => (
                <tr key={row.startup_id} className="border-b border-hair last:border-0 transition hover:bg-surface">
                  <td className="px-3 py-2">
                    <Link href={`/records/startups/${row.startup_id}`} className="font-medium text-navy underline decoration-navy/25 underline-offset-2 hover:decoration-navy">
                      {row.startup}
                    </Link>
                    <div className="text-[11px] text-faint">
                      {row.sector} - {row.stage.replace(/_/g, " ")}
                    </div>
                    <div className="mt-1 max-w-md text-[11px] italic text-ink-soft">{row.sentence}</div>
                  </td>
                  <td className="px-3 py-2">
                    {row.application_ref ? (
                      <>
                        <StatusBadge registry="application" value={row.application_status} />
                        <div className="mt-0.5 font-mono text-[10px] text-faint">{row.application_ref}</div>
                      </>
                    ) : (
                      <span className="text-faint">-</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="screening_outcome" value={row.screening_outcome} />
                    <div className="mt-0.5">
                      <StatusBadge registry="analyst_recommendation" value={row.analyst_recommendation} />
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="mou" value={row.mou_status} />
                    <div className="mt-0.5">
                      <StatusBadge registry="irr" value={row.irr_status} />
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="committee_outcome" value={row.committee_outcome} />
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="upfront_fee" value={row.upfront_fee_status} />
                    {row.upfront_fee_amount > 0 ? (
                      <div className="mt-0.5 text-[11px] text-faint">
                        <Money paise={row.upfront_fee_paid} compact /> of <Money paise={row.upfront_fee_amount} compact />
                      </div>
                    ) : null}
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="main_shoot" value={row.shoot_status} />
                    <div className="mt-0.5 flex gap-1">
                      <StatusBadge registry="av_shoot" value={row.av_status} />
                      <StatusBadge registry="mock_shoot" value={row.mock_status} />
                    </div>
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="telecast" value={row.telecast_status} />
                    <div className="mt-0.5">
                      <StatusBadge registry="episode" value={row.episode_status} />
                    </div>
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    <Money paise={row.deployed_amount} compact />
                  </td>
                  <td className="px-3 py-2 text-right tabular-nums">
                    {row.outstanding_commitment > 0 ? <Money paise={row.outstanding_commitment} compact /> : <span className="text-faint">-</span>}
                  </td>
                  <td className="px-3 py-2">
                    <StatusBadge registry="success_fee" value={row.success_fee_status} />
                    {row.success_fee_invoiced > 0 ? (
                      <div className="mt-0.5 text-[11px] text-faint">
                        <Money paise={row.success_fee_collected} compact /> of <Money paise={row.success_fee_invoiced} compact />
                      </div>
                    ) : null}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {row.open_tasks === 0 ? (
                      <span className="text-faint">0</span>
                    ) : (
                      <Badge tone={row.overdue_tasks > 0 ? "danger" : "neutral"}>
                        {row.open_tasks}
                        {row.overdue_tasks > 0 ? ` (${row.overdue_tasks} late)` : ""}
                      </Badge>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card title="Departments" subtitle="Every department works from the same startup and investor records.">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {data.departments.map((d) => (
            <div key={d.key} className="rounded-lg border border-hair bg-canvas p-3.5 shadow-card transition hover:border-hair-strong hover:shadow-raised">
              <p className="text-[13.5px] font-semibold text-ink">{d.label}</p>
              <p className="mt-1 text-[11.5px] leading-relaxed text-faint">{d.description}</p>
              <dl className="mt-3 space-y-1.5 border-t border-hair pt-2.5 text-[12px]">
                <div className="flex justify-between">
                  <dt className="text-faint">Open</dt>
                  <dd className="font-medium tabular-nums text-ink">{d.metrics.open}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-faint">Overdue</dt>
                  <dd className={d.metrics.overdue > 0 ? "font-semibold text-risk" : "font-medium text-ink"}>{d.metrics.overdue}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-faint">Escalated</dt>
                  <dd className={d.metrics.escalated > 0 ? "font-semibold text-warn" : "font-medium text-ink"}>{d.metrics.escalated}</dd>
                </div>
              </dl>
            </div>
          ))}
        </div>
      </Card>

      {session ? (
        <InfoNote>
          Acting as <strong>{session.actor.name}</strong> ({DEPARTMENT_MAP[session.actor.department]?.label ?? session.actor.department}).
          Switch the acting user in the header to see how the screens, exports and documents change with role restrictions.
        </InfoNote>
      ) : null}

      <div className="text-[12px] text-faint">
        Figures refresh from the live records on every load. <DateText value={new Date().toISOString()} />.
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <dt className="text-ink-soft">{label}</dt>
      <dd className="text-right font-medium tabular-nums text-ink">{value}</dd>
    </div>
  );
}
