"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { apiMeta, type MetaResponse } from "@/lib/client/api";
import { Badge, Card, InfoNote, PageHeader, StatusBadge, Tabs } from "@/components/ui";
import { DEPARTMENT_MAP } from "@/lib/domain/departments";

/**
 * Journey map.
 *
 * Renders every SOP stage with its owner, deadline rule, required output, evidence, approver,
 * required documents and escalation path. This is the process foundation the brief asks for,
 * presented straight from the same definitions the server enforces.
 */
export default function JourneysPage() {
  const [meta, setMeta] = useState<MetaResponse | null>(null);
  const [tab, setTab] = useState("startup");

  useEffect(() => {
    apiMeta().then(setMeta).catch(() => setMeta(null));
  }, []);

  if (!meta) return <div className="p-8 text-center text-sm text-faint">Loading journey maps&hellip;</div>;

  const journeyStages = (key: string) => meta.stages.filter((s) => s.journey === key).sort((a, b) => a.order - b.order);

  const tabs = meta.journeys.map((j) => ({ key: j.key, label: j.label }));

  const activeJourney = meta.journeys.find((j) => j.key === tab);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Journey maps and SOP stages"
        description="Every stage with a clear owner, deadline, approval, document record and escalation mechanism. The startup and investor journeys run in parallel, and after the shoot the content and investment workstreams continue side by side."
        actions={
          <Link href="/policies" className="rounded-lg border border-hair-strong bg-canvas px-3 py-1.5 text-[13px] hover:bg-surface">
            Policies and configuration
          </Link>
        }
      />

      <InfoNote>
        The ERP connects these journeys while maintaining <strong>separate statuses</strong> for selection, production,
        investment, community engagement and finance. A startup can therefore read as: shoot completed; telecast pending;
        Rs 75 lakh deployed; success fee partly collected.
      </InfoNote>

      <Tabs tabs={tabs} active={tab} onChange={setTab} />

      {activeJourney ? (
        <Card title={activeJourney.label} subtitle={activeJourney.description}>
          <div className="mb-3 flex items-center gap-2">
            <Badge>{DEPARTMENT_MAP[activeJourney.department]?.label ?? activeJourney.department}</Badge>
            <span className="text-xs text-faint">{journeyStages(activeJourney.key).length} stages</span>
          </div>
          <ol className="space-y-3">
            {journeyStages(activeJourney.key).map((stage, i) => (
              <li key={stage.key} className="rounded-xl border border-hair p-3">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="flex items-start gap-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-navy text-[11px] font-semibold text-white">
                      {i + 1}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-ink">{stage.label}</p>
                      <p className="mt-0.5 font-mono text-[11px] text-faint">{stage.key}</p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-1">
                    <Badge>{DEPARTMENT_MAP[stage.department]?.short ?? stage.department}</Badge>
                    {stage.statusRegistry ? <StatusBadge registry={stage.statusRegistry} value={Object.keys((meta.statuses[stage.statusRegistry] ?? {}))[0]} /> : null}
                  </div>
                </div>

                <dl className="mt-3 grid gap-x-6 gap-y-2 sm:grid-cols-2 lg:grid-cols-3">
                  <Detail label="Owner role" value={stage.ownerRole.replace(/_/g, " ")} />
                  <Detail
                    label="Deadline rule"
                    value={stage.deadline ? `${stage.deadline.workingDays} working day(s) from ${stage.deadline.fromEvent.replace(/_/g, " ")}` : "Not time-bound"}
                  />
                  <Detail label="Approver" value={stage.approverRole ? stage.approverRole.replace(/_/g, " ") : "Not required"} />
                  <Detail label="Required output" value={stage.requiredOutput} />
                  <Detail label="Evidence" value={stage.evidence} />
                  <Detail
                    label="Required documents"
                    value={
                      stage.requiredDocuments && stage.requiredDocuments.length > 0 ? (
                        <span className="flex flex-wrap gap-1">
                          {stage.requiredDocuments.map((d) => (
                            <span key={d} className="rounded bg-hover px-1.5 py-0.5 font-mono text-[10px] text-ink-soft">
                              {d}
                            </span>
                          ))}
                        </span>
                      ) : (
                        "None"
                      )
                    }
                  />
                  {stage.escalation ? <Detail label="Escalation" value={stage.escalation.replace(/_/g, " ")} /> : null}
                  {stage.notes ? <Detail label="Notes" value={stage.notes} /> : null}
                </dl>
              </li>
            ))}
          </ol>
        </Card>
      ) : null}

      <Card title="Every task carries the same six fields" subtitle="The invariant that keeps the whole ERP auditable">
        <div className="flex flex-wrap items-center gap-2">
          {["Owner", "Due date", "Required output", "Evidence", "Approver", "Next action"].map((field) => (
            <span key={field} className="rounded-full bg-ink px-3 py-1 text-xs font-medium text-white">
              {field}
            </span>
          ))}
        </div>
      </Card>

      <Card title="Statuses tracked separately" subtitle="Selection, production, investment, community and finance never collapse into one figure">
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { label: "Selection", registry: "committee_outcome" },
            { label: "Production", registry: "main_shoot" },
            { label: "Investment", registry: "commitment" },
            { label: "Deployment", registry: "tranche" },
            { label: "Upfront fee", registry: "upfront_fee" },
            { label: "Success fee", registry: "success_fee" },
          ].map((item) => (
            <div key={item.registry} className="rounded-lg border border-hair p-3">
              <p className="text-xs font-semibold uppercase tracking-wide text-faint">{item.label}</p>
              <div className="mt-2 flex flex-wrap gap-1">
                {Object.values(meta.statuses[item.registry] ?? {}).map((s) => (
                  <Badge key={s.value} tone={s.tone as never}>
                    {s.label}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <dt className="text-[11px] font-medium uppercase tracking-wide text-faint">{label}</dt>
      <dd className="mt-0.5 text-xs text-ink-soft">{value}</dd>
    </div>
  );
}
