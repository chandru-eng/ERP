"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { apiGet, apiMeta, apiUpdate, type DetailResponse, type MetaResponse } from "@/lib/client/api";
import { useSession } from "@/components/SessionProvider";
import { Badge, Breadcrumb, Button, Card, EmptyState, Field, InfoNote, Input, KeyValue, PageHeader, StatusBadge, Table, Textarea, Toaster, useToasts } from "@/components/ui";
import { formatDateTime } from "@/lib/domain/dates";
import { compactINR } from "@/lib/domain/money";
import { humanise } from "@/lib/domain/format";

/**
 * Record detail.
 *
 * One screen serves every entity: fields from the record, related records grouped by relation
 * and an inline editor for the scalar columns the entity declares. Field-level restrictions
 * arrive already applied from the API, so this screen shows exactly what the role may see.
 */
export default function RecordPage() {
  const params = useParams<{ entity: string; id: string }>();
  const { session, canAccessModule } = useSession();
  const { toasts, push, dismiss } = useToasts();
  const [data, setData] = useState<DetailResponse | null>(null);
  const [meta, setMeta] = useState<MetaResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [reason, setReason] = useState("");

  const entity = params?.entity ?? "";
  const id = params?.id ?? "";

  const load = useCallback(async () => {
    if (!entity || !id) return;
    try {
      const detail = await apiGet(entity, id);
      setData(detail);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load record");
    }
  }, [entity, id]);

  useEffect(() => {
    void load();
    apiMeta().then(setMeta).catch(() => setMeta(null));
  }, [load]);

  const entityMeta = meta?.entities.find((e) => e.key === entity);

  const save = async () => {
    try {
      await apiUpdate(entity, id, { ...draft, _reason: reason || "Edited on the record screen" });
      push("Record updated");
      setEditing(false);
      setDraft({});
      setReason("");
      await load();
    } catch (e) {
      push(e instanceof Error ? e.message : "Update failed", "danger");
    }
  };

  if (error) {
    return (
      <div className="space-y-4">
        <InfoNote tone="danger">{error}</InfoNote>
        <Link href="/" className="text-[13px] font-medium text-navy underline decoration-navy/25 underline-offset-2 hover:decoration-navy">
          Back to the dashboard
        </Link>
      </div>
    );
  }

  if (!data) return <div className="space-y-4">
        <div className="h-8 w-72 animate-pulse rounded bg-hover" />
        <div className="h-24 animate-pulse rounded-lg border border-hair bg-surface" />
        <div className="h-48 animate-pulse rounded-lg border border-hair bg-surface" />
      </div>;
  if (!canAccessModule(entityMeta?.module ?? entity)) {
    return <EmptyState title="This record is not available for the acting role" />;
  }

  const record = data.record;
  const statusColumn = entityMeta?.status?.column;

  return (
    <div className="space-y-4">
      <Toaster toasts={toasts} onDismiss={dismiss} />
      <PageHeader
        breadcrumb={<Breadcrumb items={[{ label: "Dashboard", href: "/" }, { label: data.label }]} />}
        title={String(record.name ?? record.title ?? record.reference_no ?? record.id)}
        description={<span className="font-mono text-[12px] text-faint">{entity} / {id}</span>}
        actions={
          <>
            {statusColumn && entityMeta?.status ? (
              <StatusBadge registry={entityMeta.status.registry} value={record[statusColumn]} />
            ) : null}
            {session?.canWrite ? (
              <Button variant={editing ? "secondary" : "primary"} onClick={() => setEditing((v) => !v)}>
                {editing ? "Stop editing" : "Edit fields"}
              </Button>
            ) : null}
          </>
        }
      />

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Record" className="lg:col-span-2">
          <KeyValue items={renderFields(record)} />
        </Card>

        <Card title="Audit trail" subtitle="Most recent changes first">
          <AuditTrail entity={entity} id={id} />
        </Card>
      </div>

      {editing ? (
        <Card title="Edit fields" subtitle="A reason is stored with the change; the before and after values are both kept in the audit history">
          <div className="space-y-3">
            <InfoNote tone="warning">
              Restricted fields are rejected for the acting role, and any field reserved for Management requires that role.
            </InfoNote>
            {Object.entries(record)
              .filter(([key]) => !["id", "created_at", "updated_at"].includes(key))
              .map(([key, value]) => (
                <Field key={key} label={humanise(key)}>
                  {String(value ?? "").length > 60 ? (
                    <Textarea value={draft[key] ?? String(value ?? "")} onChange={(v) => setDraft((d) => ({ ...d, [key]: v }))} />
                  ) : (
                    <Input value={draft[key] ?? String(value ?? "")} onChange={(v) => setDraft((d) => ({ ...d, [key]: v }))} />
                  )}
                </Field>
              ))}
            <Field label="Reason for the change">
              <Input value={reason} onChange={setReason} placeholder="Recorded against the audit entry" />
            </Field>
            <div className="flex justify-end gap-2">
              <Button variant="secondary" onClick={() => setEditing(false)}>
                Cancel
              </Button>
              <Button onClick={save}>Save changes</Button>
            </div>
          </div>
        </Card>
      ) : null}

      {Object.entries(data.related).map(([label, rows]) =>
        rows.length === 0 ? null : (
          <Card key={label} title={label} subtitle={`${rows.length} record${rows.length === 1 ? "" : "s"}`} padded={false}>
            <Table
              dense
              columns={buildColumns(rows, label)}
              rows={rows}
              onRowClick={(row) => {
                if (label.toLowerCase().includes("document") || label.toLowerCase().includes("task")) return;
                if (row.id) window.location.assign(`/records/${guessEntity(label, entity)}/${String(row.id)}`);
              }}
            />
          </Card>
        ),
      )}
    </div>
  );
}

function renderFields(record: Record<string, unknown>) {
  return Object.entries(record)
    .filter(([key]) => !["created_at", "updated_at"].includes(key))
    .map(([key, value]) => {
      let rendered: React.ReactNode = null;
      const text = value === null || value === undefined ? "" : String(value);
      if (text === "[restricted]") {
        rendered = <span className="text-warn">Restricted for this role</span>;
      } else if (typeof value === "number" && /amount|fee|turnover|paid|outstanding|allocated|committed|verified|deployed|ticket|invoiced|collected|cap|discount|waiver|settlement|tax|adjustment|budget|ask/.test(key)) {
        rendered = <span className="tabular-nums">{compactINR(Number(value))}</span>;
      } else if (text.includes("T") && /_at$|_on$/.test(key)) {
        rendered = <span>{formatDateTime(text)}</span>;
      } else if (text.length > 160) {
        rendered = <span className="whitespace-pre-wrap text-xs">{text}</span>;
      } else {
        rendered = text || <span className="text-faint">-</span>;
      }
      return { label: humanise(key), value: rendered };
    });
}

function buildColumns(rows: Record<string, unknown>[], label: string) {
  const keys = Object.keys(rows[0] ?? {}).filter((k) => !["created_at", "updated_at", "score_reasons"].includes(k)).slice(0, 8);
  void label;
  return keys.map((k) => ({
    key: k,
    label: humanise(k),
    render:
      typeof rows[0]?.[k] === "number" && /amount|fee|turnover|paid|outstanding|allocated|committed|verified|deployed/.test(k)
        ? (row: Record<string, unknown>) => <span className="tabular-nums">{compactINR(Number(row[k]))}</span>
        : undefined,
  }));
}

function guessEntity(label: string, parent: string): string {
  const map: Record<string, string> = {
    Applications: "applications",
    Founders: "founders",
    "Investor conversations": "matches",
    Commitments: "commitments",
    "Funding rounds": "funding_rounds",
    Deals: "deals",
    "Upfront fees": "upfront_fees",
    "Success fees": "success_fees",
    Screening: "screenings",
    Bootcamp: "bootcamp_attendance",
    "Analyst evaluation": "analyst_evaluations",
    MoU: "mous",
    "IRR reports": "irr_reports",
    Agreements: "investor_agreements",
    "Grade assessments": "investor_grade_assessments",
    "Startup conversations": "matches",
    Tranches: "tranches",
    "Investor allocations": "deals",
    "One-to-one slots": "pitch_day_slots",
    Registrations: "event_registrations",
    Roles: "community_member_roles",
    "Support requests": "support_requests",
  };
  return map[label] ?? parent;
}

function AuditTrail({ entity, id }: { entity: string; id: string }) {
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);

  useEffect(() => {
    import("@/lib/client/api")
      .then((m) => m.apiList("audit_events", { limit: 200 }))
      .then((r) => setRows(r.items.filter((x) => x.entity_type === entity && x.entity_id === id).slice(0, 15)))
      .catch(() => setRows([]));
  }, [entity, id]);

  if (rows.length === 0) return <EmptyState title="No changes recorded yet" />;

  return (
    <ul className="space-y-2">
      {rows.map((r) => (
        <li key={String(r.id)} className="rounded-md border border-hair bg-surface p-2.5 text-xs">
          <div className="flex items-center justify-between gap-2">
            <span className="font-medium text-ink">{String(r.actor_name)}</span>
            <Badge tone={String(r.action) === "delete" ? "danger" : String(r.action) === "create" ? "success" : "info"}>{String(r.action)}</Badge>
          </div>
          {r.field ? (
            <p className="mt-1 text-ink-soft">
              <span className="font-mono text-[11px]">{String(r.field)}</span>: {String(r.before_value)} &rarr; {String(r.after_value)}
            </p>
          ) : null}
          {r.reason ? <p className="mt-0.5 italic text-ink-soft">{String(r.reason)}</p> : null}
          <p className="mt-0.5 text-[10px] text-faint">{String(r.created_at)}</p>
        </li>
      ))}
    </ul>
  );
}
