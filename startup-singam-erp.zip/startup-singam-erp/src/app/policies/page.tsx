"use client";

import { useEffect, useState } from "react";
import { apiList, apiMeta, type MetaResponse } from "@/lib/client/api";
import { MiniTable } from "@/components/MiniTable";
import { ModuleActions } from "@/components/ModuleActions";
import { Badge, Card, InfoNote, StatusBadge, Table, Tabs } from "@/components/ui";
import { UPFRONT_FEE_SCHEDULE } from "@/lib/domain/policies";

const RESOLUTIONS = [
  {
    point: "Investment closure timing",
    documents: "The application SOP starts term sheets after telecast; the investor documents start deal execution after the shoot.",
    treatment: "Closure is allowed after deal confirmation, with telecast tracked independently.",
  },
  {
    point: "Pre-shoot MoU",
    documents: "The application SOP describes signing after the stage pitch; the unified flow separates pre-shoot and post-shoot documents.",
    treatment: "Document names, purposes and actual signing points are defined in the document register.",
  },
  {
    point: "Golden Pass",
    documents: "The application SOP treats it as initial interest; the IR SOP also requires a minimum commitment before issuance.",
    treatment: "The evidence required is defined by policy and interest is retained separately from a written commitment.",
  },
  {
    point: "Investor agreements",
    documents: "The IR SOP uses both \u201cIPA or NDA or MoU\u201d and an exit gate saying all three are signed.",
    treatment: "The mandatory document set is defined per investor category and access level.",
  },
  {
    point: "Shoot-day signatures",
    documents: "The IR SOP says immediate execution and also specifies a 24-hour sign-off control.",
    treatment: "The target and the final deadline are recorded separately.",
  },
  {
    point: "Automated screening",
    documents: "Marks are defined; the qualifying score and the treatment of non-applicable criteria are not.",
    treatment: "The scoring rule must be approved before automatic progression is enabled.",
  },
  {
    point: "Upfront fee rules",
    documents: "The turnover basis and timeline are defined; the complete fee slabs and adjustment rules are not supplied.",
    treatment: "The slabs are configured from the approved commercial schedule.",
  },
  {
    point: "Community",
    documents: "Detailed operating rules are not included.",
    treatment: "Membership, engagement, referral and support workflows are approved as policies.",
  },
];

export default function PoliciesPage() {
  const [tab, setTab] = useState("policies");
  const [meta, setMeta] = useState<MetaResponse | null>(null);
  const [policies, setPolicies] = useState<Record<string, unknown>[]>([]);

  useEffect(() => {
    apiMeta().then(setMeta).catch(() => setMeta(null));
    apiList("policies", { limit: 100 }).then((r) => setPolicies(r.items)).catch(() => setPolicies([]));
  }, []);

  return (
    <div className="space-y-4">
      <InfoNote>
        Every open decision is recorded as a <strong>configurable policy with an effective date and an approval history</strong>,
        so a future season can change the process without losing the earlier records. A revision creates a new version and
        retains the previous one.
      </InfoNote>

      <ModuleActions
        actions={["policy.revise"]}
        label="Policy actions"
        notes={{ "policy.revise": "Policy changes require Management or Administrator and a recorded reason." }}
      />

      <Tabs
        tabs={[
          { key: "policies", label: "Policies" },
          { key: "resolutions", label: "Points to resolve" },
          { key: "fees", label: "Upfront fee schedule" },
          { key: "revisions", label: "Revision history" },
        ]}
        active={tab}
        onChange={setTab}
      />

      {tab === "policies" ? (
        <Card title="Configured policies" subtitle="Each policy holds a JSON value, an effective date and an approver" padded={false}>
          <Table
            columns={[
              { key: "code", label: "Code" },
              { key: "title", label: "Policy" },
              { key: "category", label: "Category", render: (r) => <Badge>{String(r.category)}</Badge> },
              { key: "status", label: "Status", render: (r) => <StatusBadge registry="policy" value={r.status} /> },
              { key: "effective_from", label: "Effective from" },
              { key: "approved_by_id", label: "Approved by" },
              { key: "value", label: "Value", render: (r) => <code className="block max-w-md overflow-hidden text-ellipsis whitespace-nowrap font-mono text-[11px] text-ink-soft">{String(r.value)}</code> },
            ]}
            rows={policies}
            empty="No policies configured"
          />
        </Card>
      ) : null}

      {tab === "resolutions" ? (
        <Card title="Points to resolve before the rules are locked" subtitle="Each row is the recommended ERP treatment" padded={false}>
          <Table
            columns={[
              { key: "point", label: "Point", render: (r) => <span className="font-medium text-ink">{String(r.point)}</span> },
              { key: "documents", label: "What the documents say" },
              { key: "treatment", label: "ERP treatment", render: (r) => <span className="text-ink-soft">{String(r.treatment)}</span> },
            ]}
            rows={RESOLUTIONS}
          />
        </Card>
      ) : null}

      {tab === "fees" ? (
        <Card title="Turnover-based upfront fee schedule" subtitle="Configured from the approved commercial schedule, with version control" padded={false}>
          <Table
            columns={[
              { key: "schedule", label: "Schedule" },
              { key: "version", label: "Version" },
              { key: "basis", label: "Basis" },
              { key: "slab", label: "Turnover slab" },
              { key: "fee", label: "Fee", align: "right" },
            ]}
            rows={Object.entries(UPFRONT_FEE_SCHEDULE).flatMap(([code, schedule]) =>
              schedule.slabs.map((slab, i) => ({
                id: `${code}-${i}`,
                schedule: code,
                version: schedule.version,
                basis: "Turnover of the relevant financial year",
                slab: `${(slab.turnoverMinPaise / 100).toLocaleString("en-IN")} to ${
                  slab.turnoverMaxPaise ? (slab.turnoverMaxPaise / 100).toLocaleString("en-IN") : "and above"
                } rupees`,
                fee: (slab.feePaise / 100).toLocaleString("en-IN"),
              })),
            )}
            empty="No fee schedule configured"
          />
        </Card>
      ) : null}

      {tab === "revisions" ? (
        <Card title="Policy revision history" subtitle="Each revision retains the version it replaced" padded={false}>
          <MiniTable
            entity="policy_revisions"
            columns={["id", "policy_id", "version", "changed_by_id", "changed_on", "reason", "value"]}
            renderers={{
              value: (r) => <code className="font-mono text-[11px] text-ink-soft">{String(r.value)}</code>,
            }}
          />
        </Card>
      ) : null}

      {meta ? (
        <Card title="Policy catalogue" subtitle="Every policy the system reads, with the question it answers">
          <ul className="space-y-2">
            {meta.policies.map((p) => (
              <li key={p.code} className="rounded-lg border border-hair p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-medium text-ink">{p.title}</p>
                  <Badge>{p.category}</Badge>
                </div>
                <p className="mt-1 text-xs text-ink-soft">{p.question}</p>
                <p className="mt-1 font-mono text-[11px] text-faint">{p.code}</p>
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}
