import { fail, ok } from "@/lib/server/api";
import { listUsers } from "@/lib/server/session";
import { DEPARTMENTS } from "@/lib/domain/departments";
import { ROLES } from "@/lib/domain/rbac";
import { actorFromRequest } from "@/lib/server/session";
import { all } from "@/lib/db/client";
import { currentSeasonId, listSeasons } from "@/lib/server/season";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const session = actorFromRequest(request);
    const notifications = all<Record<string, unknown>>(
      "SELECT * FROM notifications WHERE read_at IS NULL AND (recipient_id = ? OR recipient_role = ?) ORDER BY created_at DESC LIMIT 20",
      session.actor.id,
      session.actor.department,
    );
    return ok({
      actor: session.actor,
      seasons: listSeasons(),
      currentSeasonId: currentSeasonId(),
      canWrite: session.canWrite,
      users: listUsers(),
      roles: ROLES,
      departments: DEPARTMENTS,
      notifications,
    });
  } catch (error) {
    return fail(error);
  }
}
