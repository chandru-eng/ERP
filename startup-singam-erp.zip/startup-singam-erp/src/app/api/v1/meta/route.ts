import { fail, ok } from "@/lib/server/api";
import { ENTITIES } from "@/lib/server/registry";
import { STATUS_REGISTRIES } from "@/lib/domain/statuses";
import { JOURNEYS, ALL_STAGES, STAGE_MAP } from "@/lib/domain/workflows";
import { DEPARTMENTS } from "@/lib/domain/departments";
import { MODULES, ROLES, FIELD_RESTRICTIONS } from "@/lib/domain/rbac";
import { SCREENING_CRITERIA, SCREENING_MAX, DEFAULT_QUALIFYING_RULE } from "@/lib/domain/scoring";
import { POLICY_DEFINITIONS, UPFRONT_FEE_SCHEDULE } from "@/lib/domain/policies";
import { DOCUMENT_PURPOSES } from "@/lib/domain/documents";

export const dynamic = "force-dynamic";

/**
 * Process and configuration metadata. The UI reads this so the journey maps, badges and
 * policy screens are generated from the same definitions the server enforces.
 */
export async function GET() {
  try {
    return ok({
      entities: ENTITIES,
      statuses: STATUS_REGISTRIES,
      journeys: JOURNEYS,
      stages: ALL_STAGES,
      departments: DEPARTMENTS,
      modules: MODULES,
      roles: ROLES,
      fieldRestrictions: FIELD_RESTRICTIONS,
      screening: { criteria: SCREENING_CRITERIA, max: SCREENING_MAX, defaultRule: DEFAULT_QUALIFYING_RULE },
      policies: POLICY_DEFINITIONS,
      feeSchedules: UPFRONT_FEE_SCHEDULE,
      documentPurposes: DOCUMENT_PURPOSES,
      stageMap: Object.fromEntries(Object.entries(STAGE_MAP).map(([k, v]) => [k, v.label])),
    });
  } catch (error) {
    return fail(error);
  }
}
