"use client";

import { useMemo, useState } from "react";
import { apiActionCatalog, type ActionResult } from "@/lib/client/api";
import { useEffect } from "react";
import { ActionForm } from "./ActionForm";
import { useSession } from "./SessionProvider";
import { Button, InfoNote } from "./ui";

/**
 * Module action bar.
 *
 * Shows every action the acting role may run for a module, and opens the generic form for
 * the chosen action. Actions the role may not run are hidden, and a read-only role sees a
 * note instead of buttons.
 */
export function ModuleActions({
  actions,
  label = "Actions",
  defaults = {},
  notes = {},
  documentPurposes = [],
}: {
  actions: string[];
  label?: string;
  defaults?: Record<string, unknown>;
  notes?: Record<string, string>;
  documentPurposes?: { key: string; label: string }[];
}) {
  const { session } = useSession();
  const [allowed, setAllowed] = useState<Set<string>>(new Set());
  const [catalog, setCatalog] = useState<Record<string, { label: string; description: string }>>({});
  const [open, setOpen] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<ActionResult | null>(null);

  useEffect(() => {
    apiActionCatalog()
      .then((res) => {
        setAllowed(new Set(res.allowed));
        setCatalog(Object.fromEntries(res.catalog.map((a) => [a.name, { label: a.label, description: a.description }])));
      })
      .catch(() => {
        setAllowed(new Set());
      });
  }, [session?.actor.id]);

  const visible = useMemo(() => actions.filter((a) => allowed.has(a)), [actions, allowed]);

  if (!session) return null;
  if (!session.canWrite) {
    return <InfoNote tone="warning">Read-only role: actions are disabled.</InfoNote>;
  }

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2 rounded-lg border border-hair bg-surface px-3 py-2.5 shadow-card">
        <span className="text-[11.5px] font-semibold uppercase tracking-wide text-faint">{label}</span>
        {visible.length === 0 ? <span className="text-[12.5px] text-faint">No actions available for this role</span> : null}
        {visible.map((name) => (
          <Button key={name} size="sm" variant="secondary" onClick={() => setOpen(name)} title={catalog[name]?.description}>
            {catalog[name]?.label ?? name}
          </Button>
        ))}
      </div>
      {lastResult?.message ? <InfoNote tone="success">{lastResult.message}</InfoNote> : null}
      {open ? (
        <ActionForm
          action={open}
          title={catalog[open]?.label ?? open}
          subtitle={catalog[open]?.description}
          defaults={defaults}
          users={session.users}
          documentPurposes={documentPurposes}
          open
          onClose={() => setOpen(null)}
          onDone={(res) => {
            setLastResult(res);
            setOpen(null);
          }}
          extraNote={notes[open]}
        />
      ) : null}
    </div>
  );
}

export function ActionButton({ action, label }: { action: string; label?: string }) {
  const { session } = useSession();
  const [open, setOpen] = useState(false);
  const [allowed, setAllowed] = useState<Set<string>>(new Set());
  const [meta, setMeta] = useState<{ label: string; description: string } | null>(null);

  useEffect(() => {
    apiActionCatalog()
      .then((res) => {
        setAllowed(new Set(res.allowed));
        const found = res.catalog.find((a) => a.name === action);
        setMeta(found ? { label: found.label, description: found.description } : null);
      })
      .catch(() => setAllowed(new Set()));
  }, [action]);

  if (!session?.canWrite || !allowed.has(action)) return null;

  return (
    <>
      <Button size="sm" onClick={() => setOpen(true)}>
        {label ?? meta?.label ?? action}
      </Button>
      <ActionForm
        action={action}
        title={meta?.label ?? action}
        subtitle={meta?.description}
        users={session.users}
        open={open}
        onClose={() => setOpen(false)}
        onDone={() => setOpen(false)}
      />
    </>
  );
}

export function useActionRunner() {
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ActionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const run = async (action: string, payload: Record<string, unknown> = {}) => {
    setBusy(true);
    setError(null);
    try {
      const res = await import("@/lib/client/api").then((m) => m.apiAction(action, payload));
      setResult(res);
      return res;
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed");
      throw e;
    } finally {
      setBusy(false);
    }
  };

  return { run, busy, result, error };
}
