"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { SessionProvider, useSession } from "./SessionProvider";
import { Badge, EmptyState, ToneDot } from "./ui";
import { Icon, type IconName } from "./icons";
import { apiSearch, type SearchResponse } from "@/lib/client/api";
import { DEPARTMENT_MAP } from "@/lib/domain/departments";

interface NavItem {
  href: string;
  label: string;
  module: string;
  icon: IconName;
  badge?: "tasks" | "notifications";
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

const NAV: NavGroup[] = [
  {
    label: "Overview",
    items: [
      { href: "/", label: "Management dashboard", module: "dashboard", icon: "home" },
      { href: "/journeys", label: "Journey maps & SOP stages", module: "dashboard", icon: "map" },
      { href: "/my-work", label: "My work", module: "tasks", icon: "check-square" },
    ],
  },
  {
    label: "Startup journey",
    items: [
      { href: "/startups", label: "Startups", module: "startups", icon: "rocket" },
      { href: "/applications", label: "Applications", module: "applications", icon: "file-text" },
      { href: "/screening", label: "Internal screening", module: "screening", icon: "bar-chart" },
      { href: "/bootcamp", label: "Prep Bootcamp", module: "bootcamp", icon: "graduation-cap" },
      { href: "/analyst", label: "Analyst screening", module: "analyst", icon: "search" },
      { href: "/mou", label: "MoU", module: "mou", icon: "pen" },
      { href: "/irr", label: "Investment Readiness Report", module: "irr", icon: "book" },
    ],
  },
  {
    label: "Investor journey",
    items: [
      { href: "/investors", label: "Investors", module: "investors", icon: "briefcase" },
      { href: "/matching", label: "Startup matching", module: "matching", icon: "link" },
      { href: "/pitches", label: "Virtual pitches", module: "pitches", icon: "mic" },
      { href: "/pitchday", label: "Pitch Day & Golden Pass", module: "pitchday", icon: "ticket" },
      { href: "/committee", label: "Final selection committee", module: "committee", icon: "scales" },
      { href: "/commitments", label: "Commitments & pre-shoot", module: "commitments", icon: "file-check" },
    ],
  },
  {
    label: "Funding & finance",
    items: [
      { href: "/deals", label: "Deals & closure", module: "deals", icon: "layers" },
      { href: "/deployment", label: "Deployment tracking", module: "deployment", icon: "bank" },
      { href: "/upfront-fees", label: "Upfront fee collection", module: "upfront_fees", icon: "receipt" },
      { href: "/success-fees", label: "Post-funding success fees", module: "success_fees", icon: "currency" },
    ],
  },
  {
    label: "Production & content",
    items: [
      { href: "/production", label: "AV, mock & main shoot", module: "production", icon: "clapperboard" },
      { href: "/episodes", label: "Episodes & editing", module: "episodes", icon: "film" },
      { href: "/telecast", label: "Telecast & promotions", module: "telecast", icon: "tv" },
    ],
  },
  {
    label: "Community",
    items: [
      { href: "/community", label: "Members", module: "community", icon: "users" },
      { href: "/events", label: "Events & engagement", module: "events", icon: "calendar" },
      { href: "/referrals", label: "Referrals", module: "referrals", icon: "sprout" },
      { href: "/support", label: "Founder support", module: "support", icon: "lifebuoy" },
    ],
  },
  {
    label: "Platform",
    items: [
      { href: "/tasks", label: "Tasks & escalations", module: "tasks", icon: "clipboard", badge: "tasks" },
      { href: "/handovers", label: "Handovers", module: "handovers", icon: "refresh" },
      { href: "/documents", label: "Document register", module: "documents", icon: "folder" },
      { href: "/policies", label: "Policies & configuration", module: "policies", icon: "settings" },
      { href: "/integrations", label: "Integrations & sync", module: "integrations", icon: "plug" },
      { href: "/audit", label: "Audit history", module: "audit", icon: "clock" },
      { href: "/admin", label: "Access & administration", module: "admin", icon: "shield" },
    ],
  },
];

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <Shell>{children}</Shell>
    </SessionProvider>
  );
}

function BrandLockup() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="grid h-8 w-8 shrink-0 place-items-center overflow-hidden rounded-md bg-white/95 ring-1 ring-white/15">
        <Image src="/singam-logo.png" alt="Startup Singam" width={26} height={22} className="h-5 w-auto" priority />
      </span>
      <p className="truncate text-[14px] font-semibold leading-tight text-white">Startup Singam</p>
    </div>
  );
}

/**
 * Season switcher.
 *
 * The show runs in numbered seasons and the same startup can apply in more than one, so the
 * whole app is scoped to one season at a time. This control is the single place the season
 * changes; every screen and the dashboard follow it.
 */
function SeasonSwitcher() {
  const { seasons, seasonId, season, switchSeason, loading } = useSession();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const close = () => setOpen(false);
    window.addEventListener("click", close);
    return () => window.removeEventListener("click", close);
  }, [open]);

  if (loading && seasons.length === 0) {
    return <div className="h-11 animate-pulse rounded-md bg-white/10" aria-hidden />;
  }
  if (seasons.length === 0) return null;

  return (
    <div className="relative" onClick={(e) => e.stopPropagation()}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Change season"
        className="flex w-full items-center gap-2 rounded-md border border-white/12 bg-white/[0.06] px-2.5 py-1.5 text-left transition hover:bg-white/[0.11]"
      >
        <Icon name="calendar" className="h-[15px] w-[15px] shrink-0 text-gold" />
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[13px] font-medium leading-tight text-white">
            {season ? season.name : "Season"}
          </span>
          <span className="block text-[10.5px] leading-tight text-side-muted">
            {season ? `${season.code} · ${season.status === "live" ? "live" : "closed"}` : ""}
          </span>
        </span>
        <Icon name={open ? "chevron-up" : "chevron-down"} className="h-3.5 w-3.5 shrink-0 text-side-muted" strokeWidth={2} />
      </button>

      {open ? (
        <ul
          role="listbox"
          aria-label="Seasons"
          className="absolute left-0 right-0 top-full z-50 mt-1 overflow-hidden rounded-md border border-hair bg-canvas py-1 shadow-overlay"
        >
          {[...seasons].reverse().map((s) => {
            const active = s.id === seasonId;
            return (
              <li key={s.id}>
                <button
                  type="button"
                  role="option"
                  aria-selected={active}
                  onClick={() => {
                    switchSeason(s.id);
                    setOpen(false);
                  }}
                  className={`flex w-full items-center gap-2 px-2.5 py-1.5 text-left text-[13px] transition ${
                    active ? "bg-brand-soft font-medium text-brand-ink" : "text-ink-soft hover:bg-hover hover:text-ink"
                  }`}
                >
                  <Icon name={active ? "check" : "calendar"} className="h-[14px] w-[14px] shrink-0" strokeWidth={2} />
                  <span className="min-w-0 flex-1 truncate">{s.name}</span>
                  <span className="font-mono text-[10.5px] text-faint">{s.code}</span>
                  {s.status === "live" ? (
                    <span className="rounded bg-ok-soft px-1 py-px text-[10px] font-semibold uppercase tracking-wide text-ok">
                      live
                    </span>
                  ) : null}
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const { session, loading, error, actorId, switchActor, canAccessModule } = useSession();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const groups = useMemo(
    () =>
      NAV.map((g) => ({ ...g, items: g.items.filter((i) => canAccessModule(i.module)) })).filter((g) => g.items.length > 0),
    [canAccessModule],
  );

  const department = session ? DEPARTMENT_MAP[session.actor.department] : null;
  const alertCount = session?.notifications.length ?? 0;

  const current = useMemo(() => {
    const all = NAV.flatMap((g) => g.items);
    return (
      all.find((i) => i.href === pathname) ??
      all
        .filter((i) => i.href !== "/" && pathname.startsWith(i.href))
        .sort((a, b) => b.href.length - a.href.length)[0] ??
      null
    );
  }, [pathname]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div className="flex h-screen overflow-hidden bg-canvas">
      <aside
        className={`ss-rail fixed inset-y-0 left-0 z-40 flex w-[252px] transform flex-col border-r border-black/20 transition-transform lg:static lg:h-screen lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="ss-rule h-[3px] w-full shrink-0" aria-hidden />
        <div className="flex h-14 shrink-0 items-center px-3">
          <Link href="/" onClick={() => setSidebarOpen(false)} className="min-w-0 rounded-md px-1 py-1 hover:bg-white/[0.06]">
            <BrandLockup />
          </Link>
        </div>
        <div className="shrink-0 px-3 pb-3">
          <SeasonSwitcher />
        </div>
        <nav className="min-h-0 flex-1 overflow-y-auto px-2 pb-3">
          {groups.map((group) => {
            const isCollapsed = collapsed[group.label];
            return (
              <div key={group.label} className="mb-0.5">
                <button
                  type="button"
                  onClick={() => setCollapsed((c) => ({ ...c, [group.label]: !c[group.label] }))}
                  aria-expanded={!isCollapsed}
                  className="ss-rail-group flex w-full items-center gap-1 rounded px-2 py-1.5 text-[11px] font-semibold uppercase tracking-[0.08em] transition hover:bg-white/[0.05]"
                >
                  <Icon name={isCollapsed ? "chevron-right" : "chevron-down"} className="h-3 w-3" strokeWidth={2} />
                  {group.label}
                </button>
                {isCollapsed ? null : (
                  <ul className="mt-0.5 space-y-px">
                    {group.items.map((item) => {
                      const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
                      return (
                        <li key={item.href}>
                          <Link
                            href={item.href}
                            onClick={() => setSidebarOpen(false)}
                            aria-current={active ? "page" : undefined}
                            className="ss-rail-link relative flex items-center gap-2.5 rounded-md px-2.5 py-[6px] text-[13.5px] transition"
                          >
                            {active ? <span className="absolute inset-y-1.5 left-0 w-[2.5px] rounded-full bg-brand" aria-hidden /> : null}
                            <Icon name={item.icon} className={`h-[16px] w-[16px] shrink-0 ${active ? "text-white" : ""}`} />
                            <span className="truncate">{item.label}</span>
                            {item.badge === "tasks" && session && alertCount > 0 ? (
                              <span className="ml-auto rounded-full bg-brand px-1.5 text-[10.5px] font-semibold leading-[18px] text-white">
                                {alertCount}
                              </span>
                            ) : null}
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            );
          })}
          {loading && groups.length === 0 ? <p className="px-2 text-[12px] text-side-muted">Loading navigation&hellip;</p> : null}
        </nav>
      </aside>

      {sidebarOpen ? (
        <button
          type="button"
          aria-label="Close navigation"
          onClick={() => setSidebarOpen(false)}
          className="fixed inset-0 z-30 bg-ink/20 lg:hidden"
        />
      ) : null}

      <div className="flex min-w-0 flex-1 flex-col lg:h-screen">
        <header className="sticky top-0 z-20 border-b border-hair bg-canvas/85 backdrop-blur">
          <div className="flex h-14 shrink-0 items-center gap-2 px-3 sm:px-5">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="rounded-md border border-hair-strong px-2 py-1.5 text-ink-soft transition hover:bg-hover lg:hidden"
              aria-label="Open navigation"
            >
              <Icon name="menu" className="h-[18px] w-[18px]" />
            </button>
            <nav className="hidden min-w-0 items-center gap-1.5 text-[13px] text-faint sm:flex" aria-label="Breadcrumb">
              <Link href="/" className="rounded px-1 py-0.5 transition hover:bg-hover hover:text-ink">
                Startup Singam
              </Link>
              {current && current.href !== "/" ? (
                <>
                  <span aria-hidden className="text-hair-strong">/</span>
                  <span className="truncate px-1 py-0.5 font-medium text-ink">{current.label}</span>
                </>
              ) : null}
            </nav>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="ml-auto flex items-center gap-2 rounded-md border border-hair-strong bg-surface px-2.5 py-1.5 text-[13px] text-faint transition hover:border-hair-strong hover:bg-hover hover:text-ink-soft sm:min-w-[280px]"
            >
              <Icon name="search" className="h-[15px] w-[15px]" />
              <span className="hidden truncate sm:inline">Search or jump to&hellip;</span>
              <kbd className="ml-auto hidden rounded border border-hair-strong bg-canvas px-1.5 py-0.5 font-sans text-[10.5px] text-faint sm:inline">
                ⌘K
              </kbd>
            </button>
            <div className="relative flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setNotificationsOpen((v) => !v)}
                aria-expanded={notificationsOpen}
                aria-label="Alerts"
                className="relative rounded-md border border-hair-strong bg-canvas px-2 py-1.5 text-ink-soft transition hover:bg-hover hover:text-ink"
              >
                <Icon name="bell" className="h-[17px] w-[17px]" />
                {alertCount > 0 ? (
                  <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-brand px-1 text-[10px] font-semibold text-white">
                    {alertCount}
                  </span>
                ) : null}
              </button>
              <label className="flex items-center gap-1.5 text-[12px] text-faint">
                <span className="hidden md:inline">Acting as</span>
                <select
                  value={actorId}
                  onChange={(e) => switchActor(e.target.value)}
                  className="max-w-[13rem] rounded-md border border-hair-strong bg-canvas px-2 py-1.5 text-[12.5px] text-ink transition hover:bg-hover"
                >
                  {(session?.users ?? []).map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} · {u.roleLabel}
                    </option>
                  ))}
                </select>
              </label>

              {notificationsOpen && session ? (
                <div className="absolute right-0 top-[calc(100%+0.5rem)] z-30 w-96 max-w-[calc(100vw-1.5rem)] rounded-lg border border-hair bg-canvas p-3 shadow-overlay">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-[13.5px] font-semibold text-ink">Alerts and notifications</p>
                    <button
                      type="button"
                      className="text-[12px] text-faint transition hover:text-ink"
                      onClick={() => setNotificationsOpen(false)}
                    >
                      Close
                    </button>
                  </div>
                  {session.notifications.length === 0 ? (
                    <EmptyState title="Nothing outstanding" hint="Alerts appear here when a deadline, fee or sync needs attention." />
                  ) : (
                    <ul className="max-h-80 space-y-1.5 overflow-y-auto">
                      {session.notifications.map((n) => (
                        <li key={String(n.id)} className="rounded-md border border-hair p-2 transition hover:bg-hover">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-[12.5px] font-medium text-ink">{String(n.title)}</p>
                            <Badge tone="warning">{String(n.recipient_role)}</Badge>
                          </div>
                          <p className="mt-1 text-[12px] text-ink-soft">{String(n.body)}</p>
                          <p className="mt-1 font-mono text-[10.5px] text-faint">
                            {String(n.entity_type)} / {String(n.entity_id)}
                          </p>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : null}
            </div>
          </div>
        </header>

        {session && !session.canWrite ? (
          <div className="flex items-center gap-2 border-b border-warn/25 bg-warn-soft px-4 py-2 text-[12.5px] text-warn">
            <ToneDot tone="warning" />
            Read-only role: {session.actor.role}. Mutating actions are disabled.
          </div>
        ) : null}

        <main className="min-h-0 min-w-0 flex-1 overflow-y-auto bg-surface px-4 py-6 sm:px-7">
          <div className="mx-auto max-w-[1240px]">
            {error ? (
              <div className="mb-4 flex items-center gap-2 rounded-md border border-risk/25 bg-risk-soft px-3 py-2 text-[13px] text-risk">
                <ToneDot tone="danger" />
                {error}
              </div>
            ) : null}
            {children}
            <footer className="mt-12 flex flex-wrap items-center gap-x-2 gap-y-1 border-t border-hair pt-5 text-[12px] text-faint">
              <span className="font-medium text-ink-soft">Startup Singam ERP</span>
              <span aria-hidden>·</span>
              <span>Simplify Fund Raise, Amplify Success Stories.</span>
              <span aria-hidden>·</span>
              <span>Selection, production, investment, community and finance are tracked separately by design.</span>
              {department ? (
                <>
                  <span aria-hidden>·</span>
                  <span>Current department: {department.label}.</span>
                </>
              ) : null}
            </footer>
          </div>
        </main>
      </div>

      {searchOpen ? <GlobalSearch onClose={() => setSearchOpen(false)} groups={groups} /> : null}
    </div>
  );
}

function GlobalSearch({ onClose, groups }: { onClose: () => void; groups: NavGroup[] }) {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<SearchResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  const navMatches = useMemo(() => {
    const q = query.trim().toLowerCase();
    const all = groups.flatMap((g) => g.items.map((i) => ({ ...i, group: g.label })));
    if (!q) return all;
    return all.filter((i) => i.label.toLowerCase().includes(q) || i.group.toLowerCase().includes(q));
  }, [groups, query]);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResult(null);
      return;
    }
    let cancelled = false;
    setBusy(true);
    const timer = setTimeout(() => {
      apiSearch(query)
        .then((r) => {
          if (!cancelled) setResult(r);
        })
        .catch(() => {
          if (!cancelled) setResult(null);
        })
        .finally(() => {
          if (!cancelled) setBusy(false);
        });
    }, 200);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  const go = (href: string) => {
    router.push(href);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-ink/25 p-4 sm:p-20" onClick={onClose}>
      <div
        className="w-full max-w-xl overflow-hidden rounded-lg border border-hair bg-canvas shadow-[0_16px_48px_rgba(15,15,15,0.18)]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 border-b border-hair px-3 py-2">
          <Icon name="search" className="h-[16px] w-[16px] text-faint" />
          <input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search records, or jump to a screen&hellip;"
            className="flex-1 border-0 bg-transparent px-1 py-1 text-[13.5px] text-ink outline-none placeholder:text-faint"
          />
          <button type="button" onClick={onClose} className="rounded border border-hair-strong px-1.5 py-0.5 text-[11px] text-faint">
            Esc
          </button>
        </div>
        <div className="max-h-[60vh] overflow-y-auto p-2">
          {navMatches.length > 0 ? (
            <div className="mb-1">
              <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-faint">Jump to</p>
              {navMatches.slice(0, query ? 6 : 40).map((i) => (
                <button
                  key={i.href}
                  type="button"
                  onClick={() => go(i.href)}
                  className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-[13.5px] text-ink-soft hover:bg-hover hover:text-ink"
                >
                  <Icon name={i.icon} className="h-[15px] w-[15px] text-faint" />
                  <span className="truncate">{i.label}</span>
                  <span className="ml-auto text-[11.5px] text-faint">{i.group}</span>
                </button>
              ))}
            </div>
          ) : null}

          {query.trim().length >= 2 ? (
            <div>
              <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-faint">Records</p>
              {busy ? <p className="px-2 py-2 text-[12.5px] text-faint">Searching&hellip;</p> : null}
              {result && result.results.length === 0 && !busy ? (
                <p className="px-2 py-2 text-[12.5px] text-faint">No records match &ldquo;{result.query}&rdquo;.</p>
              ) : null}
              {!busy &&
                (result?.results ?? []).map((r) => (
                  <button
                    key={`${r.entity}-${r.id}`}
                    type="button"
                    className="flex w-full items-center justify-between gap-3 rounded px-2 py-1.5 text-left hover:bg-hover"
                    onClick={() => go(`/records/${r.entity}/${r.id}`)}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-[13.5px] text-ink">{r.title}</span>
                      <span className="block text-[11.5px] text-faint">
                        {r.entityLabel} · {r.subtitle}
                      </span>
                    </span>
                    <span className="font-mono text-[10.5px] text-faint">{r.id}</span>
                  </button>
                ))}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
