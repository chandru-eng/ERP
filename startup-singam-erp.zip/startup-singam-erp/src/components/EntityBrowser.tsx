"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { apiList, type ListResponse } from "@/lib/client/api";
import { useSession } from "./SessionProvider";
import { Badge, Button, Card, EmptyState, Input, PageHeader, Select, Skeleton, StatusBadge, Table, Toaster, useToasts } from "./ui";

/**
 * Generic list screen.
 *
 * Columns are declared per screen; search, filters, paging and the status badge are
 * handled here, so a new list screen is a column definition plus a filter list.
 */

export interface ColumnSpec {
  key: string;
  label: string;
  render?: (row: Record<string, unknown>) => ReactNode;
  align?: "left" | "right";
}

export interface FilterSpec {
  column: string;
  label: string;
  options: { value: string; label: string }[];
}

interface EntityBrowserProps {
  entity: string;
  /** Access-control module; defaults to the entity key when they differ. */
  module?: string;
  title: string;
  description?: ReactNode;
  columns: ColumnSpec[];
  filters?: FilterSpec[];
  statusRegistry?: string;
  searchPlaceholder?: string;
  defaultFilters?: Record<string, string>;
  actions?: ReactNode;
  rowHref?: (row: Record<string, unknown>) => string | null;
  limit?: number;
  toolbar?: ReactNode;
  onRefreshRef?: (fn: () => void) => void;
}

export function EntityBrowser({
  entity,
  module,
  title,
  description,
  columns,
  filters = [],
  statusRegistry,
  searchPlaceholder = "Search\u2026",
  defaultFilters = {},
  actions,
  rowHref,
  limit = 100,
  toolbar,
  onRefreshRef,
}: EntityBrowserProps) {
  const { canAccessModule, seasonId } = useSession();
  const { toasts, dismiss } = useToasts();
  const [data, setData] = useState<ListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>(defaultFilters);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const result = await apiList(entity, { search, filters: activeFilters, limit });
      setData(result);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load records");
    } finally {
      setLoading(false);
    }
  }, [entity, search, activeFilters, limit]);

  useEffect(() => {
    const timer = setTimeout(() => void load(), 180);
    return () => clearTimeout(timer);
  }, [load, seasonId]);

  useEffect(() => {
    onRefreshRef?.(() => void load());
  }, [onRefreshRef, load]);

  const allColumns = useMemo(() => {
    if (!statusRegistry) return columns;
    return columns;
  }, [columns, statusRegistry]);

  if (!canAccessModule(module ?? entity)) {
    return (
      <Card title={title}>
        <InfoBlock />
      </Card>
    );
  }

  return (
    <div>
      <Toaster toasts={toasts} onDismiss={dismiss} />
      <PageHeader title={title} description={description} actions={actions} />

      <Card padded={false}>
        <div className="flex flex-wrap items-center gap-2 border-b border-hair bg-surface/60 px-3 py-2.5">
          <div className="min-w-[14rem] flex-1">
            <Input value={search} onChange={setSearch} placeholder={searchPlaceholder} />
          </div>
          {filters.map((f) => (
            <div key={f.column} className="w-48">
              <Select
                value={activeFilters[f.column] ?? ""}
                onChange={(v) => setActiveFilters((prev) => ({ ...prev, [f.column]: v }))}
                placeholder={`All ${f.label.toLowerCase()}`}
                options={f.options}
              />
            </div>
          ))}
          <Button variant="secondary" size="sm" onClick={() => void load()}>
            Refresh
          </Button>
          <span className="rounded-full bg-canvas px-2 py-0.5 text-[12px] font-medium tabular-nums text-faint ring-1 ring-hair">
            {data ? `${data.total} record${data.total === 1 ? "" : "s"}` : "\u2026"}
          </span>
          {toolbar}
        </div>

        {error ? (
          <div className="border-b border-risk/25 bg-risk-soft px-3 py-2 text-[13px] text-risk">{error}</div>
        ) : null}

        {loading && !data ? (
          <div className="px-4 py-6">
            <Skeleton rows={6} />
          </div>
        ) : (
          <Table
            columns={allColumns}
            rows={data?.items ?? []}
            empty="No records match the current filters"
            onRowClick={
              rowHref
                ? (row) => {
                    const href = rowHref(row);
                    if (href) window.location.assign(href);
                  }
                : undefined
            }
          />
        )}
      </Card>
    </div>
  );
}

function InfoBlock() {
  return (
    <EmptyState
      title="This module is not available for the acting role"
      hint="Switch the acting user in the header to see this module."
    />
  );
}

export function StatusCell({ registry, value }: { registry: string; value: unknown }) {
  return <StatusBadge registry={registry} value={value} />;
}

export function LinkCell({ entity, id, label }: { entity: string; id: unknown; label: string }) {
  if (!id) return <span className="text-faint">-</span>;
  return (
    <Link
      href={`/records/${entity}/${String(id)}`}
      className="font-medium text-navy underline decoration-navy/25 underline-offset-2 transition hover:decoration-navy"
    >
      {label}
    </Link>
  );
}

export function CountBadge({ value, tone = "neutral" }: { value: number; tone?: "neutral" | "danger" | "warning" | "success" }) {
  if (!value) return <span className="text-hair-strong">0</span>;
  return <Badge tone={tone}>{value}</Badge>;
}
