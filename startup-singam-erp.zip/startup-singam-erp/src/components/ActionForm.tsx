"use client";

import { useEffect, useMemo, useState } from "react";
import { apiAction, type ActionResult } from "@/lib/client/api";
import { formSpecFor, type FieldSpec } from "@/lib/client/forms";
import { toPaise, toRupees } from "@/lib/domain/money";
import { Button, Checkbox, Field, InfoNote, Input, Modal, Select, Textarea } from "./ui";

/**
 * Generic action form.
 *
 * Renders the fields declared for a named action, converts money between rupees (as typed)
 * and paise (as stored) and reports the action's own message back to the caller.
 */

interface ActionFormProps {
  action: string;
  title: string;
  subtitle?: string;
  defaults?: Record<string, unknown>;
  users?: { id: string; name: string; roleLabel: string }[];
  documentPurposes?: { key: string; label: string }[];
  open: boolean;
  onClose: () => void;
  onDone: (result: ActionResult) => void;
  extraNote?: string;
}

export function ActionForm({
  action,
  title,
  subtitle,
  defaults = {},
  users = [],
  documentPurposes = [],
  open,
  onClose,
  onDone,
  extraNote,
}: ActionFormProps) {
  const spec = useMemo(() => formSpecFor(action), [action]);
  const [values, setValues] = useState<Record<string, string | boolean>>({});
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ActionResult | null>(null);

  useEffect(() => {
    if (!open) return;
    const initial: Record<string, string | boolean> = {};
    for (const field of spec) {
      if (defaults[field.name] !== undefined) {
        initial[field.name] = field.type === "money" ? String(toRupees(Number(defaults[field.name]))) : String(defaults[field.name]);
      } else if (field.defaultValue !== undefined) {
        initial[field.name] = typeof field.defaultValue === "boolean" ? field.defaultValue : String(field.defaultValue);
      } else {
        initial[field.name] = field.type === "checkbox" ? false : "";
      }
    }
    setValues(initial);
    setError(null);
    setResult(null);
  }, [open, spec, defaults]);

  const setValue = (name: string, value: string | boolean) => setValues((prev) => ({ ...prev, [name]: value }));

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const payload: Record<string, unknown> = {};
      for (const field of spec) {
        const raw = values[field.name];
        if (field.type === "checkbox") {
          payload[field.name] = Boolean(raw);
          continue;
        }
        const text = String(raw ?? "");
        if (text === "" && !field.required) continue;
        if (field.required && text === "") throw new Error(`${field.label} is required`);
        if (field.type === "money" || field.type === "number") {
          const n = Number(text);
          if (Number.isNaN(n)) throw new Error(`${field.label} must be a number`);
          payload[field.name] = field.type === "money" ? toPaise(n) : n;
        } else if (field.type === "json") {
          payload[field.name] = JSON.parse(text) as unknown;
        } else {
          payload[field.name] = text;
        }
      }
      const res = await apiAction(action, payload);
      setResult(res);
      onDone(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Action failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      subtitle={subtitle}
      wide
      footer={
        result ? (
          <>
            <Button variant="secondary" onClick={onClose}>
              Close
            </Button>
          </>
        ) : (
          <>
            <Button variant="secondary" onClick={onClose} disabled={busy}>
              Cancel
            </Button>
            <Button onClick={submit} disabled={busy}>
              {busy ? "Working\u2026" : "Run action"}
            </Button>
          </>
        )
      }
    >
      {result ? (
        <div className="space-y-3">
          <InfoNote tone="success">{result.message ?? "Action completed"}</InfoNote>
          {result.data !== undefined && result.data !== null ? (
            <pre className="max-h-72 overflow-auto rounded-lg bg-ink p-3 font-mono text-[11px] leading-relaxed text-white/90">
              {JSON.stringify(result.data, null, 2)}
            </pre>
          ) : null}
        </div>
      ) : (
        <div className="space-y-3">
          {extraNote ? <InfoNote tone="info">{extraNote}</InfoNote> : null}
          {error ? <InfoNote tone="danger">{error}</InfoNote> : null}
          {spec.map((field) => (
            <ActionField
              key={field.name}
              field={field}
              value={values[field.name]}
              onChange={(v) => setValue(field.name, v)}
              users={users}
              documentPurposes={documentPurposes}
            />
          ))}
        </div>
      )}
    </Modal>
  );
}

function ActionField({
  field,
  value,
  onChange,
  users,
  documentPurposes,
}: {
  field: FieldSpec;
  value: string | boolean | undefined;
  onChange: (value: string | boolean) => void;
  users: { id: string; name: string; roleLabel: string }[];
  documentPurposes: { key: string; label: string }[];
}) {
  if (field.type === "checkbox") {
    return <Checkbox checked={Boolean(value)} onChange={onChange} label={field.label} />;
  }

  const options =
    field.name === "purpose" && field.options?.length === 0
      ? documentPurposes.map((d) => ({ value: d.key, label: d.label }))
      : field.options;

  return (
    <Field label={field.label} hint={field.hint} required={field.required}>
      {field.type === "textarea" || field.type === "json" ? (
        <Textarea
          value={String(value ?? "")}
          onChange={onChange}
          rows={field.type === "json" ? 6 : 3}
          placeholder={field.type === "json" ? '{"key": "value"}' : field.placeholder}
        />
      ) : field.type === "select" || field.type === "status" || field.type === "user" ? (
        <Select
          value={String(value ?? "")}
          onChange={onChange}
          placeholder={field.required ? undefined : "\u2014"}
          options={
            field.type === "user"
              ? users.map((u) => ({ value: u.id, label: `${u.name} (${u.roleLabel})` }))
              : (options ?? [])
          }
        />
      ) : (
        <Input
          value={String(value ?? "")}
          onChange={onChange}
          type={field.type === "date" ? "date" : field.type === "money" || field.type === "number" ? "number" : "text"}
          step={field.type === "money" ? 0.01 : undefined}
          placeholder={field.type === "money" ? "Amount in rupees" : field.placeholder}
        />
      )}
    </Field>
  );
}
