"use client";

import { useEffect, useId, useState, type ReactNode } from "react";
import { STATUS_REGISTRIES, type Tone } from "@/lib/domain/statuses";
import { compactINR, rupees } from "@/lib/domain/money";
import { formatDate, formatDateTime, relativeFromNow } from "@/lib/domain/dates";
import { Icon } from "./icons";

/* ------------------------------------------------------------------ */
/* Layout primitives                                                   */
/* ------------------------------------------------------------------ */

export function Breadcrumb({ items }: { items: { label: string; href?: string }[] }) {
  return (
    <nav className="flex flex-wrap items-center gap-1.5 text-[13px] text-faint" aria-label="Breadcrumb">
      {items.map((item, i) => (
        <span key={`${item.label}-${i}`} className="flex items-center gap-1.5">
          {i > 0 ? <span aria-hidden className="text-hair-strong">/</span> : null}
          {item.href ? (
            <a href={item.href} className="rounded px-1 py-0.5 hover:bg-hover hover:text-ink">
              {item.label}
            </a>
          ) : (
            <span className="px-1 py-0.5 text-ink-soft">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function PageHeader({
  title,
  description,
  actions,
  breadcrumb,
  icon,
}: {
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
  breadcrumb?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <header className="mb-6">
      {breadcrumb ? <div className="mb-3">{breadcrumb}</div> : null}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="flex items-center gap-2.5 text-[24px] font-semibold leading-tight tracking-[-0.02em] text-ink">
            {icon ? <span className="text-[21px] leading-none text-navy">{icon}</span> : null}
            {title}
          </h1>
          {description ? <p className="mt-2 max-w-3xl text-[13.5px] leading-relaxed text-ink-soft">{description}</p> : null}
        </div>
        {actions ? <div className="flex flex-wrap items-center gap-1.5">{actions}</div> : null}
      </div>
    </header>
  );
}

/**
 * A quiet panel. The work area groups content with headings and hairlines rather than
 * heavy cards, so the default is a light bordered surface with a soft elevation.
 */
export function Card({
  title,
  subtitle,
  actions,
  children,
  padded = true,
  className = "",
}: {
  title?: ReactNode;
  subtitle?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  padded?: boolean;
  className?: string;
}) {
  return (
    <section className={`overflow-hidden rounded-lg border border-hair bg-canvas shadow-card ${className}`}>
      {title || actions ? (
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-hair px-4 py-3">
          <div className="min-w-0">
            {title ? <h2 className="text-[14px] font-semibold tracking-[-0.005em] text-ink">{title}</h2> : null}
            {subtitle ? <p className="mt-0.5 text-[12.5px] text-faint">{subtitle}</p> : null}
          </div>
          {actions ? <div className="flex flex-wrap items-center gap-1.5">{actions}</div> : null}
        </div>
      ) : null}
      <div className={padded ? "p-4" : ""}>{children}</div>
    </section>
  );
}

export function SectionTitle({ children, hint, actions }: { children: ReactNode; hint?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-2.5 flex flex-wrap items-baseline justify-between gap-2">
      <h3 className="text-[13px] font-semibold uppercase tracking-wide text-faint">{children}</h3>
      {hint ? <span className="text-[12.5px] text-faint">{hint}</span> : null}
      {actions ? <div className="flex items-center gap-1.5">{actions}</div> : null}
    </div>
  );
}

const TONE_ACCENT: Record<Tone, string> = {
  neutral: "bg-hair-strong",
  info: "bg-navy",
  progress: "bg-brand",
  success: "bg-ok",
  warning: "bg-gold",
  danger: "bg-risk",
};

export function Stat({
  label,
  value,
  hint,
  tone = "neutral",
  onClick,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: Tone;
  onClick?: () => void;
}) {
  const Tag = onClick ? "button" : "div";
  return (
    <Tag
      type={onClick ? "button" : undefined}
      onClick={onClick}
      className={`group relative w-full overflow-hidden rounded-lg border border-hair bg-canvas px-3.5 py-3 text-left shadow-card transition ${
        onClick ? "hover:-translate-y-px hover:border-hair-strong hover:shadow-raised" : ""
      }`}
    >
      <span className={`absolute inset-y-0 left-0 w-[3px] ${TONE_ACCENT[tone]}`} aria-hidden />
      <div className="text-[11.5px] font-medium uppercase tracking-[0.05em] text-faint">{label}</div>
      <div className="mt-1 text-[21px] font-semibold leading-none tracking-[-0.02em] tabular-nums text-ink">{value}</div>
      {hint ? <div className="mt-1.5 text-[12px] text-ink-soft">{hint}</div> : null}
    </Tag>
  );
}

export function ProgressBar({ value, tone = "progress" }: { value: number; tone?: Tone }) {
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-hair">
      <div
        className={`h-full rounded-full ${TONE_ACCENT[tone]}`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="rounded-md border border-dashed border-hair-strong bg-surface px-4 py-8 text-center">
      <p className="text-[13.5px] font-medium text-ink-soft">{title}</p>
      {hint ? <p className="mx-auto mt-1 max-w-md text-[12.5px] text-faint">{hint}</p> : null}
      {action ? <div className="mt-3 flex justify-center">{action}</div> : null}
    </div>
  );
}

export function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="h-4 animate-pulse rounded bg-hover" style={{ width: `${70 + ((i * 37) % 30)}%` }} />
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Status and badges                                                   */
/* ------------------------------------------------------------------ */

const TONE_TAG: Record<Tone, string> = {
  neutral: "bg-hover text-ink-soft",
  info: "bg-navy-soft text-navy",
  progress: "bg-brand-soft text-brand-ink",
  success: "bg-ok-soft text-ok",
  warning: "bg-warn-soft text-warn",
  danger: "bg-risk-soft text-risk",
};

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: Tone }) {
  return (
    <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded px-1.5 py-[2px] text-[12px] font-medium leading-tight ${TONE_TAG[tone]}`}>
      {children}
    </span>
  );
}

export function StatusBadge({ registry, value }: { registry: string; value: unknown }) {
  if (value === null || value === undefined || value === "") return <span className="text-faint">-</span>;
  const reg = STATUS_REGISTRIES[registry];
  const meta = reg?.[String(value)];
  return <Badge tone={(meta?.tone ?? "neutral") as Tone}>{meta?.label ?? String(value).replace(/_/g, " ")}</Badge>;
}

export function ToneDot({ tone }: { tone: Tone }) {
  return <span className={`inline-block h-[7px] w-[7px] shrink-0 rounded-full ${TONE_ACCENT[tone]}`} />;
}

export function Pill({ children, active, onClick }: { children: ReactNode; active?: boolean; onClick?: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-2.5 py-0.5 text-[12.5px] font-medium transition ${
        active ? "bg-ink text-white" : "bg-hover text-ink-soft hover:bg-hair-strong hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}

export function Tag({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded bg-hover px-1.5 py-[2px] font-mono text-[11.5px] text-ink-soft">{children}</span>
  );
}

/* ------------------------------------------------------------------ */
/* Money and dates                                                     */
/* ------------------------------------------------------------------ */

export function Money({ paise, compact = false }: { paise: unknown; compact?: boolean }) {
  const value = Number(paise ?? 0);
  if (!Number.isFinite(value)) return <span>-</span>;
  return <span className="tabular-nums">{compact ? compactINR(value) : rupees(value)}</span>;
}

export function DateText({ value, relative = false }: { value: unknown; relative?: boolean }) {
  if (!value) return <span className="text-faint">-</span>;
  const text = String(value);
  if (relative) {
    const overdue = text.split("T")[0] < new Date().toISOString().slice(0, 10);
    return <span className={overdue ? "font-medium text-risk" : ""}>{relativeFromNow(text)}</span>;
  }
  return <span className="tabular-nums">{text.includes("T") ? formatDateTime(text) : formatDate(text)}</span>;
}

export function Bool({ value }: { value: unknown }) {
  const on = value === 1 || value === true || value === "1";
  return on ? <Badge tone="success">Yes</Badge> : <Badge tone="neutral">No</Badge>;
}

/* ------------------------------------------------------------------ */
/* Controls                                                            */
/* ------------------------------------------------------------------ */

export function Button({
  children,
  onClick,
  variant = "primary",
  size = "md",
  disabled,
  type = "button",
  title,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "success";
  size?: "sm" | "md";
  disabled?: boolean;
  type?: "button" | "submit";
  title?: string;
}) {
  const variants = {
    primary: "bg-navy text-white shadow-card hover:bg-navy-dark disabled:bg-hair-strong disabled:text-faint disabled:shadow-none",
    secondary: "border border-hair-strong bg-canvas text-ink shadow-card hover:bg-hover disabled:text-faint disabled:shadow-none",
    ghost: "text-ink-soft hover:bg-hover hover:text-ink",
    danger: "bg-risk text-white shadow-card hover:brightness-110 disabled:bg-hair-strong disabled:text-faint disabled:shadow-none",
    success: "bg-ok text-white shadow-card hover:brightness-110 disabled:bg-hair-strong disabled:text-faint disabled:shadow-none",
  } as const;
  return (
    <button
      type={type}
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-1.5 rounded-md font-medium transition disabled:cursor-not-allowed ${
        size === "sm" ? "px-2.5 py-1 text-[12.5px]" : "px-3 py-1.5 text-[13.5px]"
      } ${variants[variant]}`}
    >
      {children}
    </button>
  );
}

export function Field({
  label,
  hint,
  required,
  children,
}: {
  label: string;
  hint?: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[12.5px] font-medium text-ink-soft">
        {label}
        {required ? <span className="ml-0.5 text-risk">*</span> : null}
      </span>
      {children}
      {hint ? <span className="mt-1 block text-[11.5px] text-faint">{hint}</span> : null}
    </label>
  );
}

const inputClass =
  "w-full rounded-md border border-hair-strong bg-canvas px-2.5 py-1.5 text-[13.5px] text-ink shadow-card transition placeholder:text-faint focus:border-navy focus:outline-none focus:ring-2 focus:ring-navy/15 disabled:bg-surface disabled:text-faint";

export function Input({
  value,
  onChange,
  placeholder,
  type = "text",
  disabled,
  min,
  step,
}: {
  value: string | number;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  disabled?: boolean;
  min?: number;
  step?: number;
}) {
  return (
    <input
      className={inputClass}
      value={value ?? ""}
      type={type}
      min={min}
      step={step}
      disabled={disabled}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

export function Textarea({
  value,
  onChange,
  rows = 3,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  rows?: number;
  placeholder?: string;
}) {
  return (
    <textarea
      className={inputClass}
      rows={rows}
      value={value ?? ""}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}

export function Select({
  value,
  onChange,
  options,
  placeholder,
  disabled,
}: {
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  placeholder?: string;
  disabled?: boolean;
}) {
  return (
    <select className={inputClass} value={value ?? ""} disabled={disabled} onChange={(e) => onChange(e.target.value)}>
      {placeholder !== undefined ? <option value="">{placeholder}</option> : null}
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function Checkbox({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (value: boolean) => void;
  label: string;
}) {
  return (
    <label className="flex items-center gap-2 text-[13.5px] text-ink">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-[15px] w-[15px] rounded border-hair-strong"
      />
      {label}
    </label>
  );
}

export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { key: string; label: string; count?: number }[];
  active: string;
  onChange: (key: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-0.5 border-b border-hair" role="tablist">
      {tabs.map((t) => (
        <button
          key={t.key}
          type="button"
          role="tab"
          aria-selected={active === t.key}
          onClick={() => onChange(t.key)}
          className={`-mb-px border-b-2 px-3 py-2 text-[13.5px] font-medium transition ${
            active === t.key
              ? "border-navy text-navy"
              : "border-transparent text-faint hover:border-hair-strong hover:text-ink-soft"
          }`}
        >
          {t.label}
          {t.count !== undefined ? <span className="ml-1.5 text-[12px] text-faint">{t.count}</span> : null}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Overlays                                                            */
/* ------------------------------------------------------------------ */

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
  footer,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-ink/30 p-4 backdrop-blur-[1px] sm:p-10">
      <div
        className={`w-full ${wide ? "max-w-4xl" : "max-w-2xl"} overflow-hidden rounded-xl border border-hair bg-canvas shadow-overlay`}
      >
        <div className="flex items-start justify-between gap-4 border-b border-hair px-5 py-3.5">
          <div>
            <h2 className="text-[15px] font-semibold tracking-[-0.005em] text-ink">{title}</h2>
            {subtitle ? <p className="mt-0.5 text-[12.5px] text-faint">{subtitle}</p> : null}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1 text-faint transition hover:bg-hover hover:text-ink"
            aria-label="Close"
          >
            <Icon name="x" className="h-[16px] w-[16px]" strokeWidth={2} />
          </button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-5 py-4">{children}</div>
        {footer ? (
          <div className="flex flex-wrap items-center justify-end gap-2 border-t border-hair bg-surface/60 px-5 py-3.5">{footer}</div>
        ) : null}
      </div>
    </div>
  );
}

export interface ToastMessage {
  id: number;
  text: string;
  tone: "success" | "danger" | "info";
}

export function Toaster({ toasts, onDismiss }: { toasts: ToastMessage[]; onDismiss: (id: number) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-80 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="pointer-events-auto flex items-start justify-between gap-3 rounded-md border border-hair bg-canvas px-3 py-2 text-[13px] shadow-[0_8px_24px_rgba(15,15,15,0.12)]"
        >
          <span className="flex items-start gap-2">
            <ToneDot tone={t.tone === "success" ? "success" : t.tone === "danger" ? "danger" : "info"} />
            <span className="text-ink">{t.text}</span>
          </span>
          <button type="button" onClick={() => onDismiss(t.id)} className="text-faint hover:text-ink" aria-label="Dismiss">
            &#10005;
          </button>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Data display                                                        */
/* ------------------------------------------------------------------ */

export function KeyValue({ items }: { items: { label: string; value: ReactNode; hint?: string }[] }) {
  return (
    <dl className="divide-y divide-hair">
      {items.map((item) => (
        <div key={item.label} className="grid grid-cols-1 gap-1 py-2 sm:grid-cols-[minmax(9rem,14rem)_1fr] sm:gap-4">
          <dt className="text-[12.5px] text-faint">{item.label}</dt>
          <dd className="min-w-0 break-words text-[13.5px] text-ink">
            {item.value ?? "-"}
            {item.hint ? <span className="mt-0.5 block text-[11.5px] text-faint">{item.hint}</span> : null}
          </dd>
        </div>
      ))}
    </dl>
  );
}

export function Table({
  columns,
  rows,
  onRowClick,
  empty = "No records",
  dense,
}: {
  columns: { key: string; label: string; render?: (row: Record<string, unknown>) => ReactNode; align?: "left" | "right" }[];
  rows: Record<string, unknown>[];
  onRowClick?: (row: Record<string, unknown>) => void;
  empty?: string;
  dense?: boolean;
}) {
  if (rows.length === 0) {
    return <div className="px-4 py-10 text-center text-[13px] text-faint">{empty}</div>;
  }
  return (
    <div className="overflow-x-auto">
      <table className="ss-table w-full border-collapse text-[13.5px]">
        <thead>
          <tr className="border-b border-hair text-left">
            {columns.map((c) => (
              <th
                key={c.key}
                className={`whitespace-nowrap px-3 py-2 text-[11.5px] font-semibold uppercase tracking-[0.04em] text-faint ${
                  c.align === "right" ? "text-right" : ""
                }`}
              >
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={String(row.id ?? i)}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              className={`border-b border-hair last:border-0 transition ${
                onRowClick ? "cursor-pointer hover:bg-hover" : "hover:bg-surface"
              }`}
            >
              {columns.map((c) => (
                <td
                  key={c.key}
                  className={`px-3 ${dense ? "py-1.5" : "py-2.5"} align-top text-ink-soft ${c.align === "right" ? "text-right" : ""}`}
                >
                  {c.render ? c.render(row) : defaultCell(row[c.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function defaultCell(value: unknown): ReactNode {
  if (value === null || value === undefined || value === "") return <span className="text-faint">-</span>;
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (typeof value === "object") return <span className="font-mono text-[11.5px]">{JSON.stringify(value)}</span>;
  const text = String(value);
  if (text.length > 120) return <span title={text}>{text.slice(0, 120)}&hellip;</span>;
  return text;
}

export function useToasts() {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const push = (text: string, tone: ToastMessage["tone"] = "success") => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { id, text, tone }]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 6000);
  };
  const dismiss = (id: number) => setToasts((prev) => prev.filter((t) => t.id !== id));
  return { toasts, push, dismiss };
}

export function useHash(initial: string): [string, (v: string) => void] {
  const [value, setValue] = useState(initial);
  return [value, setValue];
}

export function JsonBlock({ value }: { value: unknown }) {
  const text = typeof value === "string" ? value : JSON.stringify(value, null, 2);
  let pretty = text;
  try {
    pretty = JSON.stringify(JSON.parse(text), null, 2);
  } catch {
    pretty = text;
  }
  return (
    <pre className="max-h-64 overflow-auto rounded-md bg-ink p-3 font-mono text-[11.5px] leading-relaxed text-white/90">
      {pretty}
    </pre>
  );
}

export function InfoNote({ children, tone = "info" }: { children: ReactNode; tone?: Tone }) {
  const tones: Record<Tone, string> = {
    neutral: "border-hair bg-surface text-ink-soft",
    info: "border-navy/20 bg-navy-soft text-navy",
    progress: "border-brand/20 bg-brand-soft text-brand-ink",
    success: "border-ok/25 bg-ok-soft text-ok",
    warning: "border-warn/25 bg-warn-soft text-warn",
    danger: "border-risk/25 bg-risk-soft text-risk",
  };
  return <div className={`rounded-md border px-3 py-2 text-[12.5px] leading-relaxed ${tones[tone]}`}>{children}</div>;
}

export function BrandHero({
  eyebrow,
  title,
  tagline,
  children,
}: {
  eyebrow?: string;
  title: string;
  tagline?: string;
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden rounded-md border border-hair bg-surface px-5 py-5">
      <div className="ss-rule absolute inset-y-0 left-0 w-1" aria-hidden />
      {eyebrow ? <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-faint">{eyebrow}</p> : null}
      <h1 className="mt-1 text-[22px] font-semibold tracking-[-0.01em] text-ink">{title}</h1>
      {tagline ? <p className="mt-1.5 max-w-2xl text-[13.5px] text-ink-soft">{tagline}</p> : null}
      {children ? <div className="mt-4">{children}</div> : null}
    </section>
  );
}

export function Accordion({ title, children, defaultOpen }: { title: ReactNode; children: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(Boolean(defaultOpen));
  const id = useId();
  return (
    <div className="rounded-md border border-hair">
      <button
        type="button"
        aria-expanded={open}
        aria-controls={id}
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-[13.5px] font-medium text-ink hover:bg-hover"
      >
        <span className="flex items-center gap-2">
          <span className="text-faint" aria-hidden>
            {open ? "▾" : "▸"}
          </span>
          {title}
        </span>
      </button>
      {open ? (
        <div id={id} className="border-t border-hair px-3 py-3">
          {children}
        </div>
      ) : null}
    </div>
  );
}
