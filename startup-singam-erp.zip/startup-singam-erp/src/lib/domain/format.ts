/** Column and field keys are snake_case identifiers; screens show them as sentence-case labels. */
export function humanise(key: string): string {
  return key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
