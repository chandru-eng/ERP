import { all } from "../db/client";
import { roleCanAccessModule, roleCanWrite, ROLE_MAP } from "../domain/rbac";
import type { Actor } from "./repo";
import { currentSeasonId, seasonFromRequest } from "./season";

/**
 * Session handling.
 *
 * The app selects an acting user through the `x-actor` request header (or the `actor` query
 * parameter) so every role and its restrictions can be demonstrated from the UI. The acting
 * user is resolved against the `users` table, so role permissions behave exactly as they would
 * after a real login.
 */

export const DEFAULT_ACTOR = "U-MGMT";

export interface Session {
  actor: Actor;
  canWrite: boolean;
  /** Season the request is scoped to; new records are written into it. */
  seasonId: string;
}

export function resolveActor(requestedId?: string | null): Session {
  const users = all<Record<string, unknown>>("SELECT * FROM users WHERE active = 1 ORDER BY name");
  const wanted = requestedId || DEFAULT_ACTOR;
  const found = users.find((u) => u.id === wanted) ?? users.find((u) => u.id === DEFAULT_ACTOR) ?? users[0];
  const actor: Actor = {
    id: String(found.id),
    name: String(found.name),
    role: String(found.role),
    department: String(found.department),
  };
  return { actor, canWrite: roleCanWrite(actor.role), seasonId: currentSeasonId() };
}

export function actorFromRequest(request: Request): Session {
  const url = new URL(request.url);
  const header = request.headers.get("x-actor");
  const session = resolveActor(header ?? url.searchParams.get("actor"));
  // The acting season travels on the request so actions create rows in the season the
  // user is looking at, never in a hard-coded one.
  return { ...session, seasonId: seasonFromRequest(request) };
}

export function listUsers(): { id: string; name: string; role: string; department: string; roleLabel: string }[] {
  return all<Record<string, unknown>>("SELECT * FROM users WHERE active = 1 ORDER BY department, name").map((u) => ({
    id: String(u.id),
    name: String(u.name),
    role: String(u.role),
    department: String(u.department),
    roleLabel: ROLE_MAP[String(u.role)]?.label ?? String(u.role),
  }));
}

export function assertModuleAccess(session: Session, module: string): void {
  if (session.actor.role === "admin") return;
  if (!roleCanAccessModule(session.actor.role, module)) {
    throw new HttpError(403, `Role ${session.actor.role} cannot access the ${module} module`);
  }
}

export function assertWrite(session: Session): void {
  if (!session.canWrite) throw new HttpError(403, "This role has read-only access");
}

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}
