import { ACTIONS_A, type ActionContext, type ActionHandler } from "./actions";
import { ACTIONS_B } from "./actions-b";
import { ACTIONS_C } from "./actions-c";
import { HttpError } from "./session";

/**
 * Action registry.
 *
 * Every named business action lives here. The API route looks an action up by name and
 * runs it, which keeps the workflows out of the transport layer.
 */

export const ACTIONS: Record<string, ActionHandler> = {
  ...ACTIONS_A,
  ...ACTIONS_B,
  ...ACTIONS_C,
};

export interface ActionDescriptor {
  name: string;
  group: string;
  label: string;
  description: string;
  /** Roles allowed to run the action. Management and Admin always may. */
  roles: string[];
}

export const ACTION_CATALOG: ActionDescriptor[] = [
  { name: "application.draft", group: "Startup journey", label: "Create draft application", description: "Save-and-resume draft with stage-appropriate mandatory fields.", roles: ["startup_relationship_manager", "community"] },
  { name: "application.submit", group: "Startup journey", label: "Submit application", description: "Acknowledgement, duplicate link and relationship-manager assignment; moves into screening.", roles: ["startup_relationship_manager"] },
  { name: "screening.score", group: "Startup journey", label: "Score screening (100 marks)", description: "Applies the qualifying rule and records the outcome.", roles: ["startup_relationship_manager", "analyst"] },
  { name: "bootcamp.invite", group: "Startup journey", label: "Invite to Prep Bootcamp", description: "Records the invitation and starts the attendance clock.", roles: ["startup_relationship_manager"] },
  { name: "bootcamp.record", group: "Startup journey", label: "Record bootcamp preparation", description: "Records attendance and session completion; readiness requires every session.", roles: ["startup_relationship_manager"] },
  { name: "analyst.evaluate", group: "Startup journey", label: "Record analyst evaluation", description: "Indicative willingness to invest stays separate from a commitment.", roles: ["analyst", "startup_relationship_manager"] },
  { name: "mou.share", group: "Startup journey", label: "Share MoU", description: "Starts the review clock and sets the AMA and signing deadlines.", roles: ["startup_relationship_manager", "legal"] },
  { name: "mou.record_ama", group: "Startup journey", label: "Record Legal AMA", description: "Marks the fourth-working-day Legal AMA as done.", roles: ["legal", "startup_relationship_manager"] },
  { name: "mou.respond", group: "Startup journey", label: "Record MoU response", description: "Proceed, Negotiate or Discontinue; negotiation escalates to Management.", roles: ["startup_relationship_manager", "legal"] },
  { name: "irr.request", group: "Startup journey", label: "Request IRR", description: "Startup Relationships initiates the IRR request after MoU signing.", roles: ["startup_relationship_manager"] },
  { name: "irr.advance", group: "Startup journey", label: "Advance IRR", description: "Accept the handover, send the checklist, prepare, review, approve or share with IR.", roles: ["finance", "management"] },

  { name: "investor.create", group: "Investor journey", label: "Create investor", description: "Investor record with category, source, thesis and allocation.", roles: ["investor_relations", "community"] },
  { name: "investor.verify", group: "Investor journey", label: "Verify investor", description: "Checks the eligibility policy before marking verified.", roles: ["investor_relations"] },
  { name: "investor.grade", group: "Investor journey", label: "Grade investor (L1-L4)", description: "Records dimension scores, evidence, permitted engagement and panel role.", roles: ["investor_relations", "management"] },
  { name: "investor.agreement", group: "Investor journey", label: "Record investor agreement", description: "Checks the mandatory document set for the investor category.", roles: ["investor_relations", "legal"] },
  { name: "match.suggest", group: "Investor journey", label: "Suggest matches", description: "Scores every eligible investor; the system recommends only.", roles: ["investor_relations"] },
  { name: "match.approve", group: "Investor journey", label: "Approve for circulation", description: "Investor Relations approves circulation.", roles: ["investor_relations"] },
  { name: "match.share", group: "Investor journey", label: "Share information", description: "Records the version shared with the investor.", roles: ["investor_relations"] },
  { name: "match.respond", group: "Investor journey", label: "Record investor response", description: "Ready to Invest, Ready to Proceed, Information Requested, Pass or No Response.", roles: ["investor_relations"] },
  { name: "pitch.schedule", group: "Investor journey", label: "Schedule virtual pitch", description: "Five minutes of pitch and five minutes of Q&A.", roles: ["investor_relations"] },
  { name: "pitch.record", group: "Investor journey", label: "Record pitch response", description: "Attendance, questions, responses and the SOP response option.", roles: ["investor_relations"] },
  { name: "pitchday.record", group: "Investor journey", label: "Record Pitch Day", description: "One-to-one slots, IRR and IM distribution, follow-on interest.", roles: ["investor_relations"] },
  { name: "pitchday.golden_pass", group: "Investor journey", label: "Issue Golden Pass", description: "Initial interest only; never treated as a written commitment.", roles: ["investor_relations"] },
  { name: "committee.decide", group: "Investor journey", label: "Record committee outcome", description: "Compiles the pack and records Proceed, On Hold or Rejected.", roles: ["management"] },
  { name: "preshoot.confirm", group: "Investor journey", label: "Confirm pre-shoot panel", description: "Raises an alert when the two-week IRR deadline is at risk.", roles: ["investor_relations"] },
  { name: "commitment.confirm", group: "Investor journey", label: "Confirm commitment", description: "Marks a written commitment as confirmed.", roles: ["investor_relations"] },
  { name: "commitment.revise", group: "Investor journey", label: "Revise commitment", description: "Creates a revised record and preserves the original with the reason.", roles: ["investor_relations"] },
  { name: "commitment.withdraw", group: "Investor journey", label: "Withdraw commitment", description: "Records the withdrawal with a reason.", roles: ["investor_relations"] },

  { name: "upfront.initiate", group: "Finance", label: "Initiate upfront fee", description: "Calculates the fee from turnover on the approved schedule.", roles: ["finance", "startup_relationship_manager"] },
  { name: "upfront.approve", group: "Finance", label: "Approve applicable fee", description: "Management approves the fee and any exception.", roles: ["management"] },
  { name: "upfront.invoice", group: "Finance", label: "Issue invoice", description: "Raises the invoice and notifies the founder.", roles: ["finance"] },
  { name: "upfront.record_receipt", group: "Finance", label: "Verify and allocate receipt", description: "A payment screenshot alone never marks an invoice paid.", roles: ["finance"] },
  { name: "upfront.extension", group: "Finance", label: "Approve extension", description: "Preserves the original due date for ageing.", roles: ["management"] },
  { name: "upfront.waive", group: "Finance", label: "Waive fee", description: "Waiver with a recorded reason.", roles: ["management"] },
  { name: "upfront.dispute", group: "Finance", label: "Mark disputed", description: "Records a dispute and the reason.", roles: ["finance"] },
  { name: "upfront.refund", group: "Finance", label: "Process refund", description: "Refund with a credit note reference.", roles: ["management", "finance"] },

  { name: "deal.open", group: "Deal closure", label: "Open deal", description: "Deal confirmation, one closure owner and the 48-hour communication thread.", roles: ["investor_relations"] },
  { name: "deal.advance", group: "Deal closure", label: "Advance deal", description: "Term sheet, diligence, agreements, conditions, transfer, verification, allotment.", roles: ["investor_relations", "legal"] },
  { name: "deal.document", group: "Deal closure", label: "Record deal document", description: "The purpose drives the requirement, not the document title.", roles: ["legal", "investor_relations"] },
  { name: "tranche.schedule", group: "Deal closure", label: "Schedule tranche", description: "Adds a tranche to the funding round.", roles: ["investor_relations", "finance"] },
  { name: "tranche.report", group: "Deal closure", label: "Record investor-reported transfer", description: "Reported is not verified.", roles: ["investor_relations", "finance"] },
  { name: "tranche.confirm_receipt", group: "Deal closure", label: "Record startup confirmation", description: "Startup confirms the receipt.", roles: ["finance"] },
  { name: "tranche.verify", group: "Deal closure", label: "Verify tranche", description: "Verifies the amount, names the verifier and triggers the success fee.", roles: ["finance"] },
  { name: "tranche.reverse", group: "Deal closure", label: "Reverse tranche", description: "Links the reversal to the original tranche instead of editing it.", roles: ["finance"] },
  { name: "successfee.calculate", group: "Finance", label: "Calculate success fee", description: "Recomputes from verified deployment only.", roles: ["finance"] },
  { name: "successfee.invoice", group: "Finance", label: "Invoice success fee", description: "Applies discounts, waivers, partner settlements and any contractual upfront adjustment.", roles: ["finance"] },
  { name: "successfee.collect", group: "Finance", label: "Collect success fee", description: "Closure means the account reconciles.", roles: ["finance"] },
  { name: "ledger.add", group: "Finance", label: "Add ledger entry", description: "Manual charge, credit, tax, withholding or adjustment.", roles: ["finance"] },

  { name: "production.handover", group: "Production", label: "Raise production handover", description: "Advance notification is separate from the payment-cleared handover.", roles: ["production", "management", "startup_relationship_manager"] },
  { name: "production.accept", group: "Production", label: "Accept handover", description: "Blocked until payment is cleared.", roles: ["production"] },
  { name: "av.update", group: "Production", label: "Update AV shoot", description: "Story research, location, crew, schedule, shot requirements and assets.", roles: ["production"] },
  { name: "mock.update", group: "Production", label: "Update mock shoot", description: "Costumes, pitch revisions, demo readiness, rehearsal and final readiness.", roles: ["production"] },
  { name: "mainshoot.update", group: "Production", label: "Update main shoot", description: "Attendance, live ask and offers, accepted terms, allocations and signatures.", roles: ["production"] },

  { name: "episode.update", group: "Content", label: "Update episode", description: "Editing and approvals.", roles: ["production", "marketing"] },
  { name: "telecast.update", group: "Content", label: "Update telecast", description: "Notification, promotions, telecast, feedback and the public announcement.", roles: ["marketing"] },

  { name: "community.member_create", group: "Community", label: "Create community member", description: "One person record with several roles; confidential access is withheld.", roles: ["community"] },
  { name: "community.member_add_role", group: "Community", label: "Add member role", description: "Adds a role to the same person record.", roles: ["community"] },
  { name: "event.create", group: "Community", label: "Create event", description: "Purpose, owner and budget.", roles: ["community"] },
  { name: "event.register", group: "Community", label: "Register or record attendance", description: "Recalculates the event counts.", roles: ["community"] },
  { name: "event.complete", group: "Community", label: "Complete event", description: "Outcomes, follow-up tasks and feedback.", roles: ["community"] },
  { name: "referral.create", group: "Community", label: "Record referral", description: "Links to the existing startup record; keeps source and contributors separate.", roles: ["community"] },
  { name: "referral.advance", group: "Community", label: "Advance referral", description: "Qualified, engaged, converted or dropped with an outcome.", roles: ["community"] },
  { name: "support.create", group: "Community", label: "Create support request", description: "Owner, deadline and SLA from the community policy.", roles: ["community"] },
  { name: "support.resolve", group: "Community", label: "Close support request", description: "Outcome and founder feedback.", roles: ["community"] },

  { name: "task.create", group: "Platform", label: "Create task", description: "Owner, due date, required output, evidence, approver and next action.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "task.update", group: "Platform", label: "Update task", description: "Progress, evidence and completion.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "task.escalate", group: "Platform", label: "Escalate task", description: "Escalates to Management with a reason.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "handover.create", group: "Platform", label: "Raise handover", description: "Accepted handovers between teams.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "handover.accept", group: "Platform", label: "Accept or reject handover", description: "Rejection requires a reason.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "document.create", group: "Platform", label: "Record document", description: "Purpose-driven versioning; earlier versions are preserved.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
  { name: "document.verify", group: "Platform", label: "Verify document", description: "Marks a document verified.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "legal"] },
  { name: "policy.revise", group: "Platform", label: "Revise policy", description: "Creates a new version with an effective date and approval history.", roles: ["management"] },
  { name: "integration.sync", group: "Platform", label: "Run integration sync", description: "Failed syncs raise an alert instead of stopping work silently.", roles: ["management", "finance"] },
  { name: "import.run", group: "Platform", label: "Run import", description: "Existing records are linked, not replaced.", roles: ["management"] },
  { name: "notification.read", group: "Platform", label: "Mark notifications read", description: "Clears the notification tray.", roles: ["management", "startup_relationship_manager", "investor_relations", "finance", "production", "community", "marketing", "legal"] },
];

export const ACTION_CATALOG_MAP: Record<string, ActionDescriptor> = Object.fromEntries(
  ACTION_CATALOG.map((a) => [a.name, a]),
) as Record<string, ActionDescriptor>;

export function runAction(name: string, ctx: ActionContext) {
  const handler = ACTIONS[name];
  if (!handler) throw new HttpError(404, `unknown action: ${name}`);
  const descriptor = ACTION_CATALOG_MAP[name];
  const role = ctx.session.actor.role;
  if (descriptor && role !== "admin" && role !== "management" && !descriptor.roles.includes(role)) {
    throw new HttpError(403, `Role ${role} may not run ${name}`);
  }
  if (!ctx.session.canWrite) throw new HttpError(403, "This role has read-only access");
  return handler(ctx);
}

export function actionsForRole(role: string): ActionDescriptor[] {
  if (role === "admin" || role === "management") return ACTION_CATALOG;
  return ACTION_CATALOG.filter((a) => a.roles.includes(role));
}
