import { all, get, run } from "../db/client";
import { nowISO } from "../domain/dates";
import { entityOrThrow, type EntityDefinition } from "./registry";
import { seasonScopeSql } from "./season";

/**
 * Generic repository.
 *
 * Every entity is read and written through this module. It applies the module's search
 * columns, resolves foreign keys for display, writes an audit row for every field change
 * and never allows a column that is not declared in the schema.
 */

export type Row = Record<string, unknown>;

export interface Actor {
  id: string;
  name: string;
  role: string;
  department: string;
}

export interface ListOptions {
  search?: string;
  filters?: Record<string, string | undefined>;
  limit?: number;
  offset?: number;
  sort?: string;
  direction?: "asc" | "desc";
  /** Restrict the result to one season; tables with no season link ignore it. */
  seasonId?: string;
}

export interface ListResult {
  items: Row[];
  total: number;
  limit: number;
  offset: number;
}

const ID_PREFIX: Record<string, string> = {
  seasons: "SEA", users: "U", startups: "ST", founders: "F", applications: "APP",
  screenings: "SCR", bootcamp_attendance: "BC", analyst_evaluations: "AE", mous: "MOU",
  irr_reports: "IRR", investors: "INV", investor_agreements: "IA",
  investor_grade_assessments: "IG", matches: "MAT", meetings: "MT", virtual_pitches: "VP",
  pitch_days: "PD", pitch_day_slots: "PS", committee_decisions: "CD",
  pre_shoot_confirmations: "PSC", commitments: "COM", funding_rounds: "FR", deals: "D",
  deal_documents: "DD", tranches: "TR", upfront_fees: "UF", success_fees: "SF",
  ledger_entries: "LED", production_handovers: "PH", av_shoots: "AV", mock_shoots: "MS",
  main_shoots: "MSH", episodes: "EP", telecasts: "TC", community_members: "CM",
  community_member_roles: "CMR", community_events: "EV", event_registrations: "ER",
  referrals: "REF", support_requests: "SR", tasks: "TK", handovers: "H", documents: "DOC",
  audit_events: "AU", policies: "POL", policy_revisions: "PR", fee_slabs: "FS",
  calendars: "CAL", integrations: "INT", sync_runs: "SY", import_batches: "IB",
  notifications: "NT",
};

export function columnsOf(table: string): Set<string> {
  const rows = all<{ name: string }>(`PRAGMA table_info(${table})`);
  return new Set(rows.map((r) => r.name));
}

export function nextId(entity: EntityDefinition): string {
  const prefix = ID_PREFIX[entity.key] ?? entity.key.slice(0, 3).toUpperCase();
  // Seed rows use zero-padded two-digit ids, so ordering by id lexicographically would pick
  // the wrong "latest". Scan every id with the prefix and take the numeric maximum.
  const rows = all<{ id: string }>(`SELECT id FROM ${entity.table} WHERE id LIKE ?`, `${prefix}-%`);
  let max = 0;
  for (const r of rows) {
    const match = /-(\d+)$/.exec(r.id);
    if (match) max = Math.max(max, Number(match[1]));
  }
  return `${prefix}-${String(max + 1).padStart(4, "0")}`;
}

function primaryKeyColumn(): string {
  return "id";
}

export function list(entityKey: string, options: ListOptions = {}): ListResult {
  const entity = entityOrThrow(entityKey);
  const columns = columnsOf(entity.table);
  const where: string[] = [];
  const params: unknown[] = [];

  const scope = options.seasonId ? seasonScopeSql(entity.table, options.seasonId) : null;
  if (scope) {
    where.push(scope.sql);
    params.push(...scope.params);
  }

  if (options.search && options.search.trim() && entity.searchable.length) {
    const terms = entity.searchable.filter((c) => columns.has(c));
    if (terms.length) {
      where.push(`(${terms.map((c) => `lower(${c}) LIKE ?`).join(" OR ")})`);
      for (let i = 0; i < terms.length; i += 1) params.push(`%${options.search.trim().toLowerCase()}%`);
    }
  }

  for (const [column, value] of Object.entries(options.filters ?? {})) {
    if (value === undefined || value === "" || !columns.has(column)) continue;
    if (value === "__null__") {
      where.push(`${column} IS NULL`);
      continue;
    }
    where.push(`${column} = ?`);
    params.push(value);
  }

  const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const total = get<{ n: number }>(`SELECT COUNT(*) AS n FROM ${entity.table} ${whereSql}`, ...params)?.n ?? 0;

  const sortColumn =
    options.sort && columns.has(options.sort) ? options.sort : entity.orderBy;
  const direction = options.direction === "asc" ? "ASC" : options.direction === "desc" ? "DESC" : "";
  const orderSql = columns.has(sortColumn)
    ? `ORDER BY ${sortColumn} ${direction || "DESC"}`
    : "";
  const limit = Math.min(Math.max(options.limit ?? 50, 1), 500);
  const offset = Math.max(options.offset ?? 0, 0);

  const items = all<Row>(
    `SELECT * FROM ${entity.table} ${whereSql} ${orderSql} LIMIT ? OFFSET ?`,
    ...params,
    limit,
    offset,
  );

  return { items, total, limit, offset };
}

export function getOne(entityKey: string, id: string): Row | undefined {
  const entity = entityOrThrow(entityKey);
  return get<Row>(`SELECT * FROM ${entity.table} WHERE ${primaryKeyColumn()} = ?`, id);
}

export function listByIds(entityKey: string, ids: string[]): Row[] {
  const entity = entityOrThrow(entityKey);
  if (ids.length === 0) return [];
  const placeholders = ids.map(() => "?").join(", ");
  return all<Row>(`SELECT * FROM ${entity.table} WHERE id IN (${placeholders})`, ...ids);
}

export function listWhere(entityKey: string, column: string, value: unknown, orderBy?: string): Row[] {
  const entity = entityOrThrow(entityKey);
  const columns = columnsOf(entity.table);
  if (!columns.has(column)) return [];
  const order = orderBy && columns.has(orderBy) ? `ORDER BY ${orderBy}` : "";
  return all<Row>(`SELECT * FROM ${entity.table} WHERE ${column} = ? ${order}`, value);
}

export function countWhere(entityKey: string, column: string, value: unknown): number {
  const entity = entityOrThrow(entityKey);
  const columns = columnsOf(entity.table);
  if (!columns.has(column)) return 0;
  return get<{ n: number }>(
    `SELECT COUNT(*) AS n FROM ${entity.table} WHERE ${column} = ?`,
    value,
  )?.n ?? 0;
}

function sanitise(
  entity: EntityDefinition,
  data: Row,
  actor: Actor,
  mode: "create" | "update",
  before?: Row,
): Row {
  const columns = columnsOf(entity.table);
  const out: Row = {};
  for (const [key, value] of Object.entries(data)) {
    if (key === "id") continue;
    if (!columns.has(key)) continue;
    if (
      mode === "update" &&
      entity.managementOnly?.includes(key) &&
      actor.role !== "management" &&
      actor.role !== "admin" &&
      // A recalculation that lands on the same value is not a management decision; only an
      // actual change to a reserved field needs Management or Administrator.
      String(before?.[key] ?? "") !== String(value ?? "")
    ) {
      throw new Error(`field ${key} requires Management or Administrator approval`);
    }
    if (value === "") {
      out[key] = "";
      continue;
    }
    if (value === undefined || value === null) {
      out[key] = null;
      continue;
    }
    if (typeof value === "boolean") {
      out[key] = value ? 1 : 0;
      continue;
    }
    if (typeof value === "object") {
      out[key] = JSON.stringify(value);
      continue;
    }
    out[key] = value as string | number;
  }
  return out;
}

export function create(entityKey: string, data: Row, actor: Actor): Row {
  const entity = entityOrThrow(entityKey);
  const columns = columnsOf(entity.table);
  const clean = sanitise(entity, data, actor, "create");
  if (!clean.id) clean.id = (data.id as string) || nextId(entity);
  if (columns.has("created_at") && !clean.created_at) clean.created_at = nowISO();
  if (columns.has("updated_at")) clean.updated_at = nowISO();

  const keys = Object.keys(clean);
  const placeholders = keys.map(() => "?").join(", ");
  run(
    `INSERT INTO ${entity.table} (${keys.join(", ")}) VALUES (${placeholders})`,
    ...keys.map((k) => clean[k] as never),
  );

  audit(actor, entity.key, String(clean.id), "create", "", "", JSON.stringify(clean), "Record created");
  return getOne(entityKey, String(clean.id)) ?? clean;
}

export function update(entityKey: string, id: string, patch: Row, actor: Actor, reason = ""): Row {
  const entity = entityOrThrow(entityKey);
  const before = getOne(entityKey, id);
  if (!before) throw new Error(`${entity.label} ${id} not found`);
  const columns = columnsOf(entity.table);
  const clean = sanitise(entity, patch, actor, "update", before);
  if (columns.has("updated_at")) clean.updated_at = nowISO();
  const keys = Object.keys(clean).filter((k) => k !== "updated_at");
  if (keys.length === 0 && !columns.has("updated_at")) return before;

  const sets = [...keys.map((k) => `${k} = ?`)];
  if (columns.has("updated_at")) sets.push("updated_at = ?");
  const params: unknown[] = keys.map((k) => clean[k] as never);
  if (columns.has("updated_at")) params.push(clean.updated_at as never);

  run(`UPDATE ${entity.table} SET ${sets.join(", ")} WHERE id = ?`, ...params, id);

  for (const key of keys) {
    const beforeValue = before[key];
    const afterValue = clean[key];
    if (String(beforeValue ?? "") !== String(afterValue ?? "")) {
      audit(actor, entity.key, id, "update", key, String(beforeValue ?? ""), String(afterValue ?? ""), reason);
    }
  }
  return getOne(entityKey, id) ?? before;
}

export function remove(entityKey: string, id: string, actor: Actor): boolean {
  const entity = entityOrThrow(entityKey);
  const before = getOne(entityKey, id);
  if (!before) return false;
  run(`DELETE FROM ${entity.table} WHERE id = ?`, id);
  audit(actor, entity.key, id, "delete", "", JSON.stringify(before), "", "Record deleted");
  return true;
}

export function audit(
  actor: Actor,
  entityType: string,
  entityId: string,
  action: string,
  field: string,
  beforeValue: string,
  afterValue: string,
  reason: string,
): void {
  run(
    `INSERT INTO audit_events (id, actor_id, actor_name, action, entity_type, entity_id, field,
      before_value, after_value, reason, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    nextId(entityOrThrow("audit_events")),
    actor.id,
    actor.name,
    action,
    entityType,
    entityId,
    field,
    beforeValue,
    afterValue,
    reason,
    nowISO(),
  );
}

export function notify(
  recipientRole: string,
  title: string,
  body: string,
  entityType: string,
  entityId: string,
  recipientId?: string,
): void {
  run(
    `INSERT INTO notifications (id, recipient_id, recipient_role, title, body, entity_type,
      entity_id, created_at) VALUES (?,?,?,?,?,?,?,?)`,
    nextId(entityOrThrow("notifications")),
    recipientId ?? null,
    recipientRole,
    title,
    body,
    entityType,
    entityId,
    nowISO(),
  );
}
