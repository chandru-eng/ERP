/**
 * SQLite DDL for the application.
 *
 * Money columns hold paise (integers). JSON-shaped fields (allocations, milestone dates,
 * slab definitions) are stored as TEXT and parsed in the repository layer.
 */

export const SCHEMA_SQL = `
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS seasons (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'live', starts_on TEXT NOT NULL, ends_on TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL, department TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS startups (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, legal_entity TEXT NOT NULL DEFAULT '',
  entity_type TEXT NOT NULL DEFAULT 'Private Limited', sector TEXT NOT NULL DEFAULT '',
  stage TEXT NOT NULL DEFAULT 'early_revenue', geography TEXT NOT NULL DEFAULT '',
  business_model TEXT NOT NULL DEFAULT '', website TEXT NOT NULL DEFAULT '',
  cin TEXT NOT NULL DEFAULT '', gstin TEXT NOT NULL DEFAULT '', pan TEXT NOT NULL DEFAULT '',
  incorporated_on TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS founders (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'Founder', email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '', linkedin TEXT NOT NULL DEFAULT '',
  is_primary INTEGER NOT NULL DEFAULT 0, restricted_to_analyst INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_founders_startup ON founders(startup_id);

CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY, season_id TEXT NOT NULL REFERENCES seasons(id),
  startup_id TEXT NOT NULL REFERENCES startups(id), reference_no TEXT NOT NULL UNIQUE,
  source TEXT NOT NULL DEFAULT '', referring_partner TEXT NOT NULL DEFAULT '',
  campaign TEXT NOT NULL DEFAULT '', relationship_manager_id TEXT,
  stage_at_application TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'draft',
  completion_pct INTEGER NOT NULL DEFAULT 0, submitted_at TEXT, acknowledged_at TEXT,
  duplicate_of TEXT, notes TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_applications_startup ON applications(startup_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);

CREATE TABLE IF NOT EXISTS screenings (
  id TEXT PRIMARY KEY, application_id TEXT NOT NULL REFERENCES applications(id),
  reviewer_id TEXT, completeness INTEGER, documents INTEGER,
  unique_idea INTEGER, revenue INTEGER, traction INTEGER, past_funding INTEGER,
  founder_capability INTEGER, incubation INTEGER,
  ip_defensibility INTEGER, total INTEGER NOT NULL DEFAULT 0, outcome TEXT NOT NULL DEFAULT 'pending',
  comments TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '',
  submitted_at TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_screenings_application ON screenings(application_id);

CREATE TABLE IF NOT EXISTS bootcamp_attendance (
  id TEXT PRIMARY KEY, application_id TEXT NOT NULL REFERENCES applications(id),
  invited_on TEXT NOT NULL DEFAULT '', registered INTEGER NOT NULL DEFAULT 0, attended_on TEXT,
  process_briefing_done INTEGER NOT NULL DEFAULT 0, readiness_session_done INTEGER NOT NULL DEFAULT 0,
  mou_briefing_done INTEGER NOT NULL DEFAULT 0, fee_briefing_done INTEGER NOT NULL DEFAULT 0,
  questions TEXT NOT NULL DEFAULT '', actions_assigned TEXT NOT NULL DEFAULT '',
  preparation_completed INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'not_invited',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS analyst_evaluations (
  id TEXT PRIMARY KEY, application_id TEXT NOT NULL REFERENCES applications(id),
  analyst_id TEXT, thesis_fit INTEGER NOT NULL DEFAULT 0, market_opportunity INTEGER NOT NULL DEFAULT 0,
  traction INTEGER NOT NULL DEFAULT 0, business_model INTEGER NOT NULL DEFAULT 0,
  competitive_positioning INTEGER NOT NULL DEFAULT 0, willingness_to_invest INTEGER NOT NULL DEFAULT 0,
  indicative_amount INTEGER NOT NULL DEFAULT 0, recommendation TEXT NOT NULL DEFAULT 'pending',
  decision_reason TEXT NOT NULL DEFAULT '', outstanding_concern TEXT NOT NULL DEFAULT '',
  evaluated_at TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_analyst_application ON analyst_evaluations(application_id);

CREATE TABLE IF NOT EXISTS mous (
  id TEXT PRIMARY KEY, application_id TEXT NOT NULL REFERENCES applications(id),
  shared_on TEXT NOT NULL DEFAULT '', legal_ama_due TEXT NOT NULL DEFAULT '', legal_ama_on TEXT,
  signing_deadline TEXT NOT NULL DEFAULT '', signed_on TEXT, status TEXT NOT NULL DEFAULT 'not_started',
  commercial_schedule TEXT NOT NULL DEFAULT '', approved_exceptions TEXT NOT NULL DEFAULT '',
  response TEXT NOT NULL DEFAULT '', discontinued_reason TEXT NOT NULL DEFAULT '',
  founder_email TEXT NOT NULL DEFAULT '', escalated_to_management INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS irr_reports (
  id TEXT PRIMARY KEY, application_id TEXT NOT NULL REFERENCES applications(id),
  version INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'not_requested',
  requested_on TEXT NOT NULL DEFAULT '', handover_accepted_on TEXT, checklist_sent_on TEXT,
  prepared_on TEXT, reviewed_by_id TEXT, approved_on TEXT, approved_by_id TEXT,
  shared_with_ir_on TEXT, document_ref TEXT NOT NULL DEFAULT '',
  missing_documents TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS investors (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'HNI',
  investing_entity TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '',
  referral_relationship TEXT NOT NULL DEFAULT '', decision_maker TEXT NOT NULL DEFAULT '',
  authorised_representative TEXT NOT NULL DEFAULT '', sector_focus TEXT NOT NULL DEFAULT '',
  stage_focus TEXT NOT NULL DEFAULT '', geography TEXT NOT NULL DEFAULT '',
  thesis TEXT NOT NULL DEFAULT '', ticket_min INTEGER NOT NULL DEFAULT 0,
  ticket_max INTEGER NOT NULL DEFAULT 0, proposed_season_allocation INTEGER NOT NULL DEFAULT 0,
  portfolio TEXT NOT NULL DEFAULT '', reference_checks TEXT NOT NULL DEFAULT '',
  verification_evidence TEXT NOT NULL DEFAULT '', availability TEXT NOT NULL DEFAULT '',
  expected_decision_timeline TEXT NOT NULL DEFAULT '', relationship_owner_id TEXT,
  status TEXT NOT NULL DEFAULT 'sourced', grade TEXT, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS investor_agreements (
  id TEXT PRIMARY KEY, investor_id TEXT NOT NULL REFERENCES investors(id),
  document_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'requested', signed_on TEXT,
  reference TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS investor_grade_assessments (
  id TEXT PRIMARY KEY, investor_id TEXT NOT NULL REFERENCES investors(id),
  grade TEXT NOT NULL, dimension TEXT NOT NULL DEFAULT '', score INTEGER NOT NULL DEFAULT 0,
  evidence TEXT NOT NULL DEFAULT '', reviewer_id TEXT, approved_on TEXT,
  permitted_engagement TEXT NOT NULL DEFAULT '', panel_role TEXT NOT NULL DEFAULT '',
  review_date TEXT NOT NULL DEFAULT '', change_reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  investor_id TEXT NOT NULL REFERENCES investors(id), score INTEGER NOT NULL DEFAULT 0,
  score_reasons TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'suggested',
  approved_for_circulation_by_id TEXT, information_shared TEXT NOT NULL DEFAULT '',
  info_version TEXT NOT NULL DEFAULT '', shared_on TEXT, response TEXT NOT NULL DEFAULT '',
  questions TEXT NOT NULL DEFAULT '', documents_requested TEXT NOT NULL DEFAULT '',
  indicative_amount INTEGER NOT NULL DEFAULT 0, next_action TEXT NOT NULL DEFAULT '',
  next_action_due TEXT NOT NULL DEFAULT '', pass_reason TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_matches_startup ON matches(startup_id);
CREATE INDEX IF NOT EXISTS idx_matches_investor ON matches(investor_id);

CREATE TABLE IF NOT EXISTS meetings (
  id TEXT PRIMARY KEY, match_id TEXT, startup_id TEXT, investor_id TEXT,
  meeting_type TEXT NOT NULL DEFAULT 'Exploratory', scheduled_at TEXT NOT NULL DEFAULT '',
  held_at TEXT, attendees TEXT NOT NULL DEFAULT '', minutes TEXT NOT NULL DEFAULT '',
  minutes_acknowledged INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS virtual_pitches (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id), match_id TEXT,
  investor_id TEXT, scheduled_at TEXT NOT NULL DEFAULT '', duration_pitch_min INTEGER NOT NULL DEFAULT 5,
  duration_qa_min INTEGER NOT NULL DEFAULT 5, attended INTEGER NOT NULL DEFAULT 0,
  material_shared TEXT NOT NULL DEFAULT '', investor_questions TEXT NOT NULL DEFAULT '',
  responses TEXT NOT NULL DEFAULT '', response TEXT NOT NULL DEFAULT 'no_response',
  amount_confirmed INTEGER NOT NULL DEFAULT 0, terms_confirmed TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pitch_days (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  episode_no TEXT NOT NULL DEFAULT '', scheduled_at TEXT NOT NULL DEFAULT '',
  irr_distributed INTEGER NOT NULL DEFAULT 0, information_memorandum_distributed INTEGER NOT NULL DEFAULT 0,
  outcome TEXT NOT NULL DEFAULT 'one_to_one_held', golden_pass_issuer_investor_id TEXT,
  golden_pass_evidence TEXT NOT NULL DEFAULT '', follow_on_interest TEXT NOT NULL DEFAULT '',
  further_discussion_deadline TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pitch_day_slots (
  id TEXT PRIMARY KEY, pitch_day_id TEXT NOT NULL REFERENCES pitch_days(id),
  investor_id TEXT NOT NULL, slot_time TEXT NOT NULL DEFAULT '', held INTEGER NOT NULL DEFAULT 0,
  outcome TEXT NOT NULL DEFAULT 'one_to_one_held', notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS committee_decisions (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  pack_summary TEXT NOT NULL DEFAULT '', outcome TEXT NOT NULL DEFAULT 'pending',
  conditions TEXT NOT NULL DEFAULT '', approver_id TEXT, decided_on TEXT,
  re_review_date TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pre_shoot_confirmations (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  episode_no TEXT NOT NULL DEFAULT '', panel_summary TEXT NOT NULL DEFAULT '',
  written_commitment_ref TEXT NOT NULL DEFAULT '', valuation_boundaries TEXT NOT NULL DEFAULT '',
  decision_parameters TEXT NOT NULL DEFAULT '', production_briefing_done INTEGER NOT NULL DEFAULT 0,
  outstanding_issues TEXT NOT NULL DEFAULT '', required_documentation TEXT NOT NULL DEFAULT '',
  irr_shared_on TEXT, shoot_date TEXT, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS commitments (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  investor_id TEXT NOT NULL REFERENCES investors(id), status TEXT NOT NULL DEFAULT 'indicative',
  amount INTEGER NOT NULL DEFAULT 0, valuation TEXT NOT NULL DEFAULT '',
  terms TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '',
  is_golden_pass INTEGER NOT NULL DEFAULT 0, written_on TEXT, confirmed_on TEXT,
  revised_from_id TEXT, revision_reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_commitments_startup ON commitments(startup_id);

CREATE TABLE IF NOT EXISTS funding_rounds (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  name TEXT NOT NULL, target_amount INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'not_started', closure_owner_id TEXT,
  expected_close_on TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS deals (
  id TEXT PRIMARY KEY, funding_round_id TEXT NOT NULL REFERENCES funding_rounds(id),
  startup_id TEXT NOT NULL REFERENCES startups(id), investor_id TEXT NOT NULL REFERENCES investors(id),
  commitment_id TEXT, status TEXT NOT NULL DEFAULT 'not_started',
  committed_amount INTEGER NOT NULL DEFAULT 0, agreed_terms TEXT NOT NULL DEFAULT '',
  valuation TEXT NOT NULL DEFAULT '', communication_thread_opened_at TEXT,
  communication_thread_due TEXT NOT NULL DEFAULT '', milestone_dates TEXT NOT NULL DEFAULT '{}',
  open_documents TEXT NOT NULL DEFAULT '', open_conditions TEXT NOT NULL DEFAULT '',
  blocker TEXT NOT NULL DEFAULT '', responsible_id TEXT, next_action TEXT NOT NULL DEFAULT '',
  withdrawal_reason TEXT NOT NULL DEFAULT '', replacement_investor_id TEXT, closed_on TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_deals_startup ON deals(startup_id);
CREATE INDEX IF NOT EXISTS idx_deals_investor ON deals(investor_id);

CREATE TABLE IF NOT EXISTS deal_documents (
  id TEXT PRIMARY KEY, deal_id TEXT NOT NULL REFERENCES deals(id),
  purpose TEXT NOT NULL DEFAULT '', document_type TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'requested', version INTEGER NOT NULL DEFAULT 1,
  received_on TEXT, signed_on TEXT, signer TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS tranches (
  id TEXT PRIMARY KEY, deal_id TEXT NOT NULL REFERENCES deals(id), seq INTEGER NOT NULL DEFAULT 1,
  scheduled_amount INTEGER NOT NULL DEFAULT 0, scheduled_on TEXT NOT NULL DEFAULT '',
  reported_on TEXT, reported_amount INTEGER NOT NULL DEFAULT 0, startup_confirmed_on TEXT,
  evidence TEXT NOT NULL DEFAULT '', verified_amount INTEGER NOT NULL DEFAULT 0,
  verified_on TEXT, verifier_id TEXT, status TEXT NOT NULL DEFAULT 'scheduled',
  reversal_of_id TEXT, reversal_reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tranches_deal ON tranches(deal_id);

CREATE TABLE IF NOT EXISTS upfront_fees (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  season_id TEXT NOT NULL REFERENCES seasons(id), committee_decision_id TEXT,
  initial_interest_announced_on TEXT NOT NULL DEFAULT '', financial_year TEXT NOT NULL DEFAULT '',
  turnover INTEGER NOT NULL DEFAULT 0, turnover_evidence TEXT NOT NULL DEFAULT '',
  fee_schedule_code TEXT NOT NULL DEFAULT '', fee_schedule_version TEXT NOT NULL DEFAULT '',
  fee_amount INTEGER NOT NULL DEFAULT 0, approved_exception TEXT NOT NULL DEFAULT '',
  approved_by_id TEXT, invoice_no TEXT NOT NULL DEFAULT '', invoice_date TEXT, due_date TEXT,
  payment_reference TEXT NOT NULL DEFAULT '', paid_amount INTEGER NOT NULL DEFAULT 0,
  outstanding INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'not_initiated',
  extension_approved INTEGER NOT NULL DEFAULT 0, original_due_date TEXT,
  waiver_amount INTEGER NOT NULL DEFAULT 0, refund_amount INTEGER NOT NULL DEFAULT 0,
  credit_note_ref TEXT NOT NULL DEFAULT '', late_payment_reason TEXT NOT NULL DEFAULT '',
  dispute_note TEXT NOT NULL DEFAULT '',
  management_decision TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_upfront_startup ON upfront_fees(startup_id);

CREATE TABLE IF NOT EXISTS success_fees (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id), deal_id TEXT,
  funding_round_id TEXT, agreement_ref TEXT NOT NULL DEFAULT '',
  eligible_funding INTEGER NOT NULL DEFAULT 0, excluded_funding INTEGER NOT NULL DEFAULT 0,
  fee_structure TEXT NOT NULL DEFAULT 'percentage', fee_percent REAL NOT NULL DEFAULT 0,
  slab_definition TEXT NOT NULL DEFAULT '[]', fee_cap INTEGER NOT NULL DEFAULT 0,
  sourcing_arrangement TEXT NOT NULL DEFAULT '', upfront_adjustable INTEGER NOT NULL DEFAULT 0,
  upfront_adjustment INTEGER NOT NULL DEFAULT 0, forecast_fee INTEGER NOT NULL DEFAULT 0,
  fee_due INTEGER NOT NULL DEFAULT 0, invoiced_amount INTEGER NOT NULL DEFAULT 0,
  collected_amount INTEGER NOT NULL DEFAULT 0, outstanding INTEGER NOT NULL DEFAULT 0,
  discount INTEGER NOT NULL DEFAULT 0, waiver_amount INTEGER NOT NULL DEFAULT 0,
  partner_settlement INTEGER NOT NULL DEFAULT 0, tax_amount INTEGER NOT NULL DEFAULT 0,
  withholding_amount INTEGER NOT NULL DEFAULT 0, invoice_no TEXT NOT NULL DEFAULT '',
  invoice_date TEXT, due_date TEXT, status TEXT NOT NULL DEFAULT 'not_triggered',
  triggered_on TEXT, reconciled_on TEXT, dispute_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_success_startup ON success_fees(startup_id);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  entry_type TEXT NOT NULL, reference TEXT NOT NULL DEFAULT '', amount INTEGER NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'INR', occurred_on TEXT NOT NULL DEFAULT '',
  source_type TEXT NOT NULL DEFAULT 'manual', source_id TEXT, memo TEXT NOT NULL DEFAULT '',
  created_by_id TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ledger_startup ON ledger_entries(startup_id);

CREATE TABLE IF NOT EXISTS production_handovers (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  status TEXT NOT NULL DEFAULT 'pending', selection_approved INTEGER NOT NULL DEFAULT 0,
  payment_cleared INTEGER NOT NULL DEFAULT 0, advance_notified INTEGER NOT NULL DEFAULT 0,
  pack_summary TEXT NOT NULL DEFAULT '', permitted_business_information TEXT NOT NULL DEFAULT '',
  handed_over_on TEXT, accepted_on TEXT, accepted_by_id TEXT, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS av_shoots (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  status TEXT NOT NULL DEFAULT 'not_started', story_research TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '', crew TEXT NOT NULL DEFAULT '', schedule_on TEXT,
  founder_availability TEXT NOT NULL DEFAULT '', shot_requirements TEXT NOT NULL DEFAULT '',
  completed_on TEXT, asset_links TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS mock_shoots (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  status TEXT NOT NULL DEFAULT 'not_started', scheduled_on TEXT,
  costumes_properties TEXT NOT NULL DEFAULT '', pitch_revisions TEXT NOT NULL DEFAULT '',
  product_demo_ready INTEGER NOT NULL DEFAULT 0, stage_movement_rehearsed INTEGER NOT NULL DEFAULT 0,
  final_ask INTEGER NOT NULL DEFAULT 0, valuation_information TEXT NOT NULL DEFAULT '',
  open_actions TEXT NOT NULL DEFAULT '', final_readiness_approved_on TEXT,
  final_readiness_by_id TEXT, created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS main_shoots (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  episode_no TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'not_started',
  scheduled_on TEXT, completed_on TEXT, founder_attendance TEXT NOT NULL DEFAULT '',
  investor_attendance TEXT NOT NULL DEFAULT '', live_ask INTEGER NOT NULL DEFAULT 0,
  live_offers TEXT NOT NULL DEFAULT '', accepted_deal_terms TEXT NOT NULL DEFAULT '',
  lead_investor_id TEXT, co_investor_allocations TEXT NOT NULL DEFAULT '[]',
  conditions TEXT NOT NULL DEFAULT '', investment_commitment_letter_ref TEXT NOT NULL DEFAULT '',
  startup_deal_acceptance_letter_ref TEXT NOT NULL DEFAULT '', signature_completed_on TEXT,
  outstanding_actions TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS episodes (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  episode_no TEXT NOT NULL DEFAULT '', shoot_completed_on TEXT,
  editing_status TEXT NOT NULL DEFAULT 'not_started', approvals_status TEXT NOT NULL DEFAULT 'not_started',
  status TEXT NOT NULL DEFAULT 'not_allocated', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telecasts (
  id TEXT PRIMARY KEY, startup_id TEXT NOT NULL REFERENCES startups(id),
  episode_no TEXT NOT NULL DEFAULT '', telecast_date TEXT, status TEXT NOT NULL DEFAULT 'not_scheduled',
  founder_notified_on TEXT, promo_requirements TEXT NOT NULL DEFAULT '',
  promo_assets_approved TEXT NOT NULL DEFAULT '', founder_posting_done INTEGER NOT NULL DEFAULT 0,
  post_telecast_activity TEXT NOT NULL DEFAULT '', founder_feedback TEXT NOT NULL DEFAULT '',
  public_announcement TEXT NOT NULL DEFAULT '', announced_amount INTEGER NOT NULL DEFAULT 0,
  committed_amount INTEGER NOT NULL DEFAULT 0, verified_deployed_amount INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS community_members (
  id TEXT PRIMARY KEY, person_id TEXT, name TEXT NOT NULL, email TEXT NOT NULL DEFAULT '',
  phone TEXT NOT NULL DEFAULT '', member_type TEXT NOT NULL DEFAULT 'applicant',
  organisation TEXT NOT NULL DEFAULT '', sector TEXT NOT NULL DEFAULT '',
  geography TEXT NOT NULL DEFAULT '', interests TEXT NOT NULL DEFAULT '',
  relationship_owner_id TEXT, communication_preferences TEXT NOT NULL DEFAULT '',
  consent_marketing INTEGER NOT NULL DEFAULT 0, consent_contact INTEGER NOT NULL DEFAULT 0,
  confidential_access INTEGER NOT NULL DEFAULT 0, startup_id TEXT,
  engagement_summary TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS community_member_roles (
  id TEXT PRIMARY KEY, member_id TEXT NOT NULL REFERENCES community_members(id),
  role TEXT NOT NULL, since TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS community_events (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, event_type TEXT NOT NULL DEFAULT 'Founder meetup',
  purpose TEXT NOT NULL DEFAULT '', owner_id TEXT, budget INTEGER NOT NULL DEFAULT 0,
  scheduled_on TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'planned',
  registrations INTEGER NOT NULL DEFAULT 0, attendance INTEGER NOT NULL DEFAULT 0,
  feedback_score REAL NOT NULL DEFAULT 0, follow_up_tasks TEXT NOT NULL DEFAULT '',
  outcomes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_registrations (
  id TEXT PRIMARY KEY, event_id TEXT NOT NULL REFERENCES community_events(id),
  member_id TEXT NOT NULL, registered INTEGER NOT NULL DEFAULT 0,
  attended INTEGER NOT NULL DEFAULT 0, feedback TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS referrals (
  id TEXT PRIMARY KEY, source_type TEXT NOT NULL DEFAULT 'community_member', source_id TEXT,
  source_name TEXT NOT NULL DEFAULT '', referred_name TEXT NOT NULL DEFAULT '',
  referred_type TEXT NOT NULL DEFAULT 'startup_application', startup_id TEXT, investor_id TEXT,
  status TEXT NOT NULL DEFAULT 'new', original_contributor TEXT NOT NULL DEFAULT '',
  additional_contributors TEXT NOT NULL DEFAULT '', outcome TEXT NOT NULL DEFAULT '',
  outcome_amount INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS support_requests (
  id TEXT PRIMARY KEY, member_id TEXT NOT NULL, startup_id TEXT,
  request_type TEXT NOT NULL DEFAULT 'investor_introduction', detail TEXT NOT NULL DEFAULT '',
  owner_id TEXT, due_date TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
  outcome TEXT NOT NULL DEFAULT '', founder_feedback TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '', module TEXT NOT NULL DEFAULT '',
  entity_type TEXT, entity_id TEXT, owner_id TEXT, due_date TEXT NOT NULL DEFAULT '',
  required_output TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '',
  approver_id TEXT, next_action TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
  priority TEXT NOT NULL DEFAULT 'medium', escalation_status TEXT NOT NULL DEFAULT 'open',
  escalated_on TEXT, escalation_reason TEXT NOT NULL DEFAULT '', completed_on TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_owner ON tasks(owner_id);
CREATE INDEX IF NOT EXISTS idx_tasks_entity ON tasks(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS handovers (
  id TEXT PRIMARY KEY, from_department TEXT NOT NULL, to_department TEXT NOT NULL,
  entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending', accepted_by_id TEXT, accepted_on TEXT,
  rejected_reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
  title TEXT NOT NULL, purpose TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '',
  version INTEGER NOT NULL DEFAULT 1, status TEXT NOT NULL DEFAULT 'requested',
  file_ref TEXT NOT NULL DEFAULT '', uploaded_by_id TEXT, uploaded_on TEXT NOT NULL,
  notes TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_documents_entity ON documents(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY, actor_id TEXT, actor_name TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
  field TEXT NOT NULL DEFAULT '', before_value TEXT NOT NULL DEFAULT '',
  after_value TEXT NOT NULL DEFAULT '', reason TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id);

CREATE TABLE IF NOT EXISTS policies (
  id TEXT PRIMARY KEY, code TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL DEFAULT '',
  value TEXT NOT NULL DEFAULT '{}', status TEXT NOT NULL DEFAULT 'draft',
  effective_from TEXT NOT NULL DEFAULT '', approved_by_id TEXT, approved_on TEXT,
  superseded_by_id TEXT, notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_policies_code ON policies(code);

CREATE TABLE IF NOT EXISTS policy_revisions (
  id TEXT PRIMARY KEY, policy_id TEXT NOT NULL REFERENCES policies(id), version INTEGER NOT NULL,
  value TEXT NOT NULL, changed_by_id TEXT, changed_on TEXT NOT NULL, reason TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS fee_slabs (
  id TEXT PRIMARY KEY, schedule_code TEXT NOT NULL, schedule_version TEXT NOT NULL,
  turnover_min INTEGER NOT NULL DEFAULT 0, turnover_max INTEGER, fee_amount INTEGER NOT NULL DEFAULT 0,
  effective_from TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS calendars (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, region TEXT NOT NULL DEFAULT '',
  holidays TEXT NOT NULL DEFAULT '[]', working_days TEXT NOT NULL DEFAULT '1,2,3,4,5'
);

CREATE TABLE IF NOT EXISTS integrations (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'sanchi_connect',
  status TEXT NOT NULL DEFAULT 'not_configured', last_sync_at TEXT,
  last_sync_status TEXT NOT NULL DEFAULT '', records_synced INTEGER NOT NULL DEFAULT 0,
  failed_sync_alerts INTEGER NOT NULL DEFAULT 0, last_error TEXT NOT NULL DEFAULT '',
  config TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS sync_runs (
  id TEXT PRIMARY KEY, integration_id TEXT NOT NULL REFERENCES integrations(id),
  started_at TEXT NOT NULL, finished_at TEXT, status TEXT NOT NULL DEFAULT 'success',
  records INTEGER NOT NULL DEFAULT 0, error TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS import_batches (
  id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, file_name TEXT NOT NULL DEFAULT '',
  rows INTEGER NOT NULL DEFAULT 0, imported INTEGER NOT NULL DEFAULT 0, skipped INTEGER NOT NULL DEFAULT 0,
  duplicates INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'completed',
  started_at TEXT NOT NULL, finished_at TEXT, log TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY, recipient_id TEXT, recipient_role TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL, body TEXT NOT NULL DEFAULT '', entity_type TEXT NOT NULL DEFAULT '',
  entity_id TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, read_at TEXT
);
`;
