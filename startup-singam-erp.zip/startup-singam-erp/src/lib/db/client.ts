import { DatabaseSync } from "node:sqlite";
import { existsSync, mkdirSync } from "node:fs";
import path from "node:path";
import { SCHEMA_SQL } from "./schema";
import { seedDatabase } from "./seed";

/**
 * Persistence.
 *
 * The whole ERP runs against one SQLite file created from `schema.ts` and filled by
 * `seed.ts` on first boot. The repository layer (`src/lib/server/repo.ts`) is the only
 * code that talks to this module directly.
 */

let instance: DatabaseSync | null = null;

function databasePath(): string {
  return process.env.SINGAM_DB_PATH ?? path.join(process.cwd(), "data", "singam.db");
}

export function getDb(): DatabaseSync {
  if (instance) return instance;

  const file = databasePath();
  if (file !== ":memory:") {
    const dir = path.dirname(file);
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
  }

  const db = new DatabaseSync(file);
  db.exec(SCHEMA_SQL);

  const row = db.prepare("SELECT COUNT(*) AS n FROM seasons").get() as { n: number } | undefined;
  if (!row || row.n === 0) {
    seedDatabase(db);
  }

  instance = db;
  return db;
}

export type SqlValue = string | number | bigint | null | Uint8Array;

/** SQLite rejects `undefined`; normalise it to NULL and booleans to 0/1. */
export function normaliseParams(params: unknown[]): SqlValue[] {
  return params.map((p) => {
    if (p === undefined || p === null) return null;
    if (typeof p === "boolean") return p ? 1 : 0;
    if (typeof p === "number" || typeof p === "string" || typeof p === "bigint") return p;
    if (p instanceof Uint8Array) return p;
    return JSON.stringify(p);
  });
}

export function all<T = Record<string, unknown>>(sql: string, ...params: unknown[]): T[] {
  return getDb().prepare(sql).all(...normaliseParams(params)) as T[];
}

export function get<T = Record<string, unknown>>(sql: string, ...params: unknown[]): T | undefined {
  return getDb().prepare(sql).get(...normaliseParams(params)) as T | undefined;
}

export function run(sql: string, ...params: unknown[]) {
  return getDb().prepare(sql).run(...normaliseParams(params));
}

export function exec(sql: string): void {
  getDb().exec(sql);
}

/** Reset helper used by `npm run db:reset`. */
export function resetDatabase(): void {
  instance = null;
  const file = databasePath();
  if (file !== ":memory:" && existsSync(file)) {
    const db = new DatabaseSync(file);
    const tables = db
      .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
      .all() as { name: string }[];
    db.exec("PRAGMA foreign_keys = OFF");
    for (const t of tables) db.exec(`DROP TABLE IF EXISTS "${t.name}"`);
    db.close();
  }
  getDb();
}

export function newId(prefix: string, seq: number): string {
  return `${prefix}-${String(seq).padStart(4, "0")}`;
}
