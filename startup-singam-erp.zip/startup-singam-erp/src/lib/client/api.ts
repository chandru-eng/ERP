"use client";

/**
 * Browser API client.
 *
 * The acting user travels in the `x-actor` header so role restrictions are exercised the
 * same way they would be after a real login.
 */

export interface ApiEnvelope<T> {
  ok: boolean;
  data: T;
  error?: string;
  status?: number;
}

/** Error thrown by the API client, carrying the HTTP status so callers can react to it. */
export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = "ApiError";
    this.status = status;
  }
}

let currentActor = "U-MGMT";
let currentSeason = "";

export function setActor(id: string): void {
  currentActor = id;
  if (typeof window !== "undefined") window.localStorage.setItem("singam.actor", id);
}

export function getActor(): string {
  if (typeof window !== "undefined") {
    const stored = window.localStorage.getItem("singam.actor");
    if (stored) return stored;
  }
  return currentActor;
}

/** The season every request is scoped to. Empty until the session resolves. */
export function setSeason(id: string): void {
  currentSeason = id;
  if (typeof window !== "undefined") window.localStorage.setItem("singam.season", id);
}

export function getSeason(): string {
  if (typeof window !== "undefined") {
    const stored = window.localStorage.getItem("singam.season");
    if (stored) return stored;
  }
  return currentSeason;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      "x-actor": getActor(),
      ...(getSeason() ? { "x-season": getSeason() } : {}),
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });
  // The body may be empty (for example a transient 5xx while the dev server compiles a
  // route on first hit), so read the text and parse defensively instead of assuming JSON.
  const text = await response.text();
  let payload: ApiEnvelope<T> | null = null;
  if (text) {
    try {
      payload = JSON.parse(text) as ApiEnvelope<T>;
    } catch {
      payload = null;
    }
  }
  if (!payload) {
    throw new ApiError(`Request to ${path} failed with status ${response.status}`, response.status);
  }
  if (!payload.ok) throw new ApiError(payload.error ?? `Request failed with status ${response.status}`, response.status);
  return payload.data;
}

export interface ListResponse {
  entity: string;
  label: string;
  season?: string;
  total: number;
  limit: number;
  offset: number;
  items: Record<string, unknown>[];
}

export function apiList(
  entity: string,
  options: { search?: string; filters?: Record<string, string>; limit?: number; offset?: number; sort?: string; direction?: string } = {},
): Promise<ListResponse> {
  const params = new URLSearchParams();
  if (options.search) params.set("search", options.search);
  if (options.limit) params.set("limit", String(options.limit));
  if (options.offset) params.set("offset", String(options.offset));
  if (options.sort) params.set("sort", options.sort);
  if (options.direction) params.set("direction", options.direction);
  for (const [k, v] of Object.entries(options.filters ?? {})) if (v !== "" && v !== undefined) params.set(k, v);
  return request<ListResponse>(`/api/v1/${entity}?${params.toString()}`);
}

export interface DetailResponse {
  entity: string;
  label: string;
  record: Record<string, unknown>;
  related: Record<string, Record<string, unknown>[]>;
}

export function apiGet(entity: string, id: string): Promise<DetailResponse> {
  return request<DetailResponse>(`/api/v1/${entity}/${id}`);
}

export function apiCreate(entity: string, body: Record<string, unknown>): Promise<Record<string, unknown>> {
  return request(`/api/v1/${entity}`, { method: "POST", body: JSON.stringify(body) });
}

export function apiUpdate(entity: string, id: string, body: Record<string, unknown>): Promise<Record<string, unknown>> {
  return request(`/api/v1/${entity}/${id}`, { method: "PATCH", body: JSON.stringify(body) });
}

export function apiDelete(entity: string, id: string): Promise<{ deleted: string }> {
  return request(`/api/v1/${entity}/${id}`, { method: "DELETE" });
}

export interface ActionResult {
  ok?: boolean;
  message?: string;
  data?: unknown;
}

export function apiAction(action: string, payload: Record<string, unknown> = {}): Promise<ActionResult> {
  return request<ActionResult>("/api/v1/actions", {
    method: "POST",
    body: JSON.stringify({ action, payload }),
  });
}

export interface SessionResponse {
  actor: { id: string; name: string; role: string; department: string };
  canWrite: boolean;
  users: { id: string; name: string; role: string; department: string; roleLabel: string }[];
  roles: { key: string; label: string; department: string; modules: string[] }[];
  departments: { key: string; label: string; short: string; description: string; colour: string }[];
  seasons: { id: string; code: string; name: string; status: string; starts_on: string; ends_on: string }[];
  currentSeasonId: string;
  notifications: Record<string, unknown>[];
}

export function apiSession(): Promise<SessionResponse> {
  return request<SessionResponse>("/api/v1/session");
}

export interface BoardRow {
  startup_id: string;
  startup: string;
  sector: string;
  stage: string;
  application_ref: string | null;
  application_status: string | null;
  screening_outcome: string | null;
  analyst_recommendation: string | null;
  mou_status: string | null;
  irr_status: string | null;
  committee_outcome: string | null;
  upfront_fee_status: string | null;
  upfront_fee_amount: number;
  upfront_fee_paid: number;
  upfront_fee_outstanding: number;
  shoot_status: string | null;
  av_status: string | null;
  mock_status: string | null;
  episode_status: string | null;
  telecast_status: string | null;
  committed_amount: number;
  deal_status: string | null;
  deployed_amount: number;
  outstanding_commitment: number;
  success_fee_status: string | null;
  success_fee_due: number;
  success_fee_invoiced: number;
  success_fee_collected: number;
  success_fee_outstanding: number;
  open_tasks: number;
  overdue_tasks: number;
  sentence: string;
}

export interface DashboardResponse {
  season?: string;
  kpis: {
    applications: { total: number; submitted: number; inScreening: number; proceeded: number; rejected: number; conversionPct: number };
    stageBacklog: { stage: string; department: string; count: number; oldestDays: number }[];
    investors: { total: number; onboarded: number; verificationPending: number; agreementPending: number; gradeMix: Record<string, number> };
    matching: { suggested: number; approved: number; shared: number; advanced: number; passed: number; coveragePct: number };
    upfront: { due: number; collected: number; overdue: number; overdueCount: number };
    shoot: { paidAwaitingAv: number; avCompleted: number; mockReady: number; shootCompleted: number; telecastReady: number; telecastDone: number };
    commitments: { committed: number; signedDeals: number; deployed: number; outstanding: number; atRiskDeals: number };
    successFees: { due: number; invoiced: number; collected: number; overdue: number; overdueCount: number };
    community: { members: number; events: number; registrations: number; attendance: number; qualifiedReferrals: number; convertedReferrals: number; supportOpen: number; supportResolved: number; referralFunding: number };
    overdueByDepartment: { department: string; count: number }[];
    exceptions: { id: string; title: string; department: string; severity: string; detail: string }[];
  };
  departments: (Record<string, unknown> & { key: string; label: string; short: string; description: string; metrics: Record<string, number> })[];
  board: BoardRow[];
}

export function apiDashboard(): Promise<DashboardResponse> {
  return request<DashboardResponse>("/api/v1/dashboard");
}

export function apiBoard(startupId?: string): Promise<BoardRow[] | BoardRow> {
  const suffix = startupId ? `?startup_id=${startupId}` : "";
  return request(`/api/v1/startup-board${suffix}`);
}

export interface MetaResponse {
  entities: { key: string; label: string; plural: string; module: string; status?: { column: string; registry: string }; searchable: string[]; relations?: { column: string; entity: string; label: string }[] }[];
  statuses: Record<string, Record<string, { value: string; label: string; tone: string; terminal?: boolean }>>;
  journeys: { key: string; label: string; description: string; department: string }[];
  stages: {
    key: string; label: string; journey: string; order: number; department: string; ownerRole: string;
    deadline?: { workingDays: number; fromEvent: string };
    requiredOutput: string; evidence: string; approverRole?: string; requiredDocuments?: string[];
    escalation?: string; statusRegistry?: string; module?: string; notes?: string;
  }[];
  departments: { key: string; label: string; short: string; description: string; colour: string }[];
  modules: string[];
  roles: { key: string; label: string; department: string; modules: string[] }[];
  fieldRestrictions: Record<string, string[]>;
  screening: { criteria: { key: string; label: string; max: number; hint: string; canBeNotApplicable: boolean }[]; max: number; defaultRule: Record<string, unknown> };
  policies: { code: string; title: string; category: string; question: string; valueSchema: string; defaultValue: Record<string, unknown> }[];
  documentPurposes: { key: string; label: string; stageKey: string; audience: string[]; confidential: boolean }[];
}

export function apiMeta(): Promise<MetaResponse> {
  return request<MetaResponse>("/api/v1/meta");
}

export interface ActionCatalogResponse {
  role: string;
  canWrite: boolean;
  total: number;
  catalog: { name: string; group: string; label: string; description: string; roles: string[] }[];
  allowed: string[];
}

export function apiActionCatalog(): Promise<ActionCatalogResponse> {
  return request<ActionCatalogResponse>("/api/v1/actions");
}

export interface SearchResponse {
  query: string;
  total?: number;
  results: { entity: string; entityLabel: string; id: string; title: string; subtitle: string }[];
}

export function apiSearch(q: string): Promise<SearchResponse> {
  return request<SearchResponse>(`/api/v1/search?q=${encodeURIComponent(q)}`);
}
