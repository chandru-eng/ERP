#!/usr/bin/env python3
"""End-to-end walkthrough of the Startup Singam ERP application.

Drives every department workflow through the real HTTP API on port 12000, acting as
each department's user, and asserts the separations the brief insists on:

* Golden Pass never becomes a written commitment on its own.
* Reported tranche amounts never become verified deployment on their own.
* A payment screenshot never marks an invoice paid.
* A verified deployment triggers the success fee without anyone sending an email.

Usage: python3 scripts/e2e_scenario.py [base_url]
"""

from __future__ import annotations

import json
import sys
import time
import urllib.error
import urllib.request
from datetime import date, timedelta

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:12000"
FAILURES: list[str] = []
CHECKS = 0


def today_str(offset: int = 0) -> str:
    return (date.today() + timedelta(days=offset)).isoformat()


def call(action: str, actor: str, payload: dict, _retries: int = 3, season: str | None = None) -> dict:
    body = json.dumps({"action": action, "payload": payload}).encode()
    headers = {"Content-Type": "application/json", "x-actor": actor}
    if season:
        headers["x-season"] = season
    req = urllib.request.Request(f"{BASE}/api/v1/actions", data=body, headers=headers)
    try:
        with urllib.request.urlopen(req) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        # A cold route can answer 500 with an empty body while Next compiles it; retry
        # only that. A 500 that carries a JSON error body is a real failure, not a race.
        try:
            return json.load(e)
        except json.JSONDecodeError:
            if _retries > 0:
                time.sleep(1.5)
                return call(action, actor, payload, _retries - 1, season)
            raise


def get(path: str, actor: str = "U-MGMT", _retries: int = 3, season: str | None = None) -> dict:
    headers = {"x-actor": actor}
    if season:
        headers["x-season"] = season
    req = urllib.request.Request(f"{BASE}/api/v1{path}", headers=headers)
    try:
        with urllib.request.urlopen(req) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        try:
            return json.load(e)
        except json.JSONDecodeError:
            if _retries > 0:
                time.sleep(1.5)
                return get(path, actor, _retries - 1, season)
            raise


def check(label: str, condition: bool, detail: str = "") -> None:
    global CHECKS
    CHECKS += 1
    if condition:
        print(f"  PASS  {label}")
    else:
        print(f"  FAIL  {label} {detail}")
        FAILURES.append(label)


def step(title: str) -> None:
    print(f"\n=== {title} ===")


def data(res: dict) -> dict:
    payload = res.get("data") or {}
    return payload.get("data") if isinstance(payload.get("data"), dict) else payload


def main() -> int:
    step("Startup journey: application, screening, bootcamp, analyst, MoU, IRR")

    draft = call("application.draft", "U-SR1", {
        "startup_id": "S-06",
        "stage_at_application": "idea",
        "source": "Community event",
        "campaign": "S2-E2E",
    })
    app_id = data(draft).get("id")
    check("draft application created", draft.get("ok") is True and bool(app_id), str(draft)[:200])
    check("idea stage may skip financials", data(draft).get("stage_at_application") == "idea")

    sub = call("application.submit", "U-SR1", {"application_id": app_id})
    check("application submitted and acknowledged", sub.get("ok") is True, str(sub)[:200])

    scored = call("screening.score", "U-SR1", {
        "application_id": app_id,
        "reviewer_id": "U-SR1",
        "completeness": 10,
        "documents": 10,
        "unique_idea": 20,
        "revenue": 10,
        "traction": 10,
        "past_funding": 20,
        "founder_capability": 5,
        "incubation": 5,
        "ip_defensibility": 10,
        "outcome": "proceed",
        "comments": "Strong idea, clear evidence",
        "evidence": "deck, filings",
    })
    check("screening scored out of 100", scored.get("ok") is True, str(scored)[:250])
    check("100 marks produce the qualifying outcome", "proceed" in json.dumps(scored).lower())

    # Idea-stage startups legitimately skip financial and traction criteria. Blank
    # criteria must be accepted and excluded from the denominator, not stored as zero.
    na_score = call("screening.score", "U-SR1", {
        "application_id": app_id,
        "completeness": 10,
        "documents": 10,
        "unique_idea": 20,
        "founder_capability": 5,
        "incubation": 5,
        "ip_defensibility": 10,
        "outcome": "proceed",
        "comments": "Idea stage: financial and traction criteria not applicable",
    })
    calc = data(na_score).get("calculation") or {}
    check("blank criteria are accepted and excluded from the denominator", na_score.get("ok") is True, str(na_score)[:250])
    check(
        "non-applicable criteria are recorded as not applicable",
        set(calc.get("notApplicable", [])) >= {"revenue", "traction", "past_funding"},
        json.dumps(calc)[:250],
    )

    inv = call("bootcamp.invite", "U-SR1", {"application_id": app_id})
    check("bootcamp invitation recorded", inv.get("ok") is True, str(inv)[:200])

    partial = call("bootcamp.record", "U-SR1", {
        "application_id": app_id,
        "attended": True,
        "process_briefing_done": True,
        "readiness_session_done": True,
        "mou_briefing_done": False,
        "fee_briefing_done": False,
    })
    check(
        "attendance alone is not preparation complete",
        "not ready" in json.dumps(partial).lower() or data(partial).get("preparation_completed") in (False, 0, None),
        str(partial)[:250],
    )

    ready = call("bootcamp.record", "U-SR1", {
        "application_id": app_id,
        "attended": True,
        "process_briefing_done": True,
        "readiness_session_done": True,
        "mou_briefing_done": True,
        "fee_briefing_done": True,
        "actions_assigned": "Share cap table",
    })
    check("preparation completed once every session is done", ready.get("ok") is True, str(ready)[:250])

    ana = call("analyst.evaluate", "U-AN1", {
        "application_id": app_id,
        "analyst_id": "U-AN1",
        "thesis_fit": 8,
        "market_opportunity": 7,
        "traction": 6,
        "business_model": 8,
        "competitive_positioning": 7,
        "willingness_to_invest": 7,
        "indicative_amount": 250000000,
        "recommendation": "proceed",
        "decision_reason": "Fits the thesis",
        "outstanding_concern": "Customer concentration",
    })
    check("analyst evaluation recorded", ana.get("ok") is True, str(ana)[:250])

    analyst_view = get(f"/founders?limit=5", "U-AN1")
    founders = analyst_view["data"]["items"]
    check(
        "analyst view redacts founder contact details",
        all(f.get("email") in (None, "", "[restricted]") for f in founders),
        str(founders[:1])[:200],
    )
    mgmt_view = get("/founders?limit=5", "U-MGMT")
    check(
        "management view keeps founder contact details",
        any(m.get("email") not in (None, "", "[restricted]") for m in mgmt_view["data"]["items"]),
    )

    mou = call("mou.share", "U-SR1", {
        "application_id": app_id,
        "commercial_schedule": "2% success fee",
        "founder_email": "founder@example.test",
    })
    mou_id = data(mou).get("id")
    check("MoU shared and review clock started", mou.get("ok") is True, str(mou)[:250])
    check(
        "AMA and signing deadlines are working-day based",
        bool(data(mou).get("legal_ama_due")) and bool(data(mou).get("signing_deadline")),
        str(data(mou))[:250],
    )

    ama = call("mou.record_ama", "U-LEGAL1", {"mou_id": mou_id})
    check("Legal AMA recorded", ama.get("ok") is True, str(ama)[:200])

    resp = call("mou.respond", "U-SR1", {
        "mou_id": mou_id,
        "response": "Proceed",
        "founder_email": "founder@example.test",
    })
    check("MoU signed", resp.get("ok") is True, str(resp)[:250])

    irr = call("irr.request", "U-SR1", {"application_id": app_id})
    irr_id = data(irr).get("id")
    check("IRR requested after MoU signing", irr.get("ok") is True, str(irr)[:250])

    for step_name in ["accept_handover", "send_checklist", "prepare", "review", "approve", "share_with_ir"]:
        out = call("irr.advance", "U-FIN1", {"irr_id": irr_id, "step": step_name})
        if not out.get("ok"):
            check(f"IRR step {step_name}", False, str(out)[:200])
            break
    else:
        check("IRR advanced through every handover step", True)

    step("Investor journey: sourcing, verification, grading, matching, pitches, Pitch Day")

    investor = call("investor.create", "U-IR1", {
        "name": "E2E Capital",
        "category": "Family office",
        "investing_entity": "E2E Capital LLP",
        "source": "Referral",
        "referral_relationship": "Community partner",
        "decision_maker": "Asha Rao",
        "authorised_representative": "Asha Rao",
        "sector_focus": "Retail SaaS",
        "stage_focus": "early_revenue",
        "geography": "Tamil Nadu",
        "thesis": "Profitable B2B SaaS",
        "ticket_min": 100000000,
        "ticket_max": 500000000,
        "proposed_season_allocation": 1000000000,
        "portfolio": "Two SaaS companies",
        "reference_checks": "Two references cleared",
        "verification_evidence": "PAN, bank proof",
        "availability": "Panel available in Q1",
        "expected_decision_timeline": "30 days",
        "relationship_owner_id": "U-IR1",
    })
    investor_id = data(investor).get("id")
    check("investor record created", investor.get("ok") is True and bool(investor_id), str(investor)[:250])

    ver = call("investor.verify", "U-IR1", {
        "investor_id": investor_id,
        "verification_evidence": "PAN verified, bank proof verified",
        "reference_checks": "Both references cleared",
    })
    check("investor verified against the eligibility policy", ver.get("ok") is True, str(ver)[:250])

    grade = call("investor.grade", "U-IR1", {
        "investor_id": investor_id,
        "grade": "l2",
        "dimension": "Overall",
        "score": 78,
        "evidence": "Track record and cheque size",
        "permitted_engagement": "Panels and follow-on",
        "panel_role": "Panel member",
        "review_date": "2027-04-01",
    })
    check("investor graded L1-L4", grade.get("ok") is True, str(grade)[:250])

    agr = call("investor.agreement", "U-IR1", {
        "investor_id": investor_id,
        "document_type": "NDA",
        "status": "verified",
        "reference": "NDA-E2E-1",
    })
    check("agreement recorded", agr.get("ok") is True, str(agr)[:250])
    check(
        "agreement action reports the outstanding documents for the category",
        "ipa" in json.dumps(agr).lower() or "mo" in json.dumps(agr).lower(),
        str(agr)[:300],
    )

    suggest = call("match.suggest", "U-IR1", {"startup_id": "S-06"})
    check("matches suggested for the startup", suggest.get("ok") is True, str(suggest)[:300])

    matches = get("/matches?limit=50")["data"]["items"]
    match = next((m for m in matches if m.get("investor_id") == investor_id and m.get("startup_id") == "S-06"), None)
    check("the match has its own record", match is not None, str(matches[:2])[:300])
    if match:
        approve = call("match.approve", "U-IR1", {"match_id": match["id"]})
        check("Investor Relations approves circulation", approve.get("ok") is True, str(approve)[:200])
        share = call("match.share", "U-IR1", {
            "match_id": match["id"],
            "information_shared": "IRR v1 and teaser",
            "info_version": "v1",
        })
        check("information shared with its version recorded", share.get("ok") is True, str(share)[:250])
        respond = call("match.respond", "U-IR1", {
            "match_id": match["id"],
            "response": "ready_to_proceed",
            "questions": "Unit economics",
            "indicative_amount": 300000000,
            "next_action": "Schedule pitch",
            "next_action_due": "2026-12-15",
        })
        check("investor response recorded", respond.get("ok") is True, str(respond)[:250])

    pitch = call("pitch.schedule", "U-IR1", {
        "startup_id": "S-06",
        "investor_id": investor_id,
        "scheduled_at": "2026-12-20T10:00:00Z",
        "duration_pitch_min": 5,
        "duration_qa_min": 5,
        "material_shared": "IRR v1",
    })
    pitch_id = data(pitch).get("id")
    check("virtual pitch scheduled at 5 + 5 minutes", pitch.get("ok") is True, str(pitch)[:250])

    prec = call("pitch.record", "U-IR1", {
        "pitch_id": pitch_id,
        "attended": True,
        "investor_questions": "Gross margin trend",
        "responses": "Answered with cohort data",
        "response": "ready_to_invest",
        "amount_confirmed": 300000000,
        "terms_confirmed": "Standard terms",
    })
    check("pitch response recorded", prec.get("ok") is True, str(prec)[:250])

    pd = call("pitchday.record", "U-IR1", {
        "startup_id": "S-06",
        "episode_no": 12,
        "scheduled_at": "2027-01-10T09:00:00Z",
        "irr_distributed": True,
        "information_memorandum_distributed": True,
        "outcome": "golden_pass_issued",
        "follow_on_interest": "Two HNIs interested",
    })
    pd_id = data(pd).get("id")
    check("Pitch Day recorded with IRR and IM distribution", pd.get("ok") is True, str(pd)[:250])

    gp = call("pitchday.golden_pass", "U-IR1", {
        "startup_id": "S-06",
        "investor_id": investor_id,
        "amount": 300000000,
        "evidence": "Signed intent note",
        "valuation": "Rs 30 crore",
        "terms": "Indicative only",
        "pitch_day_id": pd_id,
    })
    gp_id = data(gp).get("id")
    check("Golden Pass issued as initial interest", gp.get("ok") is True, str(gp)[:250])

    commits = get("/commitments?limit=100")["data"]["items"]
    gp_row = next((c for c in commits if c.get("id") == gp_id), None)
    check(
        "Golden Pass is stored as a Golden Pass, not a confirmed commitment",
        gp_row is not None and gp_row.get("is_golden_pass") in (1, True) and gp_row.get("status") != "confirmed",
        str(gp_row)[:300],
    )

    confirmed = call("commitment.confirm", "U-IR1", {
        "commitment_id": gp_id,
        "status": "confirmed",
        "evidence": "Term sheet signed",
    })
    check("a written commitment is confirmed explicitly", confirmed.get("ok") is True, str(confirmed)[:250])

    rev = call("commitment.revise", "U-IR1", {
        "commitment_id": gp_id,
        "amount": 250000000,
        "valuation": "Rs 30 crore",
        "terms": "Revised cheque size",
        "evidence": "Revised intent note",
        "revision_reason": "Reduced cheque size after diligence",
    })
    check("a revision creates a new row and keeps the original", rev.get("ok") is True, str(rev)[:300])
    check(
        "the revision points back at the original commitment",
        data(rev).get("revised_from_id") == gp_id,
        str(data(rev))[:250],
    )

    dec = call("committee.decide", "U-MGMT", {
        "startup_id": "S-06",
        "outcome": "proceed",
        "conditions": "Complete documentation before the shoot",
        "re_review_date": "2027-02-01",
    })
    dec_payload = data(dec)
    dec_id = (dec_payload.get("decision") or {}).get("id")
    check("committee authorises show selection", dec.get("ok") is True and bool(dec_id), str(dec)[:300])
    check(
        "committee pack is compiled from the records",
        bool((dec_payload.get("decision") or {}).get("pack_summary")) and len(dec_payload.get("pack", {}).get("items", [])) >= 7,
        str(dec_payload)[:300],
    )

    step("Finance: turnover-based upfront fee and production clearance")

    fee = call("upfront.initiate", "U-FIN1", {
        "startup_id": "S-06",
        "committee_decision_id": dec_id,
        "initial_interest_announced_on": "2027-01-11",
        "turnover": 12000000000,
        "turnover_evidence": "Audited FY26 accounts",
        "financial_year": "FY26",
    })
    fee_id = data(fee).get("id")
    check("upfront fee initiated from turnover", fee.get("ok") is True and bool(fee_id), str(fee)[:300])
    check("the fee amount is derived from the approved schedule", bool(data(fee).get("fee_amount")), str(data(fee))[:300])

    invx = call("upfront.invoice", "U-FIN1", {
        "fee_id": fee_id,
        "invoice_no": "INV-UP-E2E-1",
        "due_date": "2027-02-05",
    })
    check("invoice issued", invx.get("ok") is True, str(invx)[:250])

    hand = call("production.handover", "U-PROD1", {
        "startup_id": "S-06",
        "pack_summary": "Profile, contacts, selection decision",
        "permitted_business_information": "Public metrics only",
    })
    hand_id = data(hand).get("id")
    check("production gets an advance notification on selection", hand.get("ok") is True, str(hand)[:300])

    blocked = call("production.accept", "U-PROD1", {"handover_id": hand_id})
    check(
        "the shoot handover is blocked until payment is cleared",
        blocked.get("ok") is False,
        str(blocked)[:300],
    )

    receipt = call("upfront.record_receipt", "U-FIN1", {
        "fee_id": fee_id,
        "amount": data(fee).get("fee_amount") or 1250000000,
        "payment_reference": "NEFT-E2E-1",
    })
    check("receipt verified and allocated", receipt.get("ok") is True, str(receipt)[:300])

    accepted = call("production.accept", "U-PROD1", {"handover_id": hand_id})
    check("handover accepted once payment is cleared", accepted.get("ok") is True, str(accepted)[:300])

    step("Production: AV, mock and main shoot")

    av = call("av.update", "U-PROD1", {
        "startup_id": "S-06",
        "status": "completed",
        "story_research": "Founder story and unit economics",
        "location": "Chennai studio",
        "crew": "Two cameras",
        "schedule_on": "2027-02-20",
        "founder_availability": "Confirmed",
        "shot_requirements": "Store walkthrough",
        "asset_links": "s3://assets/e2e",
    })
    check("AV shoot completed", av.get("ok") is True, str(av)[:250])

    mock = call("mock.update", "U-PROD1", {
        "startup_id": "S-06",
        "scheduled_on": "2027-02-25",
        "costumes_properties": "Formal wear",
        "pitch_revisions": "Tightened to 5 minutes",
        "product_demo_ready": True,
        "stage_movement_rehearsed": True,
        "final_ask": 250000000,
        "valuation_information": "Rs 30 crore",
        "open_actions": "None",
        "approve_readiness": True,
    })
    check("mock shoot readiness approved", mock.get("ok") is True, str(mock)[:250])

    main = call("mainshoot.update", "U-PROD1", {
        "startup_id": "S-06",
        "episode_no": 12,
        "scheduled_on": "2027-03-02",
        "status": "completed",
        "founder_attendance": "Founder present",
        "investor_attendance": "Lead investor present",
        "live_ask": 250000000,
        "live_offers": "Two offers",
        "accepted_deal_terms": "Rs 2 crore at Rs 30 crore valuation",
        "lead_investor_id": investor_id,
        "conditions": "Standard closing conditions",
        "outstanding_actions": "Sign letters",
    })
    check("main shoot recorded", main.get("ok") is True, str(main)[:300])

    step("Post-shoot: deal closure, tranches and deployment verification")

    deal = call("deal.open", "U-IR1", {
        "startup_id": "S-06",
        "investor_id": investor_id,
        "round_name": "Seed round S2",
        "target_amount": 200000000,
        "committed_amount": 200000000,
        "agreed_terms": "2% success fee, no upfront adjustment",
        "valuation": "Rs 30 crore",
        "closure_owner_id": "U-IR1",
        "expected_close_on": "2027-04-30",
    })
    deal_payload = data(deal)
    deal_id = (deal_payload.get("deal") or {}).get("id")
    check("deal opened with a closure owner", deal.get("ok") is True and bool(deal_id), str(deal)[:300])
    check(
        "the 48-hour communication thread becomes a tracked task",
        bool((deal_payload.get("deal") or {}).get("communication_thread_due")),
        str(deal_payload)[:300],
    )

    tasks = get("/tasks?limit=200")["data"]["items"]
    check(
        "the communication thread task exists for the deal",
        any(t.get("entity_id") == deal_id and "communication" in json.dumps(t).lower() for t in tasks),
        str([t for t in tasks if t.get("entity_id") == deal_id][:2])[:300],
    )

    # Shoot-day letters are recorded by purpose; the signing event drives the requirement.
    for purpose in ["investment_commitment_letter", "deal_acceptance_letter"]:
        out = call("deal.document", "U-IR1", {
            "deal_id": deal_id,
            "purpose": purpose,
            "status": "verified",
            "signer": "Founder and lead investor",
        })
        check(f"shoot-day {purpose} recorded by purpose", out.get("ok") is True, str(out)[:250])
    shoots = get("/main_shoots?limit=100")["data"]["items"]
    shoot = next((m for m in shoots if m.get("startup_id") == "S-06"), None)
    check(
        "the signing event updates the main shoot letter references",
        shoot is not None
        and bool(shoot.get("investment_commitment_letter_ref"))
        and bool(shoot.get("startup_deal_acceptance_letter_ref")),
        str(shoot)[:300],
    )

    t1 = call("tranche.schedule", "U-IR1", {"deal_id": deal_id, "amount": 7500000, "scheduled_on": "2027-04-10"})
    t2 = call("tranche.schedule", "U-IR1", {"deal_id": deal_id, "amount": 12500000, "scheduled_on": "2027-06-10"})
    t1_id, t2_id = data(t1).get("id"), data(t2).get("id")
    check("two tranches scheduled", t1.get("ok") and t2.get("ok"), f"{t1} {t2}"[:250])

    call("tranche.report", "U-IR1", {"tranche_id": t1_id, "amount": 7500000, "evidence": "Investor NEFT advice"})
    before = get(f"/deals/{deal_id}")["data"]["record"]
    tranches_before = get("/tranches?limit=100")["data"]["items"]
    t1_before = next(t for t in tranches_before if t["id"] == t1_id)
    check(
        "an investor-reported transfer is not yet verified deployment",
        t1_before.get("status") != "verified" and (t1_before.get("verified_amount") in (None, 0)),
        str(t1_before)[:300],
    )

    call("tranche.confirm_receipt", "U-FIN1", {"tranche_id": t1_id})
    call("tranche.verify", "U-FIN1", {"tranche_id": t1_id, "verified_amount": 7500000, "evidence": "Bank statement matched"})

    deployment = get("/tranches?limit=100")["data"]["items"]
    t1_after = next(t for t in deployment if t["id"] == t1_id)
    check("verified deployment is recorded with the verifier", t1_after.get("status") == "verified", str(t1_after)[:300])

    success = get("/success_fees?limit=100")["data"]["items"]
    check(
        "verified deployment triggered the success fee without an email",
        any(s.get("deal_id") == deal_id for s in success),
        str(success[:2])[:300],
    )

    sf = next((s for s in success if s.get("deal_id") == deal_id), None)
    if sf:
        calc = call("successfee.calculate", "U-FIN1", {"deal_id": deal_id})
        check("success fee calculated on the verified amount", calc.get("ok") is True, str(calc)[:250])
        invoice = call("successfee.invoice", "U-FIN1", {
            "success_fee_id": sf["id"],
            "invoice_no": "INV-SF-E2E-1",
            "due_date": "2027-05-15",
            "tax_amount": 1800000,
        })
        check("success fee invoice issued with tax", invoice.get("ok") is True, str(invoice)[:250])
        collect = call("successfee.collect", "U-FIN1", {
            "success_fee_id": sf["id"],
            "amount": 100000,
            "reference": "NEFT-SF-E2E-1",
        })
        check("receipt allocated against the success fee invoice", collect.get("ok") is True, str(collect)[:250])

        over = call("successfee.collect", "U-FIN1", {
            "success_fee_id": sf["id"],
            "amount": 999999999,
            "reference": "NEFT-SF-OVER",
        })
        check("an allocation beyond the invoice is rejected", over.get("ok") is False, str(over)[:250])

        settle = call("successfee.collect", "U-FIN1", {
            "success_fee_id": sf["id"],
            "amount": 50000,
            "reference": "NEFT-SF-E2E-2",
        })
        check(
            "the account reconciles once the balance reaches zero",
            settle.get("ok") is True and data(settle).get("status") == "collected" and float(data(settle).get("outstanding") or 0) == 0,
            str(settle)[:300],
        )

    rev_tranche = call("tranche.reverse", "U-FIN1", {"tranche_id": t2_id, "reason": "Investor withdrew before transfer"})
    check("returned funds are recorded as a reversal", rev_tranche.get("ok") is True, str(rev_tranche)[:250])
    if rev_tranche.get("ok"):
        check(
            "the reversal links back to the original tranche",
            data(rev_tranche).get("reversal_of_id") == t2_id,
            str(data(rev_tranche))[:250],
        )

    step("Finance edge cases: extension, waiver, dispute, refund and the fee measures")

    late = call("upfront.initiate", "U-FIN1", {
        "startup_id": "S-01",
        "initial_interest_announced_on": "2027-01-11",
        "turnover": 4500000000,
        "turnover_evidence": "Audited FY26 accounts",
        "financial_year": "FY26",
    })
    late_id = data(late).get("id")
    check("a second upfront fee is initiated on a different turnover slab", late.get("ok") is True and bool(late_id), str(late)[:300])

    late_before = data(late)
    ext = call("upfront.extension", "U-MGMT", {
        "fee_id": late_id,
        "new_due_date": "2027-04-01",
        "late_payment_reason": "Bank account change pending",
        "management_decision": "Extension approved to 2027-04-01",
    })
    check("extension approved", ext.get("ok") is True, str(ext)[:250])
    check(
        "the approved extension preserves the original due date for ageing",
        bool(data(ext).get("original_due_date")) and data(ext).get("original_due_date") == late_before.get("due_date"),
        f"before={late_before.get('due_date')} after={data(ext).get('original_due_date')}",
    )

    shot_claim = call("upfront.record_receipt", "U-FIN1", {
        "fee_id": late_id,
        "amount": 1000,
        "payment_reference": "screenshot-only",
        "verified": False,
    })
    check(
        "a payment screenshot alone does not mark the invoice paid",
        shot_claim.get("ok") is False,
        str(shot_claim)[:250],
    )

    disp = call("upfront.dispute", "U-FIN1", {"fee_id": late_id, "reason": "Founder disputes the turnover basis"})
    check("a dispute is recorded", disp.get("ok") is True and data(disp).get("status") == "disputed", str(disp)[:250])

    waiver = call("upfront.waive", "U-MGMT", {"fee_id": late_id, "amount": 50000000, "reason": "Goodwill waiver approved by Management"})
    check("a waiver is recorded with a reason and reduces the outstanding balance", waiver.get("ok") is True and data(waiver).get("status") == "waived", str(waiver)[:250])

    refund = call("upfront.refund", "U-MGMT", {"fee_id": late_id, "amount": 10000000, "credit_note_ref": "CN-E2E-1"})
    check("a refund is recorded with a credit note and a ledger entry", refund.get("ok") is True and data(refund).get("status") == "refunded", str(refund)[:250])

    sf_rows = get("/success_fees?limit=100")["data"]["items"]
    sf_row = next((s for s in sf_rows if s.get("deal_id") == deal_id), None)
    check(
        "forecast fee, fee due, invoiced, collected and outstanding are held separately",
        sf_row is not None
        and all(k in sf_row for k in ["forecast_fee", "fee_due", "invoiced_amount", "collected_amount", "outstanding"]),
        str(sf_row)[:350],
    )
    if sf_row:
        check(
            "collected never exceeds invoiced and outstanding reconciles",
            float(sf_row["collected_amount"]) <= float(sf_row["invoiced_amount"]),
            str(sf_row)[:300],
        )
        check(
            "the upfront deduction stays off unless the agreement says it is adjustable",
            sf_row.get("upfront_adjustable") in (0, False) and float(sf_row.get("upfront_adjustment") or 0) == 0,
            str(sf_row)[:300],
        )

    ledger = get("/ledger_entries?limit=200")["data"]["items"]
    entries = [e for e in ledger if e.get("startup_id") == "S-06"]
    check(
        "the startup account reconciles from ledger entries",
        any(e.get("entry_type") == "success_fee" for e in entries) and any(e.get("entry_type") == "receipt" for e in entries),
        str(entries[:3])[:300],
    )

    step("Content, community and platform")

    ep = call("episode.update", "U-PROD1", {
        "startup_id": "S-06",
        "episode_no": 12,
        "status": "approved",
        "editing_status": "Final cut locked",
        "approvals_status": "Approved by legal",
    })
    check("episode editing and approvals recorded", ep.get("ok") is True, str(ep)[:250])

    tc = call("telecast.update", "U-MKT1", {
        "startup_id": "S-06",
        "step": "telecast",
        "episode_no": 12,
        "telecast_date": "2027-04-05",
        "promo_requirements": "Three social posts",
        "promo_assets_approved": "Teaser approved",
        "founder_posting_done": True,
        "post_telecast_activity": "LinkedIn campaign",
        "founder_feedback": "Positive",
        "public_announcement": "Announced Rs 2 crore",
        "announced_amount": 200000000,
        "committed_amount": 200000000,
        "verified_deployed_amount": 7500000,
    })
    check("telecast recorded with separate announced, committed and verified figures", tc.get("ok") is True, str(tc)[:300])

    member = call("community.member_create", "U-COMM1", {
        "name": "Priya Nair",
        "email": "priya.nair@example.test",
        "member_type": "mentor",
        "organisation": "E2E Ventures",
        "sector": "Retail SaaS",
        "geography": "Karnataka",
        "interests": "Go-to-market",
        "relationship_owner_id": "U-COMM1",
        "communication_preferences": "Email",
        "consent_marketing": True,
        "consent_contact": True,
        "engagement_summary": "Mentoring clinic",
    })
    check("community member created", member.get("ok") is True, str(member)[:250])

    role = call("community.member_add_role", "U-COMM1", {
        "member_id": data(member).get("id"),
        "role": "investor",
        "notes": "Also invests small cheques",
    })
    check("a second role is added to the same person record", role.get("ok") is True, str(role)[:250])

    event = call("event.create", "U-COMM1", {
        "name": "Founder meetup Chennai",
        "event_type": "Founder meetup",
        "purpose": "Founder engagement",
        "owner_id": "U-COMM1",
        "budget": 50000000,
        "scheduled_on": "2027-05-20",
        "follow_up_tasks": "Send thank-you notes",
    })
    event_id = data(event).get("id")
    check("community event created", event.get("ok") is True, str(event)[:250])

    reg = call("event.register", "U-COMM1", {"event_id": event_id, "member_id": data(member).get("id")})
    check("event registration recorded", reg.get("ok") is True, str(reg)[:250])

    ref = call("referral.create", "U-COMM1", {
        "source_type": "Community event",
        "source_id": event_id,
        "source_name": "Founder meetup Chennai",
        "referred_name": "UrbanNest",
        "referred_type": "startup_application",
        "original_contributor": "Priya Nair",
        "additional_contributors": "Relationship manager",
        "outcome": "Application submitted",
    })
    check("referral recorded", ref.get("ok") is True, str(ref)[:250])
    check(
        "an event-generated referral links to the existing startup",
        bool(data(ref).get("startup_id")),
        str(data(ref))[:300],
    )

    sup = call("support.create", "U-COMM1", {
        "member_id": data(member).get("id"),
        "startup_id": "S-06",
        "request_type": "investor_introduction",
        "detail": "Introduction to a Chennai family office",
        "owner_id": "U-COMM1",
    })
    check("support request created with a working-day deadline", sup.get("ok") is True, str(sup)[:250])

    res = call("support.resolve", "U-COMM1", {
        "request_id": data(sup).get("id"),
        "outcome": "Introduction made",
        "founder_feedback": "Very helpful",
    })
    check("support request resolved with founder feedback", res.get("ok") is True, str(res)[:250])

    doc = call("document.create", "U-IR1", {
        "entity_type": "deal",
        "entity_id": deal_id,
        "purpose": "term_sheet",
        "title": "Term sheet",
        "category": "Legal",
        "status": "signed",
        "file_ref": "s3://docs/e2e-term-sheet.pdf",
    })
    check("document created by purpose, not title", doc.get("ok") is True, str(doc)[:250])

    sync = call("integration.sync", "U-MGMT", {"integration_id": "INT-01", "records": 12, "simulate_failure": True, "error": "Auth expired"})
    check("a failed sync raises an alert instead of stopping silently", sync.get("ok") is True, str(sync)[:300])

    imp = call("import.run", "U-MGMT", {"entity_type": "startups", "file_name": "legacy-startups.csv", "rows": 40, "duplicates": 3, "skipped": 1})
    check("import batch reconciled", imp.get("ok") is True, str(imp)[:250])

    pol = call("policy.revise", "U-MGMT", {
        "code": "POL-SCREEN-QUALIFY",
        "value": {"qualifyingScore": 65},
        "reason": "Committee approved a 65 mark cut-off",
        "effective_from": "2027-04-01",
    })
    check("policy revised with a reason and effective date", pol.get("ok") is True, str(pol)[:300])

    step("Remaining catalog actions")

    # Tasks: create, update and escalate, each with owner, due date and evidence.
    tsk = call("task.create", "U-SR1", {
        "title": "Collect the signed MoU for the E2E startup",
        "department": "startup_relationships",
        "module": "mou",
        "entity_type": "application",
        "entity_id": app_id,
        "due_date": "2027-05-01",
        "required_output": "Signed MoU",
        "evidence": "Signed PDF",
        "next_action": "Share the MoU with the founder",
    })
    task_id = data(tsk).get("id")
    check("task created with owner, due date and required output", tsk.get("ok") is True and bool(task_id), str(tsk)[:200])
    tupd = call("task.update", "U-SR1", {"task_id": task_id, "status": "in_progress", "next_action": "Chase the founder"})
    check("task updated", tupd.get("ok") is True and data(tupd).get("status") == "in_progress", str(tupd)[:200])
    tesc = call("task.escalate", "U-SR1", {"task_id": task_id, "reason": "No response after the reminder"})
    check("task escalated to Management", tesc.get("ok") is True and data(tesc).get("escalation_status") == "escalated", str(tesc)[:200])

    # Handover between teams, then acceptance by the receiving team.
    hnd = call("handover.create", "U-SR1", {
        "to_department": "production",
        "entity_type": "startup",
        "entity_id": "S-01",
        "summary": "Production handover pack for the E2E run",
    })
    handover_id = data(hnd).get("id")
    check("handover raised between departments", hnd.get("ok") is True and bool(handover_id), str(hnd)[:200])
    hacc = call("handover.accept", "U-PROD1", {"handover_id": handover_id})
    check("handover accepted by the receiving team", hacc.get("ok") is True and data(hacc).get("status") == "accepted", str(hacc)[:200])

    # Document verification.
    dver = call("document.verify", "U-LEGAL1", {"document_id": "DOC-01", "status": "verified", "notes": "Checked"})
    check("document verified", dver.get("ok") is True, str(dver)[:200])

    # Community event completion and referral progression.
    evc = call("event.complete", "U-COMM1", {"event_id": "EV-01", "outcomes": "Three qualified referrals", "feedback_score": 4.5})
    check("event completed with outcomes", evc.get("ok") is True and data(evc).get("status") == "completed", str(evc)[:200])
    radv = call("referral.advance", "U-COMM1", {"referral_id": "R-01", "status": "qualified", "outcome": "Shortlisted"})
    check("referral advanced", radv.get("ok") is True, str(radv)[:200])

    # Commitment withdrawal keeps the reason.
    cwd = call("commitment.withdraw", "U-IR1", {"commitment_id": "C-01", "reason": "Investor deferred to next season"})
    check("commitment withdrawn with a reason", cwd.get("ok") is True and data(cwd).get("revision_reason"), str(cwd)[:200])

    # Deal advanced through the closure steps; the funding round follows.
    dad = call("deal.advance", "U-IR1", {"deal_id": "D-01", "step": "due_diligence", "next_action": "Open the data room"})
    check("deal advanced through a closure step", dad.get("ok") is True and data(dad).get("status") == "due_diligence", str(dad)[:200])

    # Upfront fee approval by Management, then a ledger entry on the startup account.
    uap = call("upfront.approve", "U-MGMT", {"fee_id": "UF-04", "fee_amount": 500000_00})
    check("upfront fee approved by Management", uap.get("ok") is True, str(uap)[:200])
    led = call("ledger.add", "U-FIN1", {"startup_id": "S-01", "entry_type": "adjustment", "amount": 100000_00, "memo": "Rounding adjustment"})
    check("ledger entry recorded", led.get("ok") is True, str(led)[:200])

    # Pre-shoot confirmation flags a late IRR against the two-week policy.
    psc = call("preshoot.confirm", "U-IR1", {"startup_id": "S-01", "episode_no": "EP-E2E", "shoot_date": today_str()})
    check("pre-shoot confirmation recorded and the IRR deadline is checked", psc.get("ok") is True, str(psc)[:250])

    nread = call("notification.read", "U-MGMT", {})
    check("notifications can be marked read", nread.get("ok") is True, str(nread)[:200])

    step("Management dashboard and audit")

    dash = get("/dashboard")["data"]
    check("dashboard reports application-to-selection conversion", "conversionPct" in json.dumps(dash.get("kpis", {}).get("applications", {})), str(dash.get("kpis", {}))[:200])
    check("dashboard reports stage-wise backlog and ageing", len(dash.get("kpis", {}).get("stageBacklog", [])) > 0)
    kpis = dash.get("kpis", {})
    check("dashboard reports fees due, collected and overdue", all(k in kpis.get("upfront", {}) for k in ["due", "collected", "overdue"]), json.dumps(kpis.get("upfront")))
    check("dashboard reports success fees separately", all(k in kpis.get("successFees", {}) for k in ["due", "invoiced", "collected", "overdue"]), json.dumps(kpis.get("successFees")))
    check("dashboard reports verified deployment separately from commitments", "deployed" in kpis.get("commitments", {}) and "committed" in kpis.get("commitments", {}), json.dumps(kpis.get("commitments")))
    check("dashboard reports shoot and telecast readiness", "shootCompleted" in kpis.get("shoot", {}) and "telecastDone" in kpis.get("shoot", {}), json.dumps(kpis.get("shoot")))
    check("dashboard reports community activity", "members" in kpis.get("community", {}))
    check("dashboard reports department-wise overdue actions", len(kpis.get("overdueByDepartment", [])) > 0)
    check("dashboard reports material exceptions", len(kpis.get("exceptions", [])) > 0)

    audit = get("/audit_events?limit=500")["data"]["items"]
    check("scores, amounts and approvals are audited", len(audit) > 20, f"{len(audit)} audit rows")
    check(
        "the audit trail records before and after values",
        any(a.get("field") and a.get("before_value") is not None for a in audit),
    )

    board = get("/startup-board")["data"]
    check("the startup board tracks selection, production, investment and finance separately", bool(board), str(board)[:300])

    # --- Season dimension -------------------------------------------------
    # The show runs in numbered seasons and every screen is scoped to one, so switching
    # the season must change the records and the figures, and a new record must land in
    # the season the user is looking at rather than a hard-coded one.
    session = get("/session")["data"]
    seasons = session.get("seasons", [])
    codes = [s["code"] for s in seasons]
    check("the session lists numbered seasons S01, S02 and S03", {"S01", "S02", "S03"}.issubset(set(codes)), str(codes))
    check("exactly one season is live", sum(1 for s in seasons if s["status"] == "live") == 1, str(seasons))
    check("the session names a current season", session.get("currentSeasonId") in {s["id"] for s in seasons}, str(session.get("currentSeasonId")))

    s1 = get("/dashboard", season="S-2024")["data"]
    s3 = get("/dashboard", season="S-2026")["data"]
    n1 = s1["kpis"]["applications"]["total"]
    n3 = s3["kpis"]["applications"]["total"]
    check("the dashboard is scoped to the selected season", n1 != n3 and n1 > 0 and n3 > 0, f"S01={n1} S03={n3}")
    check("each season has its own cohort on the board", len(s1["board"]) != len(s3["board"]), f"S01={len(s1['board'])} S03={len(s3['board'])}")
    check(
        "upfront fees and deployment are season scoped",
        s1["kpis"]["upfront"]["due"] != s3["kpis"]["upfront"]["due"],
        f"S01={s1['kpis']['upfront']['due']} S03={s3['kpis']['upfront']['due']}",
    )

    apps_2024 = {r["reference_no"] for r in get("/applications?limit=200", season="S-2024")["data"]["items"]}
    apps_2026 = {r["reference_no"] for r in get("/applications?limit=200", season="S-2026")["data"]["items"]}
    check("application lists are filtered by season", apps_2024 and apps_2026 and not (apps_2024 & apps_2026), f"S01={sorted(apps_2024)} S03={sorted(apps_2026)}")

    # A new application is written into the season the user is acting in.
    created = call(
        "application.draft",
        "U-SR1",
        {"startup_id": "S-11", "source": "Direct", "stage_at_application": "early_revenue", "notes": "Season scoping check."},
        season="S-2025",
    )
    inner = created.get("data") or {}
    new_app = inner.get("data") if isinstance(inner.get("data"), dict) else inner
    new_ref = (new_app or {}).get("reference_no")
    check("a new application is created in the acting season", str(new_ref or "").startswith("S02"), str(new_ref))
    check(
        "the new record appears only in its own season",
        bool(new_ref) and new_ref in {r["reference_no"] for r in get("/applications?limit=200", season="S-2025")["data"]["items"]},
        str(new_ref),
    )


    print(f"\n{'=' * 60}")
    print(f"{CHECKS - len(FAILURES)}/{CHECKS} checks passed")
    if FAILURES:
        print("\nFailures:")
        for f in FAILURES:
            print(f"  - {f}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
